@echo off
chcp 65001 >nul
echo ======================================================================
echo Running ZFC Consistency Checker
echo ======================================================================
echo.

REM Check if b.tex exists
if not exist "b.tex" (
    echo ERROR: b.tex not found in current directory
    echo Please make sure b.tex is in: %CD%
    pause
    exit /b 1
)

echo Found b.tex
echo.

REM Run the checker
echo Running consistency check...
D:\apps\Python38_updated\python.exe zfc_checker.py > output.txt 2>&1

if errorlevel 1 (
    echo ERROR: Consistency check failed
    echo Check output.txt for details
    pause
    exit /b 1
)

echo Consistency check completed successfully
echo.

REM Show results
echo Results:
echo   - consistency_report.log - Detailed report
echo   - consistency_results.json - JSON results
echo   - formal_verification.lean - Lean code
echo   - output.txt - Console output
echo.

pause