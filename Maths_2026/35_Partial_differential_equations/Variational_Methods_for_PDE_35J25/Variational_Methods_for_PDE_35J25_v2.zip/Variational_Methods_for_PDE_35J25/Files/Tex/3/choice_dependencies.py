# choice_dependencies.py - Analyze which items truly need Choice

choice_items = {
    "banach-alaoglu": {
        "category": "Functional Analysis",
        "requires_choice": True,
        "reason": "Weak-* compactness requires Tychonoff theorem (equivalent to AC)",
        "alternative": "Can use Dependent Choice (DC) in some cases"
    },
    "frekhet": {
        "category": "L^p and Distribution",
        "requires_choice": True,
        "reason": "Compactness in L^p uses finite subcover (requires AC)",
        "alternative": "Can use Sequential Compactness in some cases"
    },
    "compact.embedding": {
        "category": "Sobolev Space",
        "requires_choice": True,
        "reason": "Rellich-Kondrachov uses compactness (AC)",
        "alternative": "Can use weaker compactness in some cases"
    },
    "divergence.neumann": {
        "category": "Physics and Elliptic",
        "requires_choice": False,  # Likely false positive
        "reason": "Uses Lax-Milgram which may not need full AC",
        "alternative": "Can prove with ZF + DC"
    },
    "subspace": {
        "category": "Hilbert Space",
        "requires_choice": False,  # Likely false positive
        "reason": "Projection onto closed subspace uses orthogonal complement",
        "alternative": "Can prove with ZF alone"
    }
}

print("Choice Dependency Analysis")
print("=" * 50)
for item, info in choice_items.items():
    status = "⚡ Requires AC" if info["requires_choice"] else "✅ No AC needed"
    print(f"\n{item}: {status}")
    print(f"  Reason: {info['reason']}")