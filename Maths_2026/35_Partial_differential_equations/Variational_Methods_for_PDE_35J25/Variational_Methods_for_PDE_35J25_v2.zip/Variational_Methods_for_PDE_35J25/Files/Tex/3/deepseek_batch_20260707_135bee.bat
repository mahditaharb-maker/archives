@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion

:: ============================================================
:: ZFC Dependencies Generator - Batch Script
:: ============================================================
:: This script runs the ZFC dependencies generator on b.tex
:: and produces zfc_tables.tex with dependency tables.
::
:: Usage: run_zfc_dependencies.bat
:: ============================================================

echo ======================================================================
echo ZFC Dependencies Generator
echo ======================================================================
echo.

:: Set Python path
set PYTHON_PATH=D:\apps\Python38_updated\python.exe

:: Check if Python exists
if not exist "%PYTHON_PATH%" (
    echo ERROR: Python not found at %PYTHON_PATH%
    echo Please update the PYTHON_PATH variable in this script.
    pause
    exit /b 1
)

echo Python found: %PYTHON_PATH%
echo.

:: Check if input file exists
set INPUT_FILE=b.tex
if not exist "%INPUT_FILE%" (
    echo ERROR: Input file '%INPUT_FILE%' not found
    echo Please make sure %INPUT_FILE% is in the current directory.
    echo Current directory: %CD%
    pause
    exit /b 1
)

echo Input file: %INPUT_FILE%
echo.

:: Set output file
set OUTPUT_FILE=zfc_tables.tex
set LOG_FILE=zfc_dependencies.log
set ERROR_LOG=zfc_dependencies_error.log

:: Remove old log files
if exist "%LOG_FILE%" del "%LOG_FILE%" 2>nul
if exist "%ERROR_LOG%" del "%ERROR_LOG%" 2>nul

echo Output file: %OUTPUT_FILE%
echo Log file: %LOG_FILE%
echo.

:: ============================================================
:: RUN THE SCRIPT
:: ============================================================

echo [1/3] Running ZFC dependencies generator...
echo.

:: Run with logging - capture both stdout and stderr
"%PYTHON_PATH%" zfc_dependencies.py "%INPUT_FILE%" "%OUTPUT_FILE%" > "%LOG_FILE%" 2>&1

:: Check exit code
if errorlevel 1 (
    echo ERROR: Script failed with exit code %errorlevel%
    echo.
    echo Last 20 lines of error log:
    echo ----------------------------------------
    type "%LOG_FILE%" | findstr /v /c:"====" | tail -20
    echo ----------------------------------------
    echo.
    echo Full log saved to: %LOG_FILE%
    pause
    exit /b 1
)

echo Script completed successfully.
echo.

:: ============================================================
:: DISPLAY RESULTS
:: ============================================================

echo [2/3] Results:
echo.

if exist "%OUTPUT_FILE%" (
    echo   ✅ Output file generated: %OUTPUT_FILE%
    
    :: Get file size
    for %%A in ("%OUTPUT_FILE%") do set FILE_SIZE=%%~zA
    echo   📄 File size: !FILE_SIZE! bytes
    
    :: Count definitions and theorems from log
    for /f "tokens=*" %%a in ('findstr /c:"Found" "%LOG_FILE%"') do echo   %%a
) else (
    echo   ❌ Output file not generated
)

echo.

:: ============================================================
:: SHOW SUMMARY FROM LOG
:: ============================================================

echo [3/3] Execution summary:
echo.

:: Extract summary from log file
if exist "%LOG_FILE%" (
    echo ----------------------------------------
    findstr /c:"Definitions" /c:"Theorems" /c:"Done" /c:"Output" "%LOG_FILE%"
    echo ----------------------------------------
) else (
    echo No log file found
)

echo.

:: ============================================================
:: OPTION: VIEW THE GENERATED TEX FILE
:: ============================================================

echo.
echo ======================================================================
echo Done!
echo ======================================================================
echo.
echo Generated files:
if exist "%OUTPUT_FILE%" echo   📄 %OUTPUT_FILE%
if exist "%LOG_FILE%" echo   📄 %LOG_FILE%
echo.
echo To view the generated tables:
echo   type %OUTPUT_FILE%
echo.
echo To compile the LaTeX:
echo   pdflatex %OUTPUT_FILE%
echo.
echo To rerun with a different input:
echo   %0 mydocument.tex output.tex
echo.

pause