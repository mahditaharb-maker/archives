@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion

echo ======================================================================
echo Building Elliptic Equations Formalization
echo ======================================================================
echo.

REM Check if Lean is installed
where lean 2>nul >nul
if errorlevel 1 (
    echo ERROR: Lean 4 is not installed or not in PATH
    echo Please install Lean 4 from: https://github.com/leanprover/lean4/releases
    pause
    exit /b 1
)

echo Lean found: 
lean --version
echo.

REM Check if lake is available
where lake 2>nul >nul
if errorlevel 1 (
    echo ERROR: Lake is not available
    echo Please ensure Lean is properly installed
    pause
    exit /b 1
)

REM Navigate to Lean project
if not exist "elliptic_equations" (
    echo Creating Lean project...
    lake new elliptic_equations
    cd elliptic_equations
    
    echo Adding Mathlib dependency...
    echo require Mathlib from git "https://github.com/leanprover-community/mathlib4.git" >> lakefile.lean
    
    echo Copying generated Lean code...
    if exist ..\formal_verification.lean (
        copy ..\formal_verification.lean .\EllipticEquations\Basic.lean
    )
) else (
    cd elliptic_equations
)

echo.
echo Building Lean project...
lake build

if errorlevel 1 (
    echo.
    echo Build failed!
    pause
    exit /b 1
)

echo.
echo Build successful!
echo.
echo Running Main.lean...
lake exec lean Main.lean

echo.
echo ======================================================================
echo Build complete!
echo ======================================================================
pause