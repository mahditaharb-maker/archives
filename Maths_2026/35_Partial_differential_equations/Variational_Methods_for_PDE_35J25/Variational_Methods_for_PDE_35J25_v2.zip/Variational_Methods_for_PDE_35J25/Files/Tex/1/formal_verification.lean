/
  Formalization of Elliptic Equations in Lean
  Verified against ZFC axioms

  This file was automatically generated from LaTeX definitions and theorems.
  Proofs are marked with 'sorry' and need to be filled in.

  ZFC Axioms used:
  - ZF1: Extensionality
  - ZF2: Pairing
  - ZF3: Union
  - ZF4: Infinity
  - ZF5: Power Set
  - ZF6: Replacement
  - ZF7: Separation
  - ZF8: Foundation
  - ZF9: Choice (AC)
-/

import Mathlib.Data.Real.Basic
import Mathlib.Analysis.InnerProductSpace.Basic
import Mathlib.Analysis.Calculus.Fderiv.Basic
import Mathlib.MeasureTheory.Integral.Bochner
import Mathlib.Topology.Instances.Real
import Mathlib.Data.Set.Basic
import Mathlib.Data.Nat.Basic
import Mathlib.Order.ConditionallyCompleteLattice.Basic

open Set
open Real
open Nat



-- ZFC Axioms (represented as axioms in Lean)
namespace ZFC

axiom extensionality : ∀ {α : Type} (x y : Set α), (∀ z, z ∈ x ↔ z ∈ y) → x = y

axiom pairing : ∀ {α : Type} (x y : α), ∃ z : Set α, ∀ w, w ∈ z ↔ w = x ∨ w = y

axiom union : ∀ {α : Type} (X : Set (Set α)), ∃ Y : Set α, ∀ u, u ∈ Y ↔ ∃ Z, u ∈ Z ∧ Z ∈ X

axiom infinity : ∃ S : Set ℕ, ∅ ∈ S ∧ ∀ x, x ∈ S → x ∪ {x} ∈ S

axiom power_set : ∀ {α : Type} (X : Set α), ∃ Y : Set (Set α), ∀ Z : Set α, Z ⊆ X → Z ∈ Y

axiom replacement : ∀ {α β : Type} (A : Set α) (φ : α → β → Prop),
  (∀ x ∈ A, ∃! y, φ x y) → ∃ B : Set β, ∀ x ∈ A, ∃ y ∈ B, φ x y

axiom separation : ∀ {α : Type} (A : Set α) (φ : α → Prop),
  ∃ B : Set α, ∀ x, x ∈ B ↔ x ∈ A ∧ φ x

axiom foundation : ∀ {α : Type} (x : Set α), x ≠ ∅ → ∃ y ∈ x, y ∩ x = ∅

axiom choice : ∀ {α : Type} (X : Set (Set α)), ∅ ∉ X →
  ∃ f : Set α → α, (∀ Y ∈ X, f Y ∈ Y)

end ZFC

open ZFC



/-- def:inner.product
    Category: Metric/Norm -/
def inner.product : Prop :=
  forall u,v,w in ℋ, (u,v)=(v,u) and (αu+βv,w)=α(u,w)+β(v,w) and (u,u)≥0 and ((u,u)=0<->u=0)



/-- def:hilbert
    Category: Metric/Norm -/
def hilbert : Prop :=
  Complete(ℋ) and InnerProduct(ℋ)



/-- def:compact
    Category: Metric/Norm -/
def compact : Prop :=
  forall {Uα}, (Ksubset ∪Uα and Open(Uα)) -> exists Jsubset I, |J|<∞ and Ksubset ∪_{αin J}Uα



/-- def:domain
    Category: Set-Theoretic -/
def domain : Prop :=
  Open(Ω) and Connected(Ω)



/-- def:lipschitz
    Category: Metric/Norm -/
def lipschitz : Prop :=
  exists L>0, forall x,yin Ω, |u(x)-u(y)| ≤ L|x-y|



/-- thm:banach-alaoglu
    Category: Functional Analysis -/
theorem banach-alaoglu :
  forall X, NormedSpace(X) -> WeakStarCompact(Ḅ_{X*}(0,1), X*) :=
  sorry  -- Proof to be filled in



/-- thm:riesz
    Category: Hilbert Space -/
theorem riesz :
  forall fin ℋ*, exists !hin ℋ, forall vin ℋ, (h,v)=⟨f,v⟩ :=
  sorry  -- Proof to be filled in



/-- thm:projection
    Category: Hilbert Space -/
theorem projection :
  forall Ksubset ℋ, Closed(K)and Convex(K)and K≠∅ -> forall hin ℋ, exists !uin K, P_K(h)=u :=
  sorry  -- Proof to be filled in



/-- thm:lax.milgram
    Category: Hilbert Space -/
theorem lax.milgram :
  forall a:ℋ×ℋ->ℝ, Bilinear(a)and Continuous(a)and Coercive(a) -> forall fin ℋ*, exists !uin ℋ, a(u,v)=⟨f,v⟩ :=
  sorry  -- Proof to be filled in
