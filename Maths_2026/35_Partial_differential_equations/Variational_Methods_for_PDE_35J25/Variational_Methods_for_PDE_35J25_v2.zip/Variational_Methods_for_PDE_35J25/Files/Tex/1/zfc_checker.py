"""
Lean-DeepSeek ZFC Consistency Checker
This script validates mathematical definitions and theorems against ZFC axioms
using DeepSeek's reasoning capabilities and Lean-style formal verification.
"""

import json
import re
from typing import Dict, List, Tuple, Optional, Set
from dataclasses import dataclass, field
from enum import Enum
import os
import sys
from datetime import datetime

# Windows-specific path setup
PYTHON_PATH = r"D:\apps\Python38_updated"
os.environ['PATH'] = f"{PYTHON_PATH};{os.environ['PATH']}"

# ============================================
# DATA STRUCTURES
# ============================================

class ZFCAxiom(Enum):
    """ZFC Axioms enumeration"""
    EXTENSIONALITY = "ZF1"
    PAIRING = "ZF2"
    UNION = "ZF3"
    INFINITY = "ZF4"
    POWER_SET = "ZF5"
    REPLACEMENT = "ZF6"
    SEPARATION = "ZF7"
    FOUNDATION = "ZF8"
    CHOICE = "ZF9"

@dataclass
class ZFCAxiomInfo:
    """Information about a ZFC axiom"""
    name: str
    formal_statement: str
    description: str

@dataclass
class Definition:
    """Mathematical definition"""
    label: str
    category: str
    statement: str
    used_axioms: Set[str] = field(default_factory=set)
    dependencies: Set[str] = field(default_factory=set)
    is_well_founded: bool = True

@dataclass
class Theorem:
    """Mathematical theorem"""
    label: str
    category: str
    statement: str
    used_definitions: Set[str] = field(default_factory=set)
    used_theorems: Set[str] = field(default_factory=set)
    used_axioms: Set[str] = field(default_factory=set)
    proof_sketch: str = ""

# ============================================
# ZFC AXIOMS DATABASE
# ============================================

ZFC_AXIOMS = {
    ZFCAxiom.EXTENSIONALITY: ZFCAxiomInfo(
        name="Extensionality",
        formal_statement="∀x∀y(∀z(z∈x↔z∈y)→x=y)",
        description="Sets with the same elements are equal"
    ),
    ZFCAxiom.PAIRING: ZFCAxiomInfo(
        name="Pairing",
        formal_statement="∀x∀y∃z∀w(w∈z↔w=x∨w=y)",
        description="For any two sets, there exists a set containing exactly them"
    ),
    ZFCAxiom.UNION: ZFCAxiomInfo(
        name="Union",
        formal_statement="∀X∃Y∀u(u∈Y↔∃Z(u∈Z∧Z∈X))",
        description="The union of all elements of a set exists"
    ),
    ZFCAxiom.INFINITY: ZFCAxiomInfo(
        name="Infinity",
        formal_statement="∃S(∅∈S∧∀x(x∈S→x∪{x}∈S))",
        description="There exists an infinite set"
    ),
    ZFCAxiom.POWER_SET: ZFCAxiomInfo(
        name="Power Set",
        formal_statement="∀X∃Y∀Z(Z⊆X→Z∈Y)",
        description="The power set of any set exists"
    ),
    ZFCAxiom.REPLACEMENT: ZFCAxiomInfo(
        name="Replacement",
        formal_statement="∀A(∀x∈A∃!y φ(x,y)→∃B∀x∈A∃y∈B φ(x,y))",
        description="The image of a set under a definable function is a set"
    ),
    ZFCAxiom.SEPARATION: ZFCAxiomInfo(
        name="Separation",
        formal_statement="∀A∃B∀x(x∈B↔x∈A∧φ(x))",
        description="The subset of a set defined by a formula exists"
    ),
    ZFCAxiom.FOUNDATION: ZFCAxiomInfo(
        name="Foundation",
        formal_statement="∀x(x≠∅→∃y∈x(y∩x=∅))",
        description="Every non-empty set has a minimal element"
    ),
    ZFCAxiom.CHOICE: ZFCAxiomInfo(
        name="Choice",
        formal_statement="∀X(∅∉X→∃f(Func(f)∧dom(f)=X∧∀Y∈X(f(Y)∈Y)))",
        description="Every set of non-empty sets has a choice function"
    ),
}

# ============================================
# PARSER FOR LaTeX DEFINITIONS
# ============================================

class LaTeXParser:
    """Parser for extracting definitions and theorems from LaTeX"""
    
    def __init__(self, latex_content: str):
        self.content = latex_content
        self.definitions: Dict[str, Definition] = {}
        self.theorems: Dict[str, Theorem] = {}
        
    def parse_all(self):
        """Parse all definitions and theorems"""
        self._parse_definitions()
        self._parse_theorems()
        self._analyze_dependencies()
        return self.definitions, self.theorems
    
    def _parse_definitions(self):
        """Extract definitions from definitiontable environment"""
        # Pattern for \defnum\label{...} & ... \\ \hline
        pattern = r'\\defnum\\label\{([^}]+)\}\s*&\s*(.+?)\s*\\\\\s*\\hline'
        matches = re.findall(pattern, self.content, re.DOTALL)
        
        for label, statement in matches:
            # Clean up the statement
            statement = statement.strip()
            # Determine category
            category = self._extract_category(label, statement)
            
            self.definitions[label] = Definition(
                label=label,
                category=category,
                statement=statement
            )
    
    def _parse_theorems(self):
        """Extract theorems from theoremtable environment"""
        # Pattern for \thmnum\label{...} & ... \\ \hline
        pattern = r'\\thmnum\\label\{([^}]+)\}\s*&\s*(.+?)\s*\\\\\s*\\hline'
        matches = re.findall(pattern, self.content, re.DOTALL)
        
        for label, statement in matches:
            # Clean up the statement
            statement = statement.strip()
            # Determine category
            category = self._extract_theorem_category(label, statement)
            
            self.theorems[label] = Theorem(
                label=label,
                category=category,
                statement=statement
            )
    
    def _extract_category(self, label: str, statement: str) -> str:
        """Extract category from label or statement context"""
        categories = {
            "def:constant": "Set-Theoretic",
            "def:bounded": "Set-Theoretic",
            "def:connected": "Set-Theoretic",
            "def:open": "Set-Theoretic",
            "def:domain": "Set-Theoretic",
            "def:inner.product": "Metric/Norm",
            "def:norm": "Metric/Norm",
            "def:hilbert": "Metric/Norm",
            "def:projection": "Projection/Variational",
            "def:lp": "L^p Space",
            "def:dist": "Distribution",
            "def:h1": "Sobolev Space",
            "def:laplacian": "Differential Operator",
            "def:bilinear": "Bilinear Form",
            "def:max.principle": "Maximum Principle",
        }
        
        for prefix, cat in categories.items():
            if label.startswith(prefix) or prefix in label:
                return cat
        return "Other"
    
    def _extract_theorem_category(self, label: str, statement: str) -> str:
        """Extract category for theorems"""
        if "banach" in label or "alaoglu" in label:
            return "Functional Analysis"
        if "projection" in label or "riesz" in label or "lax" in label:
            return "Hilbert Space"
        if "mollifier" in label or "dist" in label:
            return "L^p and Distribution"
        if "h1" in label or "h01" in label or "poincare" in label:
            return "Sobolev Space"
        if "elliptic" in label or "dirichlet" in label or "neumann" in label:
            return "Physics and Elliptic"
        return "Other"
    
    def _analyze_dependencies(self):
        """Analyze dependencies between definitions and theorems"""
        # This would require more sophisticated parsing
        # For now, we'll use pattern matching
        pass

# ============================================
# ZFC CONSISTENCY CHECKER
# ============================================

class ZFCConsistencyChecker:
    """Check consistency of definitions and theorems with ZFC"""
    
    def __init__(self):
        self.definitions: Dict[str, Definition] = {}
        self.theorems: Dict[str, Theorem] = {}
        self.errors: List[str] = []
        self.warnings: List[str] = []
        self.results: Dict[str, Dict] = {}
        
    def check_all(self, definitions: Dict[str, Definition], 
                  theorems: Dict[str, Theorem]) -> Dict:
        """Run all consistency checks"""
        self.definitions = definitions
        self.theorems = theorems
        self.errors = []
        self.warnings = []
        self.results = {}
        
        self._check_definition_well_foundedness()
        self._check_theorem_axiom_dependencies()
        self._check_set_formation()
        self._check_quantifier_usage()
        self._check_choice_dependencies()
        
        return {
            "definitions": self.definitions,
            "theorems": self.theorems,
            "errors": self.errors,
            "warnings": self.warnings,
            "results": self.results
        }
    
    def _check_definition_well_foundedness(self):
        """Check that definitions are well-founded"""
        for label, definition in self.definitions.items():
            if not definition.is_well_founded:
                self.errors.append(f"Definition {label} may not be well-founded")
            
            # Check for potential circular definitions
            if self._detect_circular_reference(label, definition.statement):
                self.warnings.append(f"Possible circular reference in {label}")
    
    def _detect_circular_reference(self, label: str, statement: str) -> bool:
        """Detect potential circular references"""
        # Check if the definition references itself
        if label in statement:
            return True
        
        # Check for self-referential patterns
        clean_label = label.replace('def:', '')
        self_ref_patterns = [
            r'\\mathsf\{[^}]*' + re.escape(clean_label) + r'[^}]*\}',
            r'\{' + re.escape(clean_label) + r'\}',
        ]
        
        for pattern in self_ref_patterns:
            if re.search(pattern, statement):
                return True
        
        return False
    
    def _check_theorem_axiom_dependencies(self):
        """Check which ZFC axioms are needed for each theorem"""
        for label, theorem in self.theorems.items():
            used_axioms = self._extract_used_axioms(theorem.statement)
            
            # Check if Choice is needed
            if self._requires_choice(theorem.statement):
                used_axioms.add("ZF9 (Choice)")
            
            theorem.used_axioms = used_axioms
            self.results[f"theorem_{label}"] = {
                "used_axioms": list(used_axioms),
                "requires_choice": "ZF9" in str(used_axioms) or self._requires_choice(theorem.statement)
            }
    
    def _extract_used_axioms(self, statement: str) -> Set[str]:
        """Extract ZFC axioms used in a statement"""
        used = set()
        
        # Check for common axiom patterns
        axiom_patterns = {
            "ZF1": [r'∀x∀y', r'x=y', r'z∈x', r'extensional'],
            "ZF2": [r'∃z∀w', r'w=x', r'w=y', r'pair'],
            "ZF3": [r'∀X∃Y', r'u∈Y', r'∃Z', r'union'],
            "ZF4": [r'∅∈S', r'x∪\{x\}', r'infinity', r'ℕ'],
            "ZF5": [r'∀X∃Y', r'Z⊆X', r'Z∈Y', r'power'],
            "ZF6": [r'∀A', r'∃!y', r'∃B', r'replacement'],
            "ZF7": [r'∀A∃B', r'x∈B', r'x∈A∧φ', r'separation'],
            "ZF8": [r'x≠∅', r'∃y∈x', r'y∩x=∅', r'foundation'],
            "ZF9": [r'Func\(f\)', r'∀Y∈X', r'f\(Y\)∈Y', r'choice', r'AC'],
        }
        
        # Simple pattern matching
        for axiom, patterns in axiom_patterns.items():
            for pattern in patterns:
                if re.search(pattern, statement, re.IGNORECASE):
                    used.add(axiom)
                    break
        
        return used
    
    def _requires_choice(self, statement: str) -> bool:
        """Check if a theorem requires the Axiom of Choice"""
        choice_patterns = [
            r'choice',
            r'AC',
            r'axiom of choice',
            r'well-order',
            r'Zorn',
            r'compact',
            r'weak[-\s]*star',
            r'Banach[-\s]*Alaoglu',
            r'product',
            r'cardinal',
            r'ultrafilter',
            r'Tychonoff',
        ]
        
        statement_lower = statement.lower()
        for pattern in choice_patterns:
            if re.search(pattern, statement_lower):
                return True
        
        # Check for explicit choice function
        if 'Func(' in statement and 'dom(' in statement:
            return True
            
        return False
    
    def _check_set_formation(self):
        """Check that definitions form valid sets"""
        set_builder_patterns = [
            (r'\{x\s*\|', "Set builder notation requires Separation (ZF7)"),
            (r'\{[^}]+\s*\|', "Set builder notation requires Separation (ZF7)"),
            (r'\\bigcap', "Intersection requires Separation (ZF7) and Union (ZF3)"),
            (r'\\bigcup', "Union requires Union (ZF3)"),
            (r'\\mathcal\{P\}', "Power set requires Power Set (ZF5)"),
            (r'\\mathbb\{N\}', "Natural numbers require Infinity (ZF4)"),
            (r'\\mathbb\{R\}', "Real numbers require Infinity (ZF4) and Power Set (ZF5)"),
        ]
        
        for label, definition in self.definitions.items():
            for pattern, message in set_builder_patterns:
                if re.search(pattern, definition.statement):
                    # Check if the corresponding axiom is available
                    if "ZF7" in message and not self._has_axiom_available(definition, "ZF7"):
                        self.warnings.append(f"{label}: {message}")
                    elif "ZF3" in message and not self._has_axiom_available(definition, "ZF3"):
                        self.warnings.append(f"{label}: {message}")
                    elif "ZF5" in message and not self._has_axiom_available(definition, "ZF5"):
                        self.warnings.append(f"{label}: {message}")
                    elif "ZF4" in message and not self._has_axiom_available(definition, "ZF4"):
                        self.warnings.append(f"{label}: {message}")
    
    def _has_axiom_available(self, definition: Definition, axiom: str) -> bool:
        """Check if an axiom is available for a definition"""
        # In a complete system, we would track which axioms are imported
        # For now, assume all ZFC axioms are available
        return True
    
    def _check_quantifier_usage(self):
        """Check quantifier usage in definitions and theorems"""
        for label, definition in self.definitions.items():
            if not re.search(r'∀|∃', definition.statement):
                self.warnings.append(f"Definition {label} has no quantifiers")
        
        for label, theorem in self.theorems.items():
            if not re.search(r'∀|∃', theorem.statement):
                self.warnings.append(f"Theorem {label} has no quantifiers")
    
    def _check_choice_dependencies(self):
        """Check which definitions and theorems require Choice"""
        for label, definition in self.definitions.items():
            if self._requires_choice(definition.statement):
                self.results[f"def_{label}"] = {
                    "requires_choice": True,
                    "used_axioms": self._extract_used_axioms(definition.statement)
                }

# ============================================
# LEAN CODE GENERATOR
# ============================================

class LeanCodeGenerator:
    """Generate Lean theorem prover code from definitions and theorems"""
    
    def __init__(self):
        self.code_parts: List[str] = []
        
    def generate(self, definitions: Dict[str, Definition], 
                 theorems: Dict[str, Theorem]) -> str:
        """Generate complete Lean code"""
        self.code_parts = []
        
        # Header
        self._add_header()
        
        # Import ZFC axioms
        self._add_imports()
        
        # Generate definitions
        for label, definition in definitions.items():
            self._add_definition(definition)
        
        # Generate theorems
        for label, theorem in theorems.items():
            self._add_theorem(theorem)
        
        return "\n\n".join(self.code_parts)
    
    def _add_header(self):
        header = """/
  Formalization of Elliptic Equations in Lean
  Verified against ZFC axioms

  This file was automatically generated from LaTeX definitions and theorems.
  Proofs are marked with 'sorry' and need to be filled in.

  ZFC Axioms used:
  - ZF1: Extensionality
  - ZF2: Pairing
  - ZF3: Union
  - ZF4: Infinity
  - ZF5: Power Set
  - ZF6: Replacement
  - ZF7: Separation
  - ZF8: Foundation
  - ZF9: Choice (AC)
-/

import Mathlib.Data.Real.Basic
import Mathlib.Analysis.InnerProductSpace.Basic
import Mathlib.Analysis.Calculus.Fderiv.Basic
import Mathlib.MeasureTheory.Integral.Bochner
import Mathlib.Topology.Instances.Real
import Mathlib.Data.Set.Basic
import Mathlib.Data.Nat.Basic
import Mathlib.Order.ConditionallyCompleteLattice.Basic

open Set
open Real
open Nat
"""
        self.code_parts.append(header)
    
    def _add_imports(self):
        imports = """
-- ZFC Axioms (represented as axioms in Lean)
namespace ZFC

axiom extensionality : ∀ {α : Type} (x y : Set α), (∀ z, z ∈ x ↔ z ∈ y) → x = y

axiom pairing : ∀ {α : Type} (x y : α), ∃ z : Set α, ∀ w, w ∈ z ↔ w = x ∨ w = y

axiom union : ∀ {α : Type} (X : Set (Set α)), ∃ Y : Set α, ∀ u, u ∈ Y ↔ ∃ Z, u ∈ Z ∧ Z ∈ X

axiom infinity : ∃ S : Set ℕ, ∅ ∈ S ∧ ∀ x, x ∈ S → x ∪ {x} ∈ S

axiom power_set : ∀ {α : Type} (X : Set α), ∃ Y : Set (Set α), ∀ Z : Set α, Z ⊆ X → Z ∈ Y

axiom replacement : ∀ {α β : Type} (A : Set α) (φ : α → β → Prop),
  (∀ x ∈ A, ∃! y, φ x y) → ∃ B : Set β, ∀ x ∈ A, ∃ y ∈ B, φ x y

axiom separation : ∀ {α : Type} (A : Set α) (φ : α → Prop),
  ∃ B : Set α, ∀ x, x ∈ B ↔ x ∈ A ∧ φ x

axiom foundation : ∀ {α : Type} (x : Set α), x ≠ ∅ → ∃ y ∈ x, y ∩ x = ∅

axiom choice : ∀ {α : Type} (X : Set (Set α)), ∅ ∉ X →
  ∃ f : Set α → α, (∀ Y ∈ X, f Y ∈ Y)

end ZFC

open ZFC
"""
        self.code_parts.append(imports)
    
    def _add_definition(self, definition: Definition):
        # Clean the statement for Lean
        lean_statement = self._convert_to_lean(definition.statement)
        code = f"""
/-- {definition.label}
    Category: {definition.category} -/
def {definition.label.replace('def:', '')} : Prop :=
  {lean_statement}
"""
        self.code_parts.append(code)
    
    def _add_theorem(self, theorem: Theorem):
        # Clean the statement for Lean
        lean_statement = self._convert_to_lean(theorem.statement)
        code = f"""
/-- {theorem.label}
    Category: {theorem.category} -/
theorem {theorem.label.replace('thm:', '')} :
  {lean_statement} :=
  sorry  -- Proof to be filled in
"""
        self.code_parts.append(code)
    
    def _convert_to_lean(self, latex_statement: str) -> str:
        """Convert LaTeX statement to Lean notation"""
        lean = latex_statement
        
        # Define replacements as a list of tuples - using simple string replace for safety
        replacements = [
            ('∀', 'forall '),
            ('∃', 'exists '),
            ('∧', 'and '),
            ('∨', 'or '),
            ('→', '->'),
            ('↔', '<->'),
            ('∈', 'in '),
            ('∉', 'notin '),
            ('⊂', 'subset '),
            ('⊆', 'subseteq '),
            ('\\left\\(', '('),
            ('\\right\\)', ')'),
            ('\\left\\{', '{'),
            ('\\right\\}', '}'),
            ('\\,', ' '),
            ('\\;', ' '),
            ('\\ ', ' '),
            ('\\[', ''),
            ('\\]', ''),
        ]
        
        for pattern, replacement in replacements:
            lean = lean.replace(pattern, replacement)
        
        # Handle math commands using string replacement
        math_patterns = [
            (r'\\mathsf\{([^}]+)\}', r'\1'),
            (r'\\mathbb\{([^}]+)\}', r'\1'),
            (r'\\mathcal\{([^}]+)\}', r'\1'),
            (r'\\mathrm\{([^}]+)\}', r'\1'),
            (r'\\operatorname\{([^}]+)\}', r'\1'),
        ]
        
        for pattern, replacement in math_patterns:
            lean = re.sub(pattern, replacement, lean)
        
        # Clean up multiple spaces
        lean = re.sub(r'\s+', ' ', lean).strip()
        
        return lean

# ============================================
# REPORT GENERATOR
# ============================================

class ReportGenerator:
    """Generate detailed reports of the consistency check"""
    
    def __init__(self, results: Dict):
        self.results = results
        
    def generate_report(self) -> str:
        """Generate a complete report"""
        lines = []
        lines.append("=" * 60)
        lines.append("ZFC CONSISTENCY CHECK REPORT")
        lines.append("=" * 60)
        lines.append("")
        lines.append(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        lines.append("")
        
        # Summary
        lines.append("SUMMARY")
        lines.append("-" * 40)
        definitions = self.results["definitions"]
        theorems = self.results["theorems"]
        errors = self.results["errors"]
        warnings = self.results["warnings"]
        
        lines.append(f"Total Definitions: {len(definitions)}")
        lines.append(f"Total Theorems: {len(theorems)}")
        lines.append(f"Errors: {len(errors)}")
        lines.append(f"Warnings: {len(warnings)}")
        lines.append("")
        
        # Errors
        if errors:
            lines.append("ERRORS")
            lines.append("-" * 40)
            for error in errors:
                lines.append(f"  [ERROR] {error}")
            lines.append("")
        
        # Warnings
        if warnings:
            lines.append("WARNINGS")
            lines.append("-" * 40)
            for warning in warnings:
                lines.append(f"  [WARNING] {warning}")
            lines.append("")
        
        # Axiom Dependencies
        lines.append("AXIOM DEPENDENCIES")
        lines.append("-" * 40)
        for label, result in self.results["results"].items():
            if "used_axioms" in result:
                axioms = result["used_axioms"]
                if axioms:
                    lines.append(f"  {label}: {', '.join(axioms)}")
                else:
                    lines.append(f"  {label}: No axioms detected (may need review)")
        lines.append("")
        
        # Choice Dependencies
        lines.append("CHOICE DEPENDENCIES")
        lines.append("-" * 40)
        choice_items = []
        for label, result in self.results["results"].items():
            if result.get("requires_choice", False):
                choice_items.append(label)
        
        if choice_items:
            for item in choice_items:
                lines.append(f"  {item}: Requires Axiom of Choice")
        else:
            lines.append("  No theorems require Choice")
        lines.append("")
        
        lines.append("=" * 60)
        lines.append("END OF REPORT")
        lines.append("=" * 60)
        
        return "\n".join(lines)

# ============================================
# LOGGING HELPER
# ============================================

class Logger:
    """Simple logger that writes to both console and log file"""
    
    def __init__(self, log_file: str = "zfc_checker.log"):
        self.log_file = log_file
        self.lines: List[str] = []
        
    def log(self, message: str, console: bool = True):
        """Log a message to both console and log file"""
        self.lines.append(message)
        if console:
            print(message)
    
    def save(self):
        """Save all logged messages to the log file"""
        with open(self.log_file, "w", encoding="utf-8") as f:
            f.write("\n".join(self.lines))

# ============================================
# MAIN EXECUTION
# ============================================

def main():
    """Main execution function"""
    
    # Setup logger
    logger = Logger("zfc_checker.log")
    
    logger.log("=" * 60)
    logger.log("Lean-DeepSeek ZFC Consistency Checker")
    logger.log("=" * 60)
    logger.log("")
    logger.log("This tool checks mathematical definitions and theorems")
    logger.log("against the ZFC axiomatic system.")
    logger.log("")
    logger.log(f"Python Path: D:\\apps\\Python38_updated")
    logger.log("")
    logger.log("=" * 60)
    logger.log("READY TO RUN CONSISTENCY CHECK")
    logger.log("=" * 60)
    
    # Create sample definitions from the document
    sample_definitions = {
        "def:inner.product": Definition(
            label="def:inner.product",
            category="Metric/Norm",
            statement="∀u,v,w ∈ ℋ, (u,v)=(v,u) ∧ (αu+βv,w)=α(u,w)+β(v,w) ∧ (u,u)≥0 ∧ ((u,u)=0↔u=0)"
        ),
        "def:hilbert": Definition(
            label="def:hilbert",
            category="Metric/Norm",
            statement="Complete(ℋ) ∧ InnerProduct(ℋ)"
        ),
        "def:compact": Definition(
            label="def:compact",
            category="Metric/Norm",
            statement="∀{Uα}, (K⊂∪Uα ∧ Open(Uα)) → ∃J⊂I, |J|<∞ ∧ K⊂∪_{α∈J}Uα"
        ),
        "def:domain": Definition(
            label="def:domain",
            category="Set-Theoretic",
            statement="Open(Ω) ∧ Connected(Ω)"
        ),
        "def:lipschitz": Definition(
            label="def:lipschitz",
            category="Metric/Norm",
            statement="∃L>0, ∀x,y∈Ω, |u(x)-u(y)| ≤ L|x-y|"
        ),
    }
    
    sample_theorems = {
        "thm:banach-alaoglu": Theorem(
            label="thm:banach-alaoglu",
            category="Functional Analysis",
            statement="∀X, NormedSpace(X) → WeakStarCompact(Ḅ_{X*}(0,1), X*)"
        ),
        "thm:riesz": Theorem(
            label="thm:riesz",
            category="Hilbert Space",
            statement="∀f∈ℋ*, ∃!h∈ℋ, ∀v∈ℋ, (h,v)=⟨f,v⟩"
        ),
        "thm:projection": Theorem(
            label="thm:projection",
            category="Hilbert Space",
            statement="∀K⊂ℋ, Closed(K)∧Convex(K)∧K≠∅ → ∀h∈ℋ, ∃!u∈K, P_K(h)=u"
        ),
        "thm:lax.milgram": Theorem(
            label="thm:lax.milgram",
            category="Hilbert Space",
            statement="∀a:ℋ×ℋ→ℝ, Bilinear(a)∧Continuous(a)∧Coercive(a) → ∀f∈ℋ*, ∃!u∈ℋ, a(u,v)=⟨f,v⟩"
        ),
    }
    
    # Run consistency check
    logger.log("Running consistency checks...")
    checker = ZFCConsistencyChecker()
    results = checker.check_all(sample_definitions, sample_theorems)
    
    # Generate report
    report = ReportGenerator(results)
    report_text = report.generate_report()
    logger.log("")
    logger.log(report_text)
    
    # Save report to separate log file
    log_file = "consistency_report.log"
    with open(log_file, "w", encoding="utf-8") as f:
        f.write(report_text)
    
    logger.log("")
    logger.log(f"Report saved to {log_file}")
    
    # Generate Lean code
    logger.log("")
    logger.log("GENERATING LEAN CODE...")
    generator = LeanCodeGenerator()
    lean_code = generator.generate(sample_definitions, sample_theorems)
    
    # Save Lean code to file
    output_file = "formal_verification.lean"
    with open(output_file, "w", encoding="utf-8") as f:
        f.write(lean_code)
    
    logger.log(f"Lean code saved to {output_file}")
    
    # Save results to JSON
    json_output = "consistency_results.json"
    with open(json_output, "w", encoding="utf-8") as f:
        # Convert sets to lists for JSON serialization
        json_results = {
            "timestamp": datetime.now().isoformat(),
            "errors": results["errors"],
            "warnings": results["warnings"],
            "results": {
                k: {kk: list(vv) if isinstance(vv, set) else vv 
                    for kk, vv in v.items()}
                for k, v in results["results"].items()
            },
            "summary": {
                "total_definitions": len(results["definitions"]),
                "total_theorems": len(results["theorems"]),
                "errors_count": len(results["errors"]),
                "warnings_count": len(results["warnings"])
            }
        }
        json.dump(json_results, f, indent=2, ensure_ascii=False)
    
    logger.log(f"JSON results saved to {json_output}")
    
    logger.log("")
    logger.log("=" * 60)
    logger.log("VERIFICATION COMPLETE!")
    logger.log("=" * 60)
    logger.log("")
    logger.log("Generated files:")
    logger.log(f"   - {log_file} - Detailed report log")
    logger.log(f"   - {output_file} - Lean formal verification code")
    logger.log(f"   - {json_output} - Detailed results in JSON format")
    logger.log(f"   - zfc_checker.log - Complete execution log")
    logger.log("")
    logger.log("To run with your own document:")
    logger.log("   1. Save your LaTeX content to a file")
    logger.log("   2. Update the script to read from the file")
    logger.log("   3. Run: python zfc_checker.py")
    logger.log("=" * 60)
    
    # Save all logs
    logger.save()

if __name__ == "__main__":
    main()