@echo off
chcp 65001 >nul
D:\apps\Python38_updated\python.exe zfc_checker.py > output.txt 2>&1
pause