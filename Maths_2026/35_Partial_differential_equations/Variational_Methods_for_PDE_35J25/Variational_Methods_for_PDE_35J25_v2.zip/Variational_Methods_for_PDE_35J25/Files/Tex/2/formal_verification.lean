/
  Formalization of Elliptic Equations in Lean
  Verified against ZFC axioms

  This file was automatically generated from LaTeX definitions and theorems.
  Proofs are marked with 'sorry' and need to be filled in.

  ZFC Axioms used:
  - ZF1: Extensionality
  - ZF2: Pairing
  - ZF3: Union
  - ZF4: Infinity
  - ZF5: Power Set
  - ZF6: Replacement
  - ZF7: Separation
  - ZF8: Foundation
  - ZF9: Choice (AC)
-/

import Mathlib.Data.Real.Basic
import Mathlib.Analysis.InnerProductSpace.Basic
import Mathlib.Analysis.Calculus.Fderiv.Basic
import Mathlib.MeasureTheory.Integral.Bochner
import Mathlib.Topology.Instances.Real
import Mathlib.Data.Set.Basic
import Mathlib.Data.Nat.Basic
import Mathlib.Order.ConditionallyCompleteLattice.Basic

open Set
open Real
open Nat



-- ZFC Axioms (represented as axioms in Lean)
namespace ZFC

axiom extensionality : ∀ {α : Type} (x y : Set α), (∀ z, z ∈ x ↔ z ∈ y) → x = y

axiom pairing : ∀ {α : Type} (x y : α), ∃ z : Set α, ∀ w, w ∈ z ↔ w = x ∨ w = y

axiom union : ∀ {α : Type} (X : Set (Set α)), ∃ Y : Set α, ∀ u, u ∈ Y ↔ ∃ Z, u ∈ Z ∧ Z ∈ X

axiom infinity : ∃ S : Set ℕ, ∅ ∈ S ∧ ∀ x, x ∈ S → x ∪ {x} ∈ S

axiom power_set : ∀ {α : Type} (X : Set α), ∃ Y : Set (Set α), ∀ Z : Set α, Z ⊆ X → Z ∈ Y

axiom replacement : ∀ {α β : Type} (A : Set α) (φ : α → β → Prop),
  (∀ x ∈ A, ∃! y, φ x y) → ∃ B : Set β, ∀ x ∈ A, ∃ y ∈ B, φ x y

axiom separation : ∀ {α : Type} (A : Set α) (φ : α → Prop),
  ∃ B : Set α, ∀ x, x ∈ B ↔ x ∈ A ∧ φ x

axiom foundation : ∀ {α : Type} (x : Set α), x ≠ ∅ → ∃ y ∈ x, y ∩ x = ∅

axiom choice : ∀ {α : Type} (X : Set (Set α)), ∅ ∉ X →
  ∃ f : Set α → α, (∀ Y ∈ X, f Y ∈ Y)

end ZFC

open ZFC



/-- def:constant
    Category: Set-Theoretic -/
def constant : Prop :=
  $Constant(u) = ∃ C ∈ R, ∀ x ∈ Omega, u(x) = C$



/-- def:bounded
    Category: Set-Theoretic -/
def bounded : Prop :=
  $Bounded(Omega) = ∃ R>0, Omega ⊂ B_R(0)$



/-- def:bounded.seq
    Category: Set-Theoretic -/
def bounded.seq : Prop :=
  $Bounded(\{u_n\}) = ∃ C>0, ∀ n ∈ N, \|u_n\| \leq C$



/-- def:connected
    Category: Set-Theoretic -/
def connected : Prop :=
  $Connected(Omega) = \nexists U,V ⊂ Omega, Open(U) ∧ Open(V) ∧ U ∩ V = ∅ ∧ U ∪ V = Omega$



/-- def:open
    Category: Set-Theoretic -/
def open : Prop :=
  $Open(Omega) = ∀ x ∈ Omega, ∃ \epsilon > 0, B_\epsilon(x) ⊂ Omega$



/-- def:domain
    Category: Set-Theoretic -/
def domain : Prop :=
  $Domain(Omega) = Open(Omega) ∧ Connected(Omega)$



/-- def:orthant
    Category: Other -/
def orthant : Prop :=
  $Orthant = \{x ∈ R^n \mid x_i \geq 0 ∀ i = 1,\ldots,n\}$



/-- def:triangle
    Category: Other -/
def triangle : Prop :=
  $Triangle(T) = ∃ A,B,C ∈ R^2, T = conv\{A,B,C\}$



/-- def:symmetric
    Category: Other -/
def symmetric : Prop :=
  $Symmetric(A) = A = A^T$



/-- def:support
    Category: Other -/
def support : Prop :=
  $Supp(\rho) = \overline{\{x ∈ Omega \mid \rho(x) \neq 0\}}$



/-- def:translation
    Category: Other -/
def translation : Prop :=
  $(\sigma_h f)(x) = f(x+h)$



/-- def:convolution
    Category: Other -/
def convolution : Prop :=
  $(f * g)(x) = ∈t_{R^n} f(y)g(x-y) dy$



/-- def:average
    Category: Other -/
def average : Prop :=
  $\fint_Omega f = \frac{1}{|Omega|}∈t_Omega f(x) dx$



/-- def:max.op
    Category: Other -/
def max.op : Prop :=
  $Max(u,v) = u ∨ v$



/-- def:min.op
    Category: Other -/
def min.op : Prop :=
  $Min(u,v) = u ∧ v$



/-- def:pos.part
    Category: Other -/
def pos.part : Prop :=
  $u^+ = u ∨ 0$



/-- def:neg.part
    Category: Other -/
def neg.part : Prop :=
  $u^- = (-u) ∨ 0$



/-- def:abs.value
    Category: Other -/
def abs.value : Prop :=
  $|u| = u^+ + u^-$



/-- def:decomp
    Category: Other -/
def decomp : Prop :=
  $u = u^+ - u^-$



/-- def:abelian.group
    Category: Other -/
def abelian.group : Prop :=
  $AbelianGroup(X, +) = & ∀ x,y,z ∈ X, (x+y)+z = x+(y+z) ∧ x+y = y+x ∧\ & ∃ 0 ∈ X, ∀ x ∈ X, x+0 = x ∧ ∀ x ∈ X, ∃ (-x) ∈ X, x+(-x) = 0 $



/-- def:vector.space
    Category: Other -/
def vector.space : Prop :=
  $VectorSpace(X) = & AbelianGroup(X, +) ∧ ∃ \cdot: R \times X arrow X, ∀ \alpha,\beta ∈ R, ∀ x,y ∈ X, \ & (\alpha + \beta)\cdot x = \alpha\cdot x + \beta\cdot x ∧ \alpha\cdot(x + y) = \alpha\cdot x + \alpha\cdot y ∧\ & (\alpha\beta)\cdot x = \alpha\cdot(\beta\cdot x) ∧ 1\cdot x = x $



/-- def:inner.product
    Category: Metric/Norm -/
def inner.product : Prop :=
  $InnerProduct(H) = & ∀ u,v,w ∈ H, ∀ \alpha,\beta ∈ R, \ & (u,v)=(v,u)∧ (\alpha u+\beta v,w)=\alpha(u,w)+\beta(v,w) ∧ (u,u)\geq 0 ∧ ((u,u)=0 ↔ u=0)$



/-- def:norm
    Category: Metric/Norm -/
def norm : Prop :=
  $\|u\| = \sqrt{(u,u)}$



/-- def:cauchy.seq
    Category: Other -/
def cauchy.seq : Prop :=
  $CauchySeq(u_n) = ∀ \epsilon>0, ∃ N ∈ N, ∀ n,m \geq N, \|u_n-u_m\| < \epsilon$



/-- def:complete
    Category: Other -/
def complete : Prop :=
  $Complete(H) = ∀ CauchySeq(u_n), ∃ u ∈ H, u_n arrow u$



/-- def:hilbert
    Category: Metric/Norm -/
def hilbert : Prop :=
  $Hilbert(H) = Complete(H) ∧ InnerProduct(H)$



/-- def:closed
    Category: Other -/
def closed : Prop :=
  $Closed(K) = ∀ \{u_n\} ⊂ K, (u_n arrow u → u ∈ K)$



/-- def:convex
    Category: Other -/
def convex : Prop :=
  $Convex(K) = ∀ u,v ∈ K, ∀ \alpha ∈ [0,1], \alpha u + (1-\alpha)v ∈ K$



/-- def:subspace
    Category: Other -/
def subspace : Prop :=
  $Subspace(V) = 0 ∈ V ∧ ∀ u,v ∈ V, ∀ \alpha,\beta ∈ R, \alpha u + \beta v ∈ V$



/-- def:closed.subspace
    Category: Other -/
def closed.subspace : Prop :=
  $ClosedSubspace(V) = Subspace(V) ∧ Closed(V)$



/-- def:orthonormal
    Category: Other -/
def orthonormal : Prop :=
  $Orthonormal(\{u_i\}) = ∀ i,j, (u_i,u_j) = \delta_{ij}$



/-- def:linear.independent
    Category: Other -/
def linear.independent : Prop :=
  $LinearlyIndependent(\{u_i\}) = \sum_{i=1}^n \alpha_i u_i = 0 → ∀ i, \alpha_i = 0$



/-- def:basis
    Category: Other -/
def basis : Prop :=
  $Basis(\{u_i\}) = Orthonormal(\{u_i\}) ∧ \overline{span\{u_i\}} = H$



/-- def:separable
    Category: Other -/
def separable : Prop :=
  $Separable(H) = ∃ \{x_n\}_{n=1}^∈fty ⊂ H, \overline{\{x_n\}} = H$



/-- def:linear
    Category: Other -/
def linear : Prop :=
  $Linear(f) = ∀ \alpha,\beta ∈ R, ∀ u,v ∈ H, f(\alpha u+\beta v) = \alpha f(u) + \beta f(v)$



/-- def:continuous.func
    Category: Other -/
def continuous.func : Prop :=
  $Continuous(f) = ∃ C > 0, ∀ u ∈ H, |f(u)| \leq C\|u\|$



/-- def:dual
    Category: Other -/
def dual : Prop :=
  $H^* = \{ f: H arrow R \mid Linear(f) ∧ Continuous(f) \}$



/-- def:dual.norm
    Category: Other -/
def dual.norm : Prop :=
  $\|f\|_* = \sup_{u ∈ H, u \neq 0} \frac{|f(u)|}{\|u\|}$



/-- def:lipschitz
    Category: Other -/
def lipschitz : Prop :=
  $Lipschitz(u) = ∃ L > 0, ∀ x,y ∈ Omega, |u(x)-u(y)| \leq L|x-y|$



/-- def:equicontinuous
    Category: Other -/
def equicontinuous : Prop :=
  $Equicontinuous(L,Omega') = ∀ \eta>0, ∃ \delta>0, ∀ h ∈ R^n, |h|<\delta → \|\sigma_h f - f\|_{p,Omega'} < \eta, ∀ f ∈ L$



/-- def:bounded.in.lp
    Category: Set-Theoretic -/
def bounded.in.lp : Prop :=
  $BoundedInLp(L,Omega) = ∃ C>0, ∀ f ∈ L, \|f\|_{p,Omega} \leq C$



/-- def:relatively.compact
    Category: Other -/
def relatively.compact : Prop :=
  $RelativelyCompact(L,Omega') = ∀ \{f_n\} ⊂ L, ∃ \{f_{n_k}\} ⊂ \{f_n\}, ∃ f ∈ L^p(Omega'), \|f_{n_k}-f\|_{p,Omega'} arrow 0$



/-- def:piecewise.c1
    Category: Other -/
def piecewise.c1 : Prop :=
  $PiecewiseC^1(f) = ∃ \{x_i\}_{i=1}^n ⊂ R, ∃ \{f_i\}_{i=1}^{n+1} ⊂ C^1(R), f = f_i \quad (x_i, x_{i+1})$



/-- def:compact.embedding
    Category: Other -/
def compact.embedding : Prop :=
  $CompactEmbedding(X, Y) = Compact(i: X arrow Y)$



/-- def:finite.dim
    Category: Other -/
def finite.dim : Prop :=
  $FiniteDim(V) = ∃ n ∈ N, \dim V = n$



/-- def:conv.hull
    Category: Other -/
def conv.hull : Prop :=
  $conv(S) = \bigcap\{K \mid S ⊂ K, K convex\}$



/-- def:indicator
    Category: Other -/
def indicator : Prop :=
  $\mathbf{1}_A(x) = 1$ if $x ∈ A$, $0$ otherwise



/-- def:characteristic
    Category: Other -/
def characteristic : Prop :=
  $\chi_A(x) = 1$ if $x ∈ A$, $0$ otherwise



/-- def:dual.ball
    Category: Other -/
def dual.ball : Prop :=
  $\overline{B}_{X^*}(0,C) = \{\phi ∈ X^* \mid \|\phi\|_* \leq C\}$



/-- def:compact
    Category: Other -/
def compact : Prop :=
  $Compact(K) = ∀ \{U_\alpha\}_{\alpha ∈ I}, (K ⊂ \bigcup_{\alpha ∈ I} U_\alpha ∧ ∀ \alpha ∈ I, Open(U_\alpha)) → ∃ J ⊂ I, |J| < ∈fty ∧ K ⊂ \bigcup_{\alpha ∈ J} U_\alpha$



/-- def:compact.seq
    Category: Other -/
def compact.seq : Prop :=
  $CompactSeq(K) = ∀ \{x_n\}_{n=1}^{∈fty} ⊂ K, ∃ \{x_{n_k}\}_{k=1}^{∈fty} ⊂ \{x_n\}_{n=1}^{∈fty}, ∃ x ∈ K, x_{n_k} arrow x$



/-- def:projection
    Category: Projection/Variational -/
def projection : Prop :=
  $P_K(h) = u = u ∈ K ∧ ∀ v ∈ K, \|h-u\| \leq \|h-v\|$



/-- def:var.ineq
    Category: Other -/
def var.ineq : Prop :=
  $VarIneq(u,h,K) = u ∈ K ∧ ∀ v ∈ K, (u-h, v-u) \geq 0$



/-- def:lp
    Category: L^p Space -/
def lp : Prop :=
  $L^p(Omega) = \{ v: Omega arrow R \mid ∈t_Omega |v|^p dx < ∈fty \}$



/-- def:lp.norm
    Category: L^p Space -/
def lp.norm : Prop :=
  $\|v\|_{p,Omega} = ( ∈t_Omega |v|^p dx )^{1/p}$



/-- def:lp.dual
    Category: L^p Space -/
def lp.dual : Prop :=
  $(L^p(Omega))^* \cong L^{p'}(Omega), \frac{1}{p} + \frac{1}{p'} = 1$



/-- def:lp.loc
    Category: L^p Space -/
def lp.loc : Prop :=
  $L_{loc}^p(Omega) = \{ v \mid ∀ Omega' ⊂⊂ Omega, v ∈ L^p(Omega') \}$



/-- def:holder
    Category: Other -/
def holder : Prop :=
  $∀ f ∈ L^p(Omega), g ∈ L^{p'}(Omega), ∈t_Omega |fg| dx \leq \|f\|_{p,Omega} \|g\|_{p',Omega}$



/-- def:mollifier
    Category: Other -/
def mollifier : Prop :=
  $\rho_\epsilon(x) = \epsilon^{-n} \rho(x/\epsilon), ∈t_{R^n} \rho_\epsilon dx = 1, Supp(\rho_\epsilon) = B_\epsilon(0)$



/-- def:mollifier.conv
    Category: Other -/
def mollifier.conv : Prop :=
  $MollifierConv(u_\epsilon, u, Omega') = (u_\epsilon arrow u) ∧ (u ∈ L^p(Omega')) = \|u_\epsilon - u\|_{p,Omega'} arrow 0$



/-- def:dist
    Category: Distribution -/
def dist : Prop :=
  $D'(Omega) = \{ T: D(Omega) arrow R \mid Linear(T) ∧ Continuous(T) \}$



/-- def:dist.derivative
    Category: Distribution -/
def dist.derivative : Prop :=
  $\langle D^\alpha T, \phi \rangle = (-1)^{|\alpha|} \langle T, D^\alpha \phi \rangle$



/-- def:dist.conv
    Category: Distribution -/
def dist.conv : Prop :=
  $DistConv(T_n, T, Omega) = (T_n arrow T) ∧ (T ∈ D'(Omega)) = ∀ \phi ∈ D(Omega), \langle T_n, \phi \rangle arrow \langle T, \phi \rangle$



/-- def:h1
    Category: Sobolev Space -/
def h1 : Prop :=
  $H^1(Omega) = \{ v ∈ L^2(Omega) \mid \partial_i v ∈ L^2(Omega), ∀ i \}$



/-- def:h1.norm
    Category: Sobolev Space -/
def h1.norm : Prop :=
  $\|v\|_{1,2} = ( ∈t_Omega |v|^2 + |\nabla v|^2 dx )^{1/2}$



/-- def:h01
    Category: Other -/
def h01 : Prop :=
  $H_0^1(Omega) = \overline{D(Omega)}^{\|\cdot\|_{1,2}}$



/-- def:hminus1
    Category: Other -/
def hminus1 : Prop :=
  $H^{-1}(Omega) = (H_0^1(Omega))^*$



/-- def:bounded.one.dir
    Category: Set-Theoretic -/
def bounded.one.dir : Prop :=
  $BoundedOneDir(Omega) = ∃ \nu ∈ R^n, |\nu|=1, ∃ a>0, Omega ⊂ \{ x ∈ R^n \mid |x\cdot\nu| \leq a \}$



/-- def:order.boundary
    Category: Other -/
def order.boundary : Prop :=
  $BoundaryOrder(u_1,u_2) = (u_1 - u_2)^+ ∈ H_0^1(Omega)$



/-- def:zero.boundary
    Category: Other -/
def zero.boundary : Prop :=
  $ZeroBoundary(u) = u ∈ H_0^1(Omega)$



/-- def:pos.neg.parts
    Category: Other -/
def pos.neg.parts : Prop :=
  $u^+ = u ∨ 0, u^- = (-u) ∨ 0, u = u^+ - u^-, |u| = u^+ + u^-$



/-- def:leq.in.omega
    Category: Other -/
def leq.in.omega : Prop :=
  $LeqInOmega(u_1, u_2) = ∀ x ∈ Omega, u_1(x) \leq u_2(x)$



/-- def:leq.on.boundary
    Category: Other -/
def leq.on.boundary : Prop :=
  $LeqOnBoundary(u_1, u_2) = ∀ x ∈ \partialOmega, u_1(x) \leq u_2(x)$



/-- def:strict.max
    Category: Other -/
def strict.max : Prop :=
  $StrictMax(u, x_0) = ∀ x ∈ Omega \setminus \{x_0\}, u(x) < u(x_0)$



/-- def:zero.on.gamma
    Category: Other -/
def zero.on.gamma : Prop :=
  $ZeroOnGamma(u, \Gamma) = u = 0 \quad (\Gamma)$



/-- def:coeff.nonnegative
    Category: Other -/
def coeff.nonnegative : Prop :=
  $a ∈ L^∈fty(Omega), a(x) \geq 0$



/-- def:coeff.positive
    Category: Other -/
def coeff.positive : Prop :=
  $a ∈ L^∈fty(Omega), a(x) \geq \alpha > 0$



/-- def:laplacian
    Category: Differential Operator -/
def laplacian : Prop :=
  $\Delta u = \sum_{i=1}^n \partial_i^2 u$



/-- def:gradient
    Category: Other -/
def gradient : Prop :=
  $\nabla u = (\partial_{x_1}u, \ldots, \partial_{x_n}u)$



/-- def:dirichlet.integral
    Category: Other -/
def dirichlet.integral : Prop :=
  $D(v) = ∈t_Omega |\nabla v|^2 dx$



/-- def:elliptic.bounded
    Category: Other -/
def elliptic.bounded : Prop :=
  $EllipticBounded(A,\Lambda) = ∀ \xi ∈ R^n, |A(x)\xi| \leq \Lambda|\xi|$



/-- def:elliptic.coercive
    Category: Other -/
def elliptic.coercive : Prop :=
  $EllipticCoercive(A,\lambda) = ∀ \xi ∈ R^n, \lambda|\xi|^2 \leq A(x)\xi\cdot\xi$



/-- def:elliptic
    Category: Other -/
def elliptic : Prop :=
  $Elliptic(A,\lambda,\Lambda) = EllipticBounded(A,\Lambda) ∧ EllipticCoercive(A,\lambda)$



/-- def:ellipsoid
    Category: Other -/
def ellipsoid : Prop :=
  $E = \{\xi ∈ R^n \mid A\xi\cdot\xi = 1\}$



/-- def:conormal
    Category: Other -/
def conormal : Prop :=
  $\frac{\partial u}{\partial \nu_A} = A(x)\nabla u\cdot n = a_{ij}(x)\partial_{x_j}u n_i$



/-- def:operator.L
    Category: Other -/
def operator.L : Prop :=
  $L u = -div(A\nabla u) + au$



/-- def:strong.elliptic
    Category: Other -/
def strong.elliptic : Prop :=
  $StrongElliptic(u,f,A,a,Omega) = -div(A\nabla u) + au = f$



/-- def:dirichlet
    Category: Other -/
def dirichlet : Prop :=
  $DirichletProblem(u,f,Omega) = (-\Delta u = f) ∧ ZeroBoundary(u)$



/-- def:neumann
    Category: Other -/
def neumann : Prop :=
  $NeumannProblem(u,f,Omega) = (-\Delta u = f) ∧ NeumannBoundary(u)$



/-- def:weak.dirichlet
    Category: Other -/
def weak.dirichlet : Prop :=
  $WeakDirichlet(u,f,Omega) = ZeroBoundary(u) ∧ ∀ v ∈ H_0^1(Omega), ∈t_Omega \nabla u\cdot\nabla v dx = ∈t_Omega f v dx$



/-- def:weak.neumann
    Category: Other -/
def weak.neumann : Prop :=
  $WeakNeumann(u,f,Omega) = u ∈ H^1(Omega) ∧ ∀ v ∈ H^1(Omega), ∈t_Omega \nabla u\cdot\nabla v + uv dx = ∈t_Omega f v dx$



/-- def:divergence.dirichlet
    Category: Other -/
def divergence.dirichlet : Prop :=
  $DivDirichlet(u,f,A,a,Omega) = ZeroBoundary(u) ∧ ∀ v ∈ H_0^1(Omega), ∈t_Omega A\nabla u\cdot\nabla v + auv dx = \langle f,v \rangle$



/-- def:divergence.neumann
    Category: Other -/
def divergence.neumann : Prop :=
  $DivNeumann(u,f,A,a,V,Omega) = u ∈ V ∧ ∀ v ∈ V, ∈t_Omega A\nabla u\cdot\nabla v + auv dx = \langle f,v \rangle$



/-- def:max.principle
    Category: Maximum Principle -/
def max.principle : Prop :=
  $ MaxPrinciple(L) = ∀ u_1,u_2 ∈ H^1(Omega), ((L u_1 \leq L u_2) ∧ BoundaryOrder(u_1,u_2)) → LeqInOmega(u_1, u_2) $



/-- def:inhomogeneous.dirichlet
    Category: Other -/
def inhomogeneous.dirichlet : Prop :=
  $InhomDirichlet(u,f,g,A,a,Omega) = (u - g ∈ H_0^1(Omega)) ∧ ∀ v ∈ H_0^1(Omega), ∈t_Omega A\nabla u\cdot\nabla v + auv dx = \langle f,v \rangle$



/-- def:lax.solution
    Category: Other -/
def lax.solution : Prop :=
  $LaxSolution(u,a,f) = ∀ v ∈ H, a(u,v) = \langle f,v \rangle$



/-- def:strong.solution
    Category: Other -/
def strong.solution : Prop :=
  $StrongSolution(u,f,Omega) = (u ∈ C^2(Omega) ∩ C^0(\overline{Omega})) ∧ (-\Delta u = f) ∧ ZeroBoundary(u)$



/-- def:mixed.subspace
    Category: Other -/
def mixed.subspace : Prop :=
  $V_{\Gamma_0} = \overline{\{v ∈ C^1(\overline{Omega}) \mid ZeroOnGamma(v, \Gamma_0)\}}^{\|\cdot\|_{1,2}}$



/-- def:mixed.problem
    Category: Other -/
def mixed.problem : Prop :=
  $MixedProblem(u,f,A,a,\Gamma_0,Omega) = (u ∈ V_{\Gamma_0}) ∧ ∀ v ∈ V_{\Gamma_0}, ∈t_Omega A\nabla u\cdot\nabla v + auv dx = ∈t_Omega f v dx $



/-- def:solves
    Category: Other -/
def solves : Prop :=
  $Solves(u, L, f) = L u = f$



/-- def:neumann.boundary
    Category: Other -/
def neumann.boundary : Prop :=
  $NeumannBoundary(u) = \partial_n u = 0$



/-- def:conormal.zero
    Category: Other -/
def conormal.zero : Prop :=
  $ConormalZero(u) = A\nabla u\cdot n = 0$



/-- def:conormal.zero.on.gamma
    Category: Other -/
def conormal.zero.on.gamma : Prop :=
  $ConormalZeroOnGamma(u, \Gamma) = A\nabla u\cdot n = 0 \quad (\Gamma)$



/-- def:bilinear.form
    Category: Bilinear Form -/
def bilinear.form : Prop :=
  $Bilinear(a) = & ∀ u_1,u_2,v ∈ H, ∀ \alpha,\beta ∈ R, \ & a(\alpha u_1+\beta u_2,v) = \alpha a(u_1,v) + \beta a(u_2,v) ∧ a(u,\alpha v_1+\beta v_2) = \alpha a(u,v_1) + \beta a(u,v_2)$



/-- def:continuous.bilinear
    Category: Other -/
def continuous.bilinear : Prop :=
  $Continuous(a) = ∃ \Lambda > 0, ∀ u,v ∈ H, |a(u,v)| \leq \Lambda \|u\|\|v\|$



/-- def:coercive.bilinear
    Category: Other -/
def coercive.bilinear : Prop :=
  $Coercive(a) = ∃ \lambda > 0, ∀ u ∈ H, a(u,u) \geq \lambda \|u\|^2$



/-- def:fick.law
    Category: Other -/
def fick.law : Prop :=
  $FickLaw = \vec{v} = -D\nabla u$



/-- def:conservation
    Category: Other -/
def conservation : Prop :=
  $Conservation = ∈t_{\partial Q} \vec{v}\cdot\vec{n} d\sigma = ∈t_Q f dx$



/-- def:divergence.theorem
    Category: Other -/
def divergence.theorem : Prop :=
  $DivergenceTheorem = ∈t_{\partial Q} \vec{v}\cdot\vec{n} d\sigma = ∈t_Q div\vec{v} dx$



/-- def:first.eigenvalue
    Category: Other -/
def first.eigenvalue : Prop :=
  $\lambda_1 = ∈f_{u ∈ H_0^1(Omega), u \neq 0} \frac{∈t_Omega A\nabla u\cdot\nabla u dx}{∈t_Omega u^2 dx}$



/-- def:energy
    Category: Other -/
def energy : Prop :=
  $J(v) = \frac{1}{2}∈t_Omega A\nabla v\cdot\nabla v + av^2 dx - \langle f,v \rangle$



/-- def:min.eigenvalue
    Category: Other -/
def min.eigenvalue : Prop :=
  $\lambda_{\min}(A) = ∈f_{\xi \neq 0} \frac{A\xi\cdot\xi}{|\xi|^2}$



/-- def:lp.conv
    Category: L^p Space -/
def lp.conv : Prop :=
  $LpConv(u_n, u, Omega) = (u_n arrow u) ∧ (u ∈ L^p(Omega)) = \|u_n - u\|_{p,Omega} arrow 0$



/-- def:strong.conv
    Category: Other -/
def strong.conv : Prop :=
  $StrongConv(u_n, u, H) = (u_n arrow u) ∧ (u ∈ H) = \|u_n - u\| arrow 0$



/-- def:weak.conv
    Category: Other -/
def weak.conv : Prop :=
  $WeakConv(u_n, u, H) = (u_n harpoonup u) ∧ (u ∈ H) = ∀ v ∈ H, (u_n,v) arrow (u,v)$



/-- def:weak.compact
    Category: Other -/
def weak.compact : Prop :=
  $WeakCompact(\{u_n\}, H) = ∀ Bounded(\{u_n\}), ∃ \{u_{n_k}\}, ∃ u ∈ H, WeakConv(u_{n_k}, u, H)$



/-- def:ae.conv
    Category: Other -/
def ae.conv : Prop :=
  $AEConv(A_n, A) = ∃ N ⊂ Omega, |N| = 0, ∀ x ∈ Omega \setminus N, \lim_{n} A_n(x) = A(x)$



/-- def:weakstar.conv
    Category: Other -/
def weakstar.conv : Prop :=
  $WeakStarConv(\phi_n, \phi, X^*) = ∀ x ∈ X, \phi_n(x) arrow \phi(x)$



/-- def:weakstar.compact
    Category: Other -/
def weakstar.compact : Prop :=
  $WeakStarCompact(K, X^*) = ∀ \{\phi_n\} ⊂ K, ∃ \{\phi_{n_k}\} ⊂ \{\phi_n\}, ∃ \phi ∈ K, WeakStarConv(\phi_{n_k}, \phi, X^*)$



/-- ex:hilbert.1
    Category: Other -/
def ex:hilbert.1 : Prop :=
  $Hilbert(R^n, (x,y) \mapsto x\cdot y)$



/-- ex:hilbert.2
    Category: Other -/
def ex:hilbert.2 : Prop :=
  $Hilbert(L^2(A), (u,v) \mapsto ∈t_A u(x)v(x) dx)$



/-- ex:mollifier.1
    Category: Other -/
def ex:mollifier.1 : Prop :=
  $\rho ∈ D(R^n) ∧ Supp(\rho) = \overline{B_1(0)}$



/-- ex:mollifier.2
    Category: Other -/
def ex:mollifier.2 : Prop :=
  $\rho_\epsilon(x) = \epsilon^{-n}\rho(x/\epsilon) ∧ Supp(\rho_\epsilon) = B_\epsilon(0) ∧ ∈t_{R^n} \rho_\epsilon(x) dx = 1$



/-- ex:dist.1
    Category: Other -/
def ex:dist.1 : Prop :=
  $∀ T ∈ L_{loc}^1(Omega), \langle T,\phi \rangle = ∈t_Omega T(x)\phi(x) dx → T ∈ D'(Omega)$



/-- ex:dist.2
    Category: Other -/
def ex:dist.2 : Prop :=
  $\delta_{x_0} ∈ D'(Omega) ∧ \langle \delta_{x_0},\phi \rangle = \phi(x_0)$



/-- ex:dist.3
    Category: Other -/
def ex:dist.3 : Prop :=
  $(x_n → x_0) → DistConv(\delta_{x_n}, \delta_{x_0}, Omega)$



/-- ex:sobolev.1
    Category: Other -/
def ex:sobolev.1 : Prop :=
  $∀ u ∈ C^1(\overline{Omega}) ∧ Bounded(Omega) → u ∈ H^1(Omega)$



/-- def:normed.space
    Category: Metric/Norm -/
def normed.space : Prop :=
  $NormedSpace(X) = & VectorSpace(X) ∧ ∃ \|\cdot\|: X arrow R, ∀ x,y ∈ X, ∀ \alpha ∈ R, \ & \|x\| \geq 0 ∧ (\|x\|=0 ↔ x=0) ∧ \|\alpha x\| = |\alpha|\|x\| ∧ \|x+y\| \leq \|x\| + \|y\| $



/-- def:banach.space
    Category: Other -/
def banach.space : Prop :=
  $BanachSpace(X) = NormedSpace(X) ∧ Complete(X)$



/-- rem:projection
    Category: Other -/
def rem:projection : Prop :=
  $(h ∈ K) → P_K(h) = h$



/-- rem:cauchy.schwarz
    Category: Other -/
def rem:cauchy.schwarz : Prop :=
  $∀ u,v ∈ H, |(u,v)| \leq \|u\|\|v\|$



/-- rem:h1.meaning
    Category: Other -/
def rem:h1.meaning : Prop :=
  $∀ v ∈ H^1(Omega), ∃ v_i ∈ L^2(Omega), -∈t_Omega v\partial_i\phi dx = ∈t_Omega v_i\phi dx$



/-- rem:h01.meaning
    Category: Other -/
def rem:h01.meaning : Prop :=
  $ZeroBoundary(u) = u ∈ H_0^1(Omega)$



/-- rem:dual.norm
    Category: Other -/
def rem:dual.norm : Prop :=
  $\|T\|_* = \sup_{v ∈ H_0^1(Omega)\setminus\{0\}} \frac{|\langle T,v \rangle|}{\|v\|_{1,2}}$



/-- rem:neumann
    Category: Other -/
def rem:neumann : Prop :=
  $∀ u,v ∈ C^∈fty(\overline{Omega}), ∈t_Omega \nabla u\cdot\nabla v dx = ∈t_{\partialOmega} \partial_n u v d\sigma - ∈t_Omega v\Delta u dx$



/-- rem:generalized.neumann
    Category: Other -/
def rem:generalized.neumann : Prop :=
  $∀ V ⊂ H^1(Omega), ClosedSubspace(V) → ∃ ! u ∈ V, ∀ v ∈ V, ∈t_Omega \nabla u\cdot\nabla v + uv dx = ∈t_Omega f v dx$



/-- rem:elliptic.bounded
    Category: Other -/
def rem:elliptic.bounded : Prop :=
  $(a_{ij} ∈ L^∈fty(Omega)) ↔ ∃ \Lambda>0, |A(x)\xi| \leq \Lambda|\xi|$



/-- rem:elliptic.a
    Category: Other -/
def rem:elliptic.a : Prop :=
  $(a(x) \geq 0) ∨ (a(x) > -\lambda_1)$



/-- rem:symmetric
    Category: Other -/
def rem:symmetric : Prop :=
  $Symmetric(A) ∧ a(u,v)=\langle f,v \rangle → u = \arg\min_{v ∈ H} J(v)$



/-- rem:finite.dim
    Category: Other -/
def rem:finite.dim : Prop :=
  $FiniteDim(V) → Closed(V) ∧ ∀ L ∈ V^*, Continuous(L)$



/-- ex:chap1.1
    Category: Other -/
def ex:chap1.1 : Prop :=
  $∀ u,v ∈ H, ∀ \lambda ∈ R, (u+\lambda v, u+\lambda v) \geq 0 → |(u,v)| \leq \|u\|\|v\|$



/-- ex:chap1.2
    Category: Other -/
def ex:chap1.2 : Prop :=
  $Closed(K) ∧ Convex(K) ∧ K = \{x \mid x_i \geq 0\} → ∀ y ∈ R^n, P_K(y) = (y_1 ∨ 0, \ldots, y_n ∨ 0)$



/-- ex:chap1.3
    Category: Other -/
def ex:chap1.3 : Prop :=
  $Hilbert(\ell^2, (x,y) \mapsto \sum_{i=1}^∈fty x_i y_i) ∧ (e_n harpoonup 0) ∧ \neg(e_n → 0)$



/-- ex:chap1.4
    Category: Other -/
def ex:chap1.4 : Prop :=
  $Closed(K) ∧ Convex(K) ∧ K = \{v ∈ L^2(A) \mid v \leq g\} → ∀ v ∈ L^2(A), P_K(v) = v ∧ g$



/-- ex:chap1.5
    Category: Other -/
def ex:chap1.5 : Prop :=
  $∀ h,h' ∈ H, \|P_K(h) - P_K(h')\| \leq \|h - h'\|$



/-- ex:chap1.6
    Category: Other -/
def ex:chap1.6 : Prop :=
  $\scriptsize Bilinear(a) ∧ Continuous(a) ∧ Coercive(a) ∧ f,\ell ∈ H^* ∧ \ell \neq 0 → ∃ ! u ∈ V = \{h \mid \langle \ell,h \rangle = 0\}, ∀ v ∈ V,a(u,v) = \langle f,v \rangle $



/-- ex:chap1.7
    Category: Other -/
def ex:chap1.7 : Prop :=
  $(∀ n \neq m, (u_n,u_m) = 0) ∧ (\sum_{k=1}^∈fty \|u_k\|^2 < ∈fty) → ∃ S ∈ H, S_n = \sum_{k=1}^n u_k → S ∧ \|S\|^2 = \sum_{k=1}^∈fty \|u_k\|^2$



/-- ex:chap1.8
    Category: Other -/
def ex:chap1.8 : Prop :=
  $Separable(H) → ∃ \{u_i\}, Basis(\{u_i\})$



/-- ex:chap2.1
    Category: Other -/
def ex:chap2.1 : Prop :=
  $f_i ∈ L^{p_i}(Omega) ∧ \sum_{i=1}^k \frac{1}{p_i} = 1 → \|\prod_{i=1}^k f_i\|_{1,Omega} \leq \prod_{i=1}^k \|f_i\|_{p_i,Omega}$



/-- ex:chap2.2
    Category: Other -/
def ex:chap2.2 : Prop :=
  $\eta(t) = e^{-1/t}$ for $t>0$, $\eta(t)=0$ for $t \leq 0 → \eta ∈ C^∈fty(R) ∧ \rho(x) = c\eta(1-|x|^2) ∈ D(R^n)$



/-- ex:chap2.3
    Category: Other -/
def ex:chap2.3 : Prop :=
  $\dim(D(Omega)) = ∈fty$



/-- ex:chap2.4
    Category: Other -/
def ex:chap2.4 : Prop :=
  $H(x) = 1$ for $x>0$, $H(x)=0$ for $x \leq 0 → H' = \delta_0$ in $D'(R)$



/-- ex:chap2.5
    Category: Other -/
def ex:chap2.5 : Prop :=
  $∀ 1 \leq p \leq ∈fty, L^p(Omega) ⊂ L_{loc}^1(Omega)$



/-- ex:chap2.6
    Category: Other -/
def ex:chap2.6 : Prop :=
  $T ∈ D'(R) ∧ T' = 0 → ∃ C ∈ R, T = C$



/-- ex:chap2.7
    Category: Other -/
def ex:chap2.7 : Prop :=
  $Bounded(Omega) → 1 ∈ H^1(Omega) \setminus H_0^1(Omega)$



/-- ex:chap2.8
    Category: Other -/
def ex:chap2.8 : Prop :=
  $\neg(∃ C>0, ∀ u ∈ H^1(Omega), \|u\|_{2,Omega} + \|\partial_1 u\|_{2,Omega} \leq C\|u\|_{1,2})$



/-- ex:chap2.9
    Category: Other -/
def ex:chap2.9 : Prop :=
  $Omega = (0,1) → Continuous(u \mapsto u(1)) ∧ (u \mapsto u(1)) ∉ D'(Omega)$



/-- ex:chap2.10
    Category: Other -/
def ex:chap2.10 : Prop :=
  $Lipschitz(u) ∧ Bounded(Omega) → u ∈ H^1(Omega) ∧ \partial_i u ∈ L^∈fty(Omega)$



/-- ex:chap2.11
    Category: Other -/
def ex:chap2.11 : Prop :=
  $Lipschitz(u) ∧ ZeroBoundary(u) → u ∈ H_0^1(Omega)$



/-- ex:chap2.12
    Category: Other -/
def ex:chap2.12 : Prop :=
  $Connected(Omega) ∧ (\nabla u = 0) → Constant(u)$



/-- ex:chap2.13
    Category: Other -/
def ex:chap2.13 : Prop :=
  $T = p' ∈ H^{-1}(Omega) ∧ p ∈ L^2(Omega) → \|T\|_* = \|p\|_{2,Omega}$



/-- ex:chap3.1
    Category: Other -/
def ex:chap3.1 : Prop :=
  $h,f ∈ C(Omega) ∧ (∀ Q ⊂ Omega, ∈t_Q h dx = ∈t_Q f dx) → h = f$



/-- ex:chap3.2
    Category: Other -/
def ex:chap3.2 : Prop :=
  $Closed(V) ∧ V = \{v ∈ H^1(Omega) \mid ∈t_Omega v dx = 0\} ∧ (-\Delta u + u = f - \fint_Omega f)$



/-- ex:chap3.3
    Category: Other -/
def ex:chap3.3 : Prop :=
  $-\Delta u = f → -\Delta(u ∨ k) \leq f\chi_{\{u>k\}}$



/-- ex:chap4.1
    Category: Other -/
def ex:chap4.1 : Prop :=
  $∀ T, Triangle(T) ⊂ R^2, ∀ \vec{\omega}, ∈t_T div\vec{\omega} dx = ∈t_{\partial T} \vec{\omega}\cdot\vec{n} ds$



/-- ex:chap4.2
    Category: Other -/
def ex:chap4.2 : Prop :=
  $ \Gamma_0 ⊂ \Gamma ∧ W &= \{v ∈ C^1(\overline{Omega}) \mid v=0 on \Gamma_0\} ∧ V = \overline{W}^{\|\cdot\|_{1,2}}\ & → MixedProblem(u,f,A,a,\Gamma_0,Omega) → ZeroOnGamma(u,\Gamma_0) ∧ ConormalZeroOnGamma(u,\Gamma\setminus\Gamma_0) $



/-- ex:chap4.3
    Category: Other -/
def ex:chap4.3 : Prop :=
  $T_1,T_2 ∈ D'(Omega) → (T_1 \leq T_2 ↔ T_2 - T_1 \geq 0)$



/-- ex:chap4.4
    Category: Other -/
def ex:chap4.4 : Prop :=
  $L_i u = -div(A\nabla u) + a_i u ∧ a_1 \leq a_2 ∧ L_1 u_1 \leq L_2 u_2 ∧ BoundaryOrder(u_1,u_2) → LeqInOmega(u_1,u_2)$



/-- ex:chap4.5
    Category: Other -/
def ex:chap4.5 : Prop :=
  $\lambda_{\min}(A) = ∈f_{\xi \neq 0} \frac{A\xi\cdot\xi}{|\xi|^2}$



/-- ex:chap4.6
    Category: Other -/
def ex:chap4.6 : Prop :=
  $Omega_1 ⊂ Omega_2 ∧ f_2 \geq f_1 \geq 0 → u_2 \geq u_1 \geq 0$



/-- ex:chap4.7
    Category: Other -/
def ex:chap4.7 : Prop :=
  $∀ f_1,f_2 ∈ H^{-1}(Omega), ∃ C>0, \|u(f_1)-u(f_2)\|_{1,2} \leq C\|f_1-f_2\|_{H^{-1}}$



/-- ex:chap4.8
    Category: Other -/
def ex:chap4.8 : Prop :=
  $AEConv(A_n, A) ∧ Solves(u_n, -div(A_n\nabla \cdot), f) → StrongConv(u_n, u, H_0^1(Omega))$



/-- ex:chap4.9
    Category: Other -/
def ex:chap4.9 : Prop :=
  $FiniteDim(V) → Closed(V) ∧ ∀ L ∈ V^*, Continuous(L)$



/-- thm:banach-alaoglu
    Category: Functional Analysis -/
theorem banach-alaoglu :
  $∀ X, NormedSpace(X) → WeakStarCompact(\overline{B}_{X^*}(0,1), X^*)$ :=
  sorry  -- Proof to be filled in



/-- thm:banach-alaoglu.general
    Category: Functional Analysis -/
theorem banach-alaoglu.general :
  $∀ X, ∀ C > 0, NormedSpace(X) → WeakStarCompact(\overline{B}_{X^*}(0,C), X^*)$ :=
  sorry  -- Proof to be filled in



/-- thm:projection
    Category: Hilbert Space -/
theorem projection :
  $∀ Hilbert(H), ∀ K ⊂ H, (Closed(K) ∧ Convex(K) ∧ K \neq ∅) → \bigl( ∀ h ∈ H, ∃ ! u ∈ K, P_K(h)=u \bigr)$ :=
  sorry  -- Proof to be filled in



/-- thm:equiv
    Category: Other -/
theorem equiv :
  $∀ Hilbert(H), ∀ K ⊂ H, ∀ h,u ∈ H, P_K(h)=u ↔ VarIneq(u,h,K)$ :=
  sorry  -- Proof to be filled in



/-- thm:subspace
    Category: Other -/
theorem subspace :
  $∀ Hilbert(H), ∀ V ⊂ H, ClosedSubspace(V) → \bigl( ∀ h ∈ H, ∃ ! u ∈ V, ∀ v ∈ V, (h-u,v)=0 \bigr)$ :=
  sorry  -- Proof to be filled in



/-- thm:riesz
    Category: Hilbert Space -/
theorem riesz :
  $∀ Hilbert(H), ∀ f ∈ H^*, ∃ ! h ∈ H, ∀ v ∈ H, (h,v) = \langle f,v \rangle$ :=
  sorry  -- Proof to be filled in



/-- thm:lax.milgram
    Category: Hilbert Space -/
theorem lax.milgram :
  $∀ Hilbert(H), ∀ a: H\timesH arrow R, (Bilinear(a) ∧ Continuous(a) ∧ Coercive(a))\ → \bigl( ∀ f ∈ H^*, ∃ ! u ∈ H, LaxSolution(u,a,f) \bigr)$ :=
  sorry  -- Proof to be filled in



/-- thm:bessel
    Category: Other -/
theorem bessel :
  $∀ \{u_i\} ∈ Orthonormal, ∀ h ∈ H, \sum_i |(h,u_i)|^2 \leq \|h\|^2$ :=
  sorry  -- Proof to be filled in



/-- thm:basis
    Category: Other -/
theorem basis :
  $∀ Hilbert(H), Separable(H) → ∃ \{u_i\}, Basis(\{u_i\})$ :=
  sorry  -- Proof to be filled in



/-- thm:weak.compact
    Category: Other -/
theorem weak.compact :
  $∀ \{u_n\} ⊂ H, ∃ C>0, \|u_n\| \leq C → ∃ \{u_{n_k}\}, ∃ u ∈ H, u_{n_k} harpoonup u$ :=
  sorry  -- Proof to be filled in



/-- thm:weak.strong.limit
    Category: Other -/
theorem weak.strong.limit :
  $(u_n harpoonup u ∧ v_n arrow v) → (u_n,v_n) arrow (u,v)$ :=
  sorry  -- Proof to be filled in



/-- thm:mollifier
    Category: L^p and Distribution -/
theorem mollifier :
  $∀ u ∈ L_{loc}^p(Omega), ∀ Omega' ⊂⊂ Omega, \|u_\epsilon - u\|_{p,Omega'} arrow 0$ :=
  sorry  -- Proof to be filled in



/-- thm:frekhet
    Category: Other -/
theorem frekhet :
  $ ∀ L ⊂ L^p(Omega), BoundedInLp(L,Omega) ∧ Equicontinuous(L,Omega') → RelativelyCompact(L|_{Omega'}, Omega') $ :=
  sorry  -- Proof to be filled in



/-- thm:dist.equality
    Category: L^p and Distribution -/
theorem dist.equality :
  $∀ T_1,T_2 ∈ L_{loc}^1(Omega), (∀ \phi ∈ D(Omega), \langle T_1,\phi \rangle = \langle T_2,\phi \rangle) → T_1 = T_2 a.e.$ :=
  sorry  -- Proof to be filled in



/-- thm:h1.hilbert
    Category: Sobolev Space -/
theorem h1.hilbert :
  $Hilbert(H^1(Omega), \|\cdot\|_{1,2})$ :=
  sorry  -- Proof to be filled in



/-- thm:h01.hilbert
    Category: Sobolev Space -/
theorem h01.hilbert :
  $ClosedSubspace(H_0^1(Omega), H^1(Omega))$ :=
  sorry  -- Proof to be filled in



/-- thm:poincare
    Category: Sobolev Space -/
theorem poincare :
  $∀ Omega, BoundedOneDir(Omega), ∀ v ∈ H_0^1(Omega), ∃ C>0, \|v\|_{2,Omega} \leq C\|\nabla v\|_{2,Omega}$ :=
  sorry  -- Proof to be filled in



/-- thm:compact.embedding
    Category: Other -/
theorem compact.embedding :
  $∀ Omega, Bounded(Omega) → CompactEmbedding(H_0^1(Omega), L^2(Omega))$ :=
  sorry  -- Proof to be filled in



/-- thm:hminus1.repr
    Category: Other -/
theorem hminus1.repr :
  $∀ T ∈ H^{-1}(Omega), ∃ T_0,T_1,\ldots,T_n ∈ L^2(Omega), T = T_0 + \sum_{i=1}^n \partial_i T_i$ :=
  sorry  -- Proof to be filled in



/-- thm:chain.rule
    Category: Other -/
theorem chain.rule :
  $∀ f ∈ C^1(R) ∩ W^{1,∈fty}(R), ∀ u ∈ H^1(Omega), \partial_i f(u) = f'(u)\partial_i u$ :=
  sorry  -- Proof to be filled in



/-- thm:chain.rule.lipschitz
    Category: Other -/
theorem chain.rule.lipschitz :
  $∀ f, Lipschitz(f), ∀ u ∈ H^1(Omega), f(u) ∈ H^1(Omega) ∧ \partial_i f(u) = f'(u)\partial_i u a.e.$ :=
  sorry  -- Proof to be filled in



/-- thm:laplace.derivation
    Category: Other -/
theorem laplace.derivation :
  $FickLaw ∧ Conservation ∧ DivergenceTheorem → -\Delta u = f$ :=
  sorry  -- Proof to be filled in



/-- thm:weak.dirichlet
    Category: Physics and Elliptic -/
theorem weak.dirichlet :
  $∀ f ∈ H^{-1}(Omega), BoundedOneDir(Omega) → ∃ ! u ∈ H_0^1(Omega), WeakDirichlet(u,f,Omega)$ :=
  sorry  -- Proof to be filled in



/-- thm:weak.neumann
    Category: Physics and Elliptic -/
theorem weak.neumann :
  $∀ f ∈ L^2(Omega), ∃ ! u ∈ H^1(Omega), WeakNeumann(u,f,Omega)$ :=
  sorry  -- Proof to be filled in



/-- thm:strong.to.weak
    Category: Other -/
theorem strong.to.weak :
  $StrongSolution(u,f,Omega) → WeakDirichlet(u,f,Omega)$ :=
  sorry  -- Proof to be filled in



/-- thm:divergence.dirichlet
    Category: Physics and Elliptic -/
theorem divergence.dirichlet :
  $&∀ Omega, BoundedOneDir(Omega), ∀ A, Elliptic(A,\lambda,\Lambda), ∀ a ∈ L^∈fty(Omega), a \geq 0, ∀ f ∈ H^{-1}(Omega), \\& ∃ ! u ∈ H_0^1(Omega), DivDirichlet(u,f,A,a,Omega)$ :=
  sorry  -- Proof to be filled in



/-- thm:divergence.neumann
    Category: Physics and Elliptic -/
theorem divergence.neumann :
  $&∀ Omega, ∀ A, Elliptic(A,\lambda,\Lambda), ∀ a ∈ L^∈fty(Omega), a \geq \alpha > 0, ∀ V ⊂ H^1(Omega), ClosedSubspace(V), \ &∀ f ∈ V^*, ∃ ! u ∈ V, DivNeumann(u,f,A,a,V,Omega)$ :=
  sorry  -- Proof to be filled in



/-- thm:max.principle
    Category: Maximum Principle -/
theorem max.principle :
  $∀ A, Elliptic(A,\lambda,\Lambda), ∀ a ∈ L^∈fty(Omega), a \geq 0, MaxPrinciple(L)$ :=
  sorry  -- Proof to be filled in



/-- thm:max.principle.neumann
    Category: Physics and Elliptic -/
theorem max.principle.neumann :
  $∀ A, Elliptic(A,\lambda,\Lambda), ∀ a ∈ L^∈fty(Omega), a \geq \alpha > 0, ∀ f_1 \leq f_2, u_1 \leq u_2$ :=
  sorry  -- Proof to be filled in



/-- thm:inhomogeneous
    Category: Other -/
theorem inhomogeneous :
  $∀ g ∈ H^1(Omega), ∀ f ∈ H^{-1}(Omega), ∃ ! u ∈ H^1(Omega), InhomDirichlet(u,f,g,A,a,Omega)$ :=
  sorry  -- Proof to be filled in



/-- thm:orthonormal.independent
    Category: Other -/
theorem orthonormal.independent :
  $∀ \{u_1,\ldots,u_n\}, Orthonormal(\{u_i\}) → LinearlyIndependent(\{u_i\})$ :=
  sorry  -- Proof to be filled in



/-- thm:orthant.projection
    Category: Hilbert Space -/
theorem orthant.projection :
  $∀ y ∈ R^n, P_K(y) = (y_1 ∨ 0, y_2 ∨ 0, \ldots, y_n ∨ 0)$ :=
  sorry  -- Proof to be filled in



/-- thm:domain.monotonicity
    Category: Other -/
theorem domain.monotonicity :
  $Omega_1 ⊂ Omega_2 ∧ f_2 \geq f_1 \geq 0 → u_2 \geq u_1 \geq 0$ :=
  sorry  -- Proof to be filled in



/-- thm:solution.map.continuous
    Category: Other -/
theorem solution.map.continuous :
  $∀ f_1,f_2 ∈ H^{-1}(Omega), ∃ C>0, \|u(f_1)-u(f_2)\|_{1,2} \leq C\|f_1-f_2\|_{H^{-1}}$ :=
  sorry  -- Proof to be filled in



/-- thm:coeff.stability
    Category: Other -/
theorem coeff.stability :
  $A_n → A a.e. ∧ u_n solves -div(A_n\nabla u_n)=f → u_n → u in H_0^1(Omega)$ :=
  sorry  -- Proof to be filled in



/-- thm:finite.dimensional
    Category: Other -/
theorem finite.dimensional :
  $∀ V ⊂ H^1(Omega), \dim V < ∈fty → Closed(V) ∧ ∀ L ∈ V^*, Continuous(L)$ :=
  sorry  -- Proof to be filled in



/-- thm:smallest.eigenvalue
    Category: Other -/
theorem smallest.eigenvalue :
  $\lambda_1 = ∈f_{\xi \neq 0} \frac{A\xi\cdot\xi}{|\xi|^2} is the smallest eigenvalue of A$ :=
  sorry  -- Proof to be filled in



/-- thm:zero.mean
    Category: Other -/
theorem zero.mean :
  $Closed(\{v ∈ H^1(Omega) \mid ∈t_Omega v dx = 0\}) ∧ -\Delta u + u = f - \fint_Omega f$ :=
  sorry  -- Proof to be filled in



/-- thm:subsolution
    Category: Other -/
theorem subsolution :
  $u solves -\Delta u = f in H_0^1(Omega) → -\Delta(u ∨ k) \leq f\chi_{\{u>k\}} in D'(Omega)$ :=
  sorry  -- Proof to be filled in



/-- thm:comparison.different.a
    Category: Other -/
theorem comparison.different.a :
  $a_1 \leq a_2 ∧ L_1 u_1 \leq L_2 u_2 ∧ u_1 \leq u_2 on \partialOmega → u_1 \leq u_2$ :=
  sorry  -- Proof to be filled in



/-- thm:generalized.neumann
    Category: Physics and Elliptic -/
theorem generalized.neumann :
  $&∀ f ∈ L^2(Omega), ∀ V ⊂ H^1(Omega), ClosedSubspace(V)\ &→ ∃ ! u ∈ V, ∀ v ∈ V, ∈t_Omega \nabla u\cdot\nabla v + uv dx = ∈t_Omega f v dx$ :=
  sorry  -- Proof to be filled in



/-- thm:mollifier.exists
    Category: L^p and Distribution -/
theorem mollifier.exists :
  $∃ \rho ∈ D(R^n), Supp(\rho) = \overline{B_1(0)} ∧ ∈t_{R^n} \rho(x) dx = 1$ :=
  sorry  -- Proof to be filled in



/-- thm:calD.infinite
    Category: Other -/
theorem calD.infinite :
  $\dim(D(Omega)) = ∈fty$ :=
  sorry  -- Proof to be filled in



/-- thm:heaviside.derivative
    Category: Other -/
theorem heaviside.derivative :
  $H' = \delta_0 in D'(R)$ :=
  sorry  -- Proof to be filled in



/-- thm:lp.subset.l1loc
    Category: Other -/
theorem lp.subset.l1loc :
  $∀ 1 \leq p \leq ∈fty, L^p(Omega) ⊂ L_{loc}^1(Omega)$ :=
  sorry  -- Proof to be filled in



/-- thm:zero.derivative.constant
    Category: Other -/
theorem zero.derivative.constant :
  $T ∈ D'(R) ∧ T' = 0 → ∃ C ∈ R, T = C$ :=
  sorry  -- Proof to be filled in



/-- thm:constant.not.in.h01
    Category: Sobolev Space -/
theorem constant.not.in.h01 :
  $Bounded(Omega) → 1 ∈ H^1(Omega) \setminus H_0^1(Omega)$ :=
  sorry  -- Proof to be filled in



/-- thm:gradient.zero.constant
    Category: Other -/
theorem gradient.zero.constant :
  $Connected(Omega) ∧ (u ∈ H^1(Omega)) ∧ (∀ i ∈ \{1,\ldots,n\}, \partial_i u = 0 in Omega) → ∃ C ∈ R, ∀ x ∈ Omega, u(x) = C$ :=
  sorry  -- Proof to be filled in



/-- thm:dual.norm.derivative
    Category: Other -/
theorem dual.norm.derivative :
  $T = p' ∈ H^{-1}(Omega) ∧ p ∈ L^2(Omega) → \|T\|_* = \|p\|_{2,Omega}$ :=
  sorry  -- Proof to be filled in



/-- thm:lipschitz.in.h1
    Category: Sobolev Space -/
theorem lipschitz.in.h1 :
  $Lipschitz(u) ∧ Bounded(Omega) → u ∈ H^1(Omega)$ :=
  sorry  -- Proof to be filled in



/-- thm:lipschitz.vanishing.in.h01
    Category: Sobolev Space -/
theorem lipschitz.vanishing.in.h01 :
  $Lipschitz(u) ∧ u=0 on \partialOmega → u ∈ H_0^1(Omega)$ :=
  sorry  -- Proof to be filled in



/-- thm:pos.neg.parts
    Category: Other -/
theorem pos.neg.parts :
  $u ∈ H^1(Omega) → u^+, u^- ∈ H^1(Omega) ∧ \partial_i u^+ = \chi_{\{u>0\}}\partial_i u ∧ \partial_i u^- = -\chi_{\{u<0\}}\partial_i u$ :=
  sorry  -- Proof to be filled in



/-- thm:norm.equivalence.h01
    Category: Sobolev Space -/
theorem norm.equivalence.h01 :
  $BoundedOneDir(Omega) → ∃ C_1,C_2>0, C_1\|v\|_{1,2} \leq \|\nabla v\|_{2,Omega} \leq C_2\|v\|_{1,2}$ :=
  sorry  -- Proof to be filled in



/-- thm:mixed.boundary
    Category: Other -/
theorem mixed.boundary :
  $MixedProblem(u,f,A,a,\Gamma_0,Omega) → u=0 on \Gamma_0 ∧ A\nabla u\cdot n = 0 on \Gamma \setminus \Gamma_0$ :=
  sorry  -- Proof to be filled in



/-- thm:divergence.triangle
    Category: Other -/
theorem divergence.triangle :
  $∀ T, Triangle(T) ⊂ R^2, ∀ \vec{\omega}, ∈t_T div\vec{\omega} dx = ∈t_{\partial T} \vec{\omega}\cdot\vec{n} ds$ :=
  sorry  -- Proof to be filled in



/-- thm:order.distributions
    Category: L^p and Distribution -/
theorem order.distributions :
  $T_1 \leq T_2 ↔ T_2 - T_1 \geq 0$ :=
  sorry  -- Proof to be filled in



/-- thm:lipschitz.bounded.derivative
    Category: Other -/
theorem lipschitz.bounded.derivative :
  $Lipschitz(u) → \partial_i u ∈ L^∈fty(Omega) ∧ |\partial_i u| \leq L$ :=
  sorry  -- Proof to be filled in



/-- thm:continuous.dense
    Category: Other -/
theorem continuous.dense :
  $∀ 1 \leq p < ∈fty, \overline{C(\overline{Omega})}^{\|\cdot\|_{p,Omega}} = L^p(Omega)$ :=
  sorry  -- Proof to be filled in



/-- thm:energy.minimization
    Category: Other -/
theorem energy.minimization :
  $Symmetric(A) ∧ a(u,v)=\langle f,v \rangle → u = \arg\min_{v ∈ H} J(v)$ :=
  sorry  -- Proof to be filled in



/-- thm:parallelogram
    Category: Other -/
theorem parallelogram :
  $\|u+v\|^2 + \|u-v\|^2 = 2\|u\|^2 + 2\|v\|^2$ :=
  sorry  -- Proof to be filled in



/-- thm:cauchy.schwarz
    Category: Other -/
theorem cauchy.schwarz :
  $|(u,v)| \leq \|u\|\|v\| ∀ u,v ∈ H$ :=
  sorry  -- Proof to be filled in



/-- thm:projection.nonexpansive
    Category: Hilbert Space -/
theorem projection.nonexpansive :
  $\|P_K(h) - P_K(h')\| \leq \|h - h'\| ∀ h,h' ∈ H$ :=
  sorry  -- Proof to be filled in



/-- thm:lax.milgram.constraint
    Category: Hilbert Space -/
theorem lax.milgram.constraint :
  $∃ ! u ∈ V = \{h ∈ H \mid \langle \ell,h \rangle = 0\}, ∀ v ∈ V, a(u,v) = \langle f,v \rangle$ :=
  sorry  -- Proof to be filled in



/-- thm:orthogonal.sum
    Category: Other -/
theorem orthogonal.sum :
  $(u_n,u_m)=0, n \neq m, \sum_{k=1}^∈fty \|u_k\|^2 < ∈fty → ∃ S ∈ H, S_n = \sum_{k=1}^n u_k → S ∧ \|S\|^2 = \sum_{k=1}^∈fty \|u_k\|^2$ :=
  sorry  -- Proof to be filled in



/-- thm:dist.derivative.continuous
    Category: L^p and Distribution -/
theorem dist.derivative.continuous :
  $T_n → T in D'(Omega) → D^\alpha T_n → D^\alpha T in D'(Omega)$ :=
  sorry  -- Proof to be filled in



/-- thm:dual.norm.inequality
    Category: Other -/
theorem dual.norm.inequality :
  $\|f\|_* = \sup_{v \neq 0} \frac{\langle f,v \rangle}{\|v\|} ∧ |\langle f,v \rangle| \leq \|f\|_*\|v\| ∀ v ∈ H$ :=
  sorry  -- Proof to be filled in



/-- thm:l2.embedding.hminus1
    Category: Other -/
theorem l2.embedding.hminus1 :
  $L^2(Omega) \hookrightarrow H^{-1}(Omega) continuously$ :=
  sorry  -- Proof to be filled in



/-- thm:mollifier.derivative
    Category: L^p and Distribution -/
theorem mollifier.derivative :
  $\partial_i(\rho_\epsilon * u) = \rho_\epsilon * \partial_i u in D'(Omega)$ :=
  sorry  -- Proof to be filled in



/-- thm:generalized.holder
    Category: Other -/
theorem generalized.holder :
  $f_i ∈ L^{p_i}(Omega), \sum \frac{1}{p_i} = 1 → \|\prod f_i\|_{1,Omega} \leq \prod \|f_i\|_{p_i,Omega}$ :=
  sorry  -- Proof to be filled in



/-- thm:integral.equality
    Category: Other -/
theorem integral.equality :
  $h,f ∈ C(Omega), ∀ Q ⊂ Omega, ∈t_Q h dx = ∈t_Q f dx → h = f$ :=
  sorry  -- Proof to be filled in



/-- thm:generalized.neumann.boundary
    Category: Physics and Elliptic -/
theorem generalized.neumann.boundary :
  $∀ v ∈ H^1(Omega), ∈t_Omega A\nabla u\cdot\nabla v + auv dx = \langle f,v \rangle → A\nabla u\cdot n = 0 on \partialOmega$ :=
  sorry  -- Proof to be filled in



/-- thm:coercivity.positive.a
    Category: Other -/
theorem coercivity.positive.a :
  $a \geq \alpha > 0 → ∈t_Omega A\nabla u\cdot\nabla u + au^2 dx \geq \min\{\lambda,\alpha\}\|u\|_{1,2}^2$ :=
  sorry  -- Proof to be filled in



/-- thm:degenerate.coercivity
    Category: Other -/
theorem degenerate.coercivity :
  $BoundedOneDir(Omega) → ∃ \lambda>0, ∈t_Omega A\nabla u\cdot\nabla u dx \geq \lambda\|u\|_{1,2}^2, ∀ u ∈ H_0^1(Omega)$ :=
  sorry  -- Proof to be filled in



/-- thm:solution.bounded
    Category: Other -/
theorem solution.bounded :
  $f ∈ L^∈fty(Omega) → u ∈ L^∈fty(Omega) ∧ \|u\|_{L^∈fty} \leq \|f\|_{L^∈fty}$ :=
  sorry  -- Proof to be filled in



/-- thm:solution.regularity
    Category: Other -/
theorem solution.regularity :
  $f ∈ H^m(Omega) → u ∈ H^{m+2}(Omega)$ :=
  sorry  -- Proof to be filled in



/-- thm:eigenvalue.problem
    Category: Other -/
theorem eigenvalue.problem :
  $∃ \lambda ∈ R, u ∈ H_0^1(Omega)\setminus\{0\}, ∀ v ∈ H_0^1(Omega), ∈t_Omega A\nabla u\cdot\nabla v dx = \lambda∈t_Omega uv dx$ :=
  sorry  -- Proof to be filled in



/-- thm:operator.comparison
    Category: Other -/
theorem operator.comparison :
  $A_1 \leq A_2 → \lambda_1^{(1)} \leq \lambda_1^{(2)}$ :=
  sorry  -- Proof to be filled in



/-- thm:hopf.lemma
    Category: Maximum Principle -/
theorem hopf.lemma :
  $ ∀ u ∈ C^2(Omega) ∩ C^1(\overline{Omega}), ∀ x_0 ∈ \partialOmega, (-L u \leq 0 in Omega) ∧ (u(x_0) > u(x), ∀ x ∈ Omega) → \frac{\partial u}{\partial n}(x_0) > 0 $ :=
  sorry  -- Proof to be filled in



/-- thm:strong.max.principle
    Category: Maximum Principle -/
theorem strong.max.principle :
  $(∀ x ∈ Omega, (-L u)(x) \leq 0) ∧ (∃ x_0 ∈ Omega, u(x_0) \geq 0 ∧ ∀ x ∈ Omega, u(x) \leq u(x_0)) → ∃ C ∈ R, u = C$ :=
  sorry  -- Proof to be filled in
