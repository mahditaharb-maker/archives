@echo off
setlocal

REM ---- Set default filename ----
if "%1"=="" (set TEXFILE=13.tex) else (set TEXFILE=%1)

REM ---- Extract base name (without extension) ----
for %%i in ("%TEXFILE%") do set BASENAME=%%~ni

REM ---- Paths ----
set TEXLIVE=E:\Processings\Doctorate\texlive\2024\bin\windows
set NODEJS=E:\Processings\Online_Softwares\tools\node-v13.14.0-win-x64
set NPM_GLOBAL=%APPDATA%\npm

set PUPPETEER_SKIP_CHROMIUM_DOWNLOAD=true
set PUPPETEER_EXECUTABLE_PATH=D:\apps\chrome+idm\Google\Chrome\Application\chrome.exe
set PUPPETEER_LAUNCH_ARGS=--no-sandbox --disable-setuid-sandbox --disable-gpu

set PATH=%TEXLIVE%;%NODEJS%;%NPM_GLOBAL%;%PATH%

REM ---- Clean auxiliary files (including index files) ----
echo Cleaning auxiliary files...
del /q *.aux *.toc *.out *.log *.lof *.lot *.idx *.ind *.ilg 2>nul

echo.
echo =====================================================
echo Compiling %TEXFILE% (pass 1/3) ...
echo =====================================================
lualatex -shell-escape %TEXFILE%
if errorlevel 1 (
    echo First pass failed. Check %BASENAME%.log
    pause
    exit /b 1
)

REM ---- Generate index (first time) ----
if exist "%BASENAME%.idx" (
    echo Generating index with makeindex (pass 1) ...
    makeindex %BASENAME%
    if errorlevel 1 (
        echo makeindex reported errors (see %BASENAME%.ilg). Continuing anyway...
    )
) else (
    echo No .idx file found – skipping makeindex (no index entries?).
)

echo.
echo =====================================================
echo Compiling %TEXFILE% (pass 2/3) ...
echo =====================================================
lualatex -shell-escape %TEXFILE%
if errorlevel 1 (
    echo Second pass failed. Check %BASENAME%.log
    pause
    exit /b 1
)

REM ---- Generate index again (to resolve cross-references) ----
if exist "%BASENAME%.idx" (
    echo Generating index with makeindex (pass 2) ...
    makeindex %BASENAME%
    if errorlevel 1 (
        echo makeindex reported errors (see %BASENAME%.ilg). Continuing anyway...
    )
) else (
    echo No .idx file found – skipping makeindex (no index entries?).
)

echo.
echo =====================================================
echo Compiling %TEXFILE% (pass 3/3) ...
echo =====================================================
lualatex -shell-escape %TEXFILE%
if errorlevel 1 (
    echo Third pass failed. Check %BASENAME%.log
    pause
    exit /b 1
)

REM ---- Final check ----
if exist "%BASENAME%.idx" (
    echo Index file size: %~zBASENAME%.idx bytes
) else (
    echo No index file generated – no \index commands were processed.
)

echo.
echo Compilation successful. Output: %BASENAME%.pdf
pause