@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion

:: ============================================================
:: ZFC Dependencies Generator - Batch Script
:: ============================================================
:: Python Path: D:\apps\Python38_updated\python.exe
:: ============================================================

echo ======================================================================
echo ZFC Dependencies Generator
echo ======================================================================
echo.

:: Set Python path
set PYTHON_PATH=D:\apps\Python38_updated\python.exe

:: Check if Python exists
if not exist "%PYTHON_PATH%" (
    echo ERROR: Python not found at %PYTHON_PATH%
    echo.
    echo Trying alternative paths...
    if exist "C:\Users\Lahmar Info\AppData\Local\Programs\Python\Python38\python.exe" (
        set PYTHON_PATH=C:\Users\Lahmar Info\AppData\Local\Programs\Python\Python38\python.exe
        echo Found Python at: !PYTHON_PATH!
    ) else (
        echo Python not found. Please check your installation.
        pause
        exit /b 1
    )
)

echo Python found: %PYTHON_PATH%
%PYTHON_PATH% --version
echo.

:: Check if zfc_dependencies.py exists
if not exist "zfc_dependencies.py" (
    echo ERROR: zfc_dependencies.py not found
    echo Current directory: %CD%
    echo.
    echo Files in current directory:
    dir *.py
    pause
    exit /b 1
)
echo Script found: zfc_dependencies.py
echo.

:: Check if input file exists
set INPUT_FILE=b.tex
if not exist "%INPUT_FILE%" (
    echo ERROR: Input file '%INPUT_FILE%' not found
    echo Current directory: %CD%
    echo.
    echo Files in current directory:
    dir *.tex
    pause
    exit /b 1
)
echo Input file: %INPUT_FILE%
echo.

:: Set output file
set OUTPUT_FILE=zfc_tables.tex
set LOG_FILE=zfc_dependencies.log

:: Remove old log files
if exist "%LOG_FILE%" del "%LOG_FILE%" 2>nul

echo Output file: %OUTPUT_FILE%
echo Log file: %LOG_FILE%
echo.

:: ============================================================
:: RUN THE SCRIPT
:: ============================================================

echo [1/3] Running ZFC dependencies generator...
echo.

:: Create log header
(
    echo ======================================================================
    echo ZFC Dependencies Generator - Execution Log
    echo ======================================================================
    echo.
    echo Date: %date%
    echo Time: %time%
    echo Computer: %COMPUTERNAME%
    echo User: %USERNAME%
    echo Python: %PYTHON_PATH%
    echo Input file: %INPUT_FILE%
    echo Output file: %OUTPUT_FILE%
    echo Current directory: %CD%
    echo.
    echo ======================================================================
    echo.
) > "%LOG_FILE%" 2>&1

:: Run the Python script
"%PYTHON_PATH%" zfc_dependencies.py "%INPUT_FILE%" "%OUTPUT_FILE%" >> "%LOG_FILE%" 2>&1

:: Check exit code
set EXIT_CODE=%errorlevel%

(
    echo.
    echo ======================================================================
    echo Exit code: %EXIT_CODE%
    echo ======================================================================
) >> "%LOG_FILE%" 2>&1

if %EXIT_CODE% neq 0 (
    echo ERROR: Script failed with exit code %EXIT_CODE%
    echo.
    echo Check the log file: %LOG_FILE%
    echo.
    echo Last 20 lines of log:
    echo ----------------------------------------
    type "%LOG_FILE%"
    echo ----------------------------------------
    echo.
    pause
    exit /b 1
)

echo Script completed successfully.
echo.

:: ============================================================
:: DISPLAY RESULTS
:: ============================================================

echo [2/3] Results:
echo.

if exist "%OUTPUT_FILE%" (
    echo   [OK] Output file generated: %OUTPUT_FILE%
    for %%A in ("%OUTPUT_FILE%") do echo   File size: %%~zA bytes
) else (
    echo   [FAIL] Output file not generated
)

if exist "%LOG_FILE%" (
    for %%A in ("%LOG_FILE%") do echo   Log file: %LOG_FILE% (%%~zA bytes)
)

echo.

:: ============================================================
:: SHOW SUMMARY FROM LOG
:: ============================================================

echo [3/3] Execution summary:
echo.

if exist "%LOG_FILE%" (
    echo ----------------------------------------
    findstr /c:"Found" /c:"Output written" /c:"Done!" "%LOG_FILE%" 2>nul
    echo ----------------------------------------
) else (
    echo No log file found
)

echo.

:: ============================================================
:: COMPLETE
:: ============================================================

echo.
echo ======================================================================
echo Done!
echo ======================================================================
echo.
echo Generated files:
if exist "%OUTPUT_FILE%" echo   %OUTPUT_FILE%
if exist "%LOG_FILE%" echo   %LOG_FILE%
echo.
echo To view the generated tables:
echo   type %OUTPUT_FILE%
echo.
echo To view the log file:
echo   type %LOG_FILE%
echo.
echo To compile the LaTeX:
echo   pdflatex %OUTPUT_FILE%
echo.

pause