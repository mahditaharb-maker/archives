@echo off
echo ======================================================================
echo Testing Python Installation
echo ======================================================================
echo.

set PYTHON_PATH=D:\apps\Python38_updated\python.exe

if exist "%PYTHON_PATH%" (
    echo [OK] Python found at: %PYTHON_PATH%
    echo.
    echo Python version:
    "%PYTHON_PATH%" --version
    echo.
    echo Python path:
    "%PYTHON_PATH%" -c "import sys; print(sys.executable)"
    echo.
    echo Python sys.path:
    "%PYTHON_PATH%" -c "import sys; print(sys.path)"
) else (
    echo [FAIL] Python NOT found at: %PYTHON_PATH%
    echo.
    echo Searching for Python...
    where python
)

echo.
pause