@echo off
setlocal enabledelayedexpansion
title PDF Compiler and Converter
color 0A

:: ============================================
:: CONFIGURATION
:: ============================================
set RESOLUTION=150
set OUTPUT_DIR=PNG_Output
set LOG_FILE=compile_log.txt
set CONFIG_FILE=compile_config.txt
set USE_GHOSTSCRIPT=1

:: ============================================
:: CHECK FOR SAVED CONFIGURATION IN compile_config.txt
:: ============================================
echo ============================================================
echo   PDF Compiler and Converter - Full Automatic Workflow
echo ============================================================
echo.
echo Starting at: %date% %time%
echo.

set TEXLIVE_PATH=
set GS_EXE=
set PDF_VIEWER=
set TEX_FOUND=0
set GS_FOUND=0
set PDF_FOUND=0
set CONFIG_VALID=0

:: ************************************************************
:: STEP 1: CHECK IF compile_config.txt EXISTS
:: ************************************************************
if exist "%CONFIG_FILE%" (
    echo Loading saved configuration from %CONFIG_FILE%...
    echo.
    
    :: ************************************************************
    :: STEP 2: READ PATHS FROM compile_config.txt
    :: ************************************************************
    for /f "usebackq tokens=1,* delims==" %%a in ("%CONFIG_FILE%") do (
        if "%%a"=="TEXLIVE_PATH" set TEXLIVE_PATH=%%b
        if "%%a"=="GS_EXE" set GS_EXE=%%b
        if "%%a"=="PDF_VIEWER" set PDF_VIEWER=%%b
        if "%%a"=="USE_GHOSTSCRIPT" set USE_GHOSTSCRIPT=%%b
    )
    
    :: ************************************************************
    :: STEP 3: VERIFY THE SAVED PATHS EXIST ON DISK
    :: ************************************************************
    set CONFIG_VALID=0
    
    :: Check if TeX Live path is defined and exists
    if defined TEXLIVE_PATH (
        if exist "!TEXLIVE_PATH!pdflatex.exe" (
            set CONFIG_VALID=1
        )
    )
    
    :: If TeX Live is valid, check Ghostscript only if enabled
    if !CONFIG_VALID!==1 (
        if !USE_GHOSTSCRIPT!==1 (
            :: Ghostscript is enabled, check if GS_EXE exists
            if defined GS_EXE (
                if exist "!GS_EXE!" (
                    set CONFIG_VALID=1
                ) else (
                    set CONFIG_VALID=0
                )
            ) else (
                set CONFIG_VALID=0
            )
        ) else (
            :: Ghostscript is disabled, so we don't need to validate GS_EXE
            set CONFIG_VALID=1
            set GS_EXE=
        )
    )
    
    :: ************************************************************
    :: STEP 4: IF ALL REQUIRED PATHS EXIST -> PROCEED TO COMPILATION
    :: ************************************************************
    if !CONFIG_VALID!==1 (
        echo ============================================================
        echo   Using saved configuration from compile_config.txt:
        echo   - TeX Live: !TEXLIVE_PATH!
        if !USE_GHOSTSCRIPT!==1 (
            echo   - Ghostscript: !GS_EXE!
        ) else (
            echo   - Ghostscript: DISABLED
        )
        if defined PDF_VIEWER (
            if exist "!PDF_VIEWER!" (
                echo   - PDF Viewer: !PDF_VIEWER!
            )
        )
        echo   - PNG Conversion: !USE_GHOSTSCRIPT!
        echo ============================================================
        echo.
        echo All required paths are valid. Proceeding to compilation...
        echo.
        timeout /t 2 /nobreak >nul
        
        :: If Ghostscript is disabled, skip the question and go directly to compile
        if !USE_GHOSTSCRIPT!==0 (
            echo Ghostscript is disabled. Skipping PNG conversion.
            echo.
            timeout /t 1 /nobreak >nul
            goto :compile
        )
        goto :ask_use_ghostscript
    )
    
    :: ************************************************************
    :: STEP 5: IF SAVED PATHS ARE INVALID -> ASK FOR NEW ONES
    :: ************************************************************
    echo.
    echo ============================================================
    echo   SAVED CONFIGURATION IS INVALID
    echo ============================================================
    echo.
    echo The paths in %CONFIG_FILE% are no longer valid.
    echo.
    echo Current values:
    echo   TEXLIVE_PATH=!TEXLIVE_PATH!
    echo   GS_EXE=!GS_EXE!
    echo   USE_GHOSTSCRIPT=!USE_GHOSTSCRIPT!
    echo.
    echo Please re-enter all paths.
    echo.
    timeout /t 3 /nobreak >nul
    goto :ask_tex_path
)

:: ************************************************************
:: STEP 6: FIRST TIME SETUP - NO compile_config.txt EXISTS
:: ************************************************************
echo.
echo ============================================================
echo   FIRST TIME SETUP - No configuration found
echo ============================================================
echo.
echo Please enter the paths to required programs.
echo These will be saved to %CONFIG_FILE% for future use.
echo.

:: ============================================
:: PART 1: ASK FOR TEXLIVE PATH
:: ============================================
:ask_tex_path
echo.
echo ============================================================
echo   ENTER TeX Live PATH
echo ============================================================
echo.
echo Example: E:\archives\25\Doctorate\texlive\2024\bin\windows\
echo Or press ENTER for automatic search
echo.
set /p TEXLIVE_PATH="Enter TeX Live bin path: "

set TEX_FOUND=0

:: If user pressed ENTER, try automatic search
if "!TEXLIVE_PATH!"=="" (
    echo.
    echo No path entered. Attempting automatic search...
    echo.
    goto :auto_search_tex
)

:: Add trailing backslash if missing
if not "!TEXLIVE_PATH:~-1!"=="\" set TEXLIVE_PATH=!TEXLIVE_PATH!\

:: Check if pdflatex exists at the entered path
if exist "!TEXLIVE_PATH!pdflatex.exe" (
    set TEX_FOUND=1
    echo FOUND: !TEXLIVE_PATH!pdflatex.exe
    echo.
    goto :tex_found
) else (
    echo NOT FOUND: !TEXLIVE_PATH!pdflatex.exe
    echo.
    echo Please enter a valid path.
    echo.
    goto :ask_tex_path
)

:auto_search_tex
echo Searching for TeX Live (pdflatex.exe) automatically...
echo.

:: Check specific path first
if exist "E:\archives\25\Doctorate\texlive\2024\bin\windows\pdflatex.exe" (
    set TEXLIVE_PATH=E:\archives\25\Doctorate\texlive\2024\bin\windows\
    set TEX_FOUND=1
    echo FOUND: E:\archives\25\Doctorate\texlive\2024\bin\windows\pdflatex.exe
    goto :tex_found
)

:: Check PATH
where pdflatex.exe >nul 2>nul
if not errorlevel 1 (
    for /f "delims=" %%i in ('where pdflatex.exe') do (
        echo %%i | find /i "texlive" >nul
        if not errorlevel 1 (
            set TEXLIVE_PATH=%%~dpi
            set TEX_FOUND=1
            echo FOUND TeX Live in PATH: %%i
            goto :tex_found
        )
    )
)

:: Check common TeX Live locations
if exist "C:\texlive\2024\bin\windows\pdflatex.exe" (
    set TEXLIVE_PATH=C:\texlive\2024\bin\windows\
    set TEX_FOUND=1
    echo FOUND: C:\texlive\2024\bin\windows\pdflatex.exe
    goto :tex_found
)
if exist "C:\texlive\2023\bin\windows\pdflatex.exe" (
    set TEXLIVE_PATH=C:\texlive\2023\bin\windows\
    set TEX_FOUND=1
    echo FOUND: C:\texlive\2023\bin\windows\pdflatex.exe
    goto :tex_found
)
if exist "D:\texlive\2024\bin\windows\pdflatex.exe" (
    set TEXLIVE_PATH=D:\texlive\2024\bin\windows\
    set TEX_FOUND=1
    echo FOUND: D:\texlive\2024\bin\windows\pdflatex.exe
    goto :tex_found
)
if exist "E:\texlive\2024\bin\windows\pdflatex.exe" (
    set TEXLIVE_PATH=E:\texlive\2024\bin\windows\
    set TEX_FOUND=1
    echo FOUND: E:\texlive\2024\bin\windows\pdflatex.exe
    goto :tex_found
)

echo NOT FOUND in any location.
echo.
goto :ask_tex_path

:tex_found
if %TEX_FOUND%==1 (
    echo.
    echo ========================================
    echo   TeX Live FOUND!
    echo ========================================
    echo Path: !TEXLIVE_PATH!
    echo.
    goto :ask_use_ghostscript
)

:tex_not_found
echo.
echo ============================================================
echo                TeX Live NOT FOUND!
echo ============================================================
echo.
echo Please install TeX Live from: https://tug.org/texlive/
echo.
goto :end_program

:: ============================================
:: PART 2: ASK IF GHOSTSCRIPT SHOULD BE USED
:: ============================================
:ask_use_ghostscript
echo.
echo ============================================================
echo   USE GHOSTSCRIPT FOR PNG CONVERSION?
echo ============================================================
echo.
echo This will convert the PDF to PNG images.
echo.
echo Enter Y for YES (complete proceeding with PNG conversion)
echo Enter N for NO  (just compile PDF and open it)
echo.
set /p USE_GS_INPUT="Use Ghostscript? (Y/N): "

:: Convert input to uppercase
set USE_GS_INPUT=!USE_GS_INPUT:~0,1!
if /i "!USE_GS_INPUT!"=="Y" (
    set USE_GHOSTSCRIPT=1
    echo.
    echo You chose: Convert PDF to PNG using Ghostscript
    echo.
    :: Check if GS_EXE is already set and valid
    if defined GS_EXE (
        if exist "!GS_EXE!" (
            echo Using existing Ghostscript path: !GS_EXE!
            goto :ask_pdf_viewer
        )
    )
    goto :ask_gs_path
) else if /i "!USE_GS_INPUT!"=="N" (
    set USE_GHOSTSCRIPT=0
    echo.
    echo You chose: Only compile PDF (no PNG conversion)
    echo.
    set GS_EXE=
    goto :ask_pdf_viewer
) else (
    echo.
    echo Invalid input. Please enter Y or N.
    echo.
    goto :ask_use_ghostscript
)

:: ============================================
:: PART 3: ASK FOR GHOSTSCRIPT PATH
:: ============================================
:ask_gs_path
echo.
echo ============================================================
echo   ENTER GHOSTSCRIPT PATH
echo ============================================================
echo.
echo IMPORTANT: You MUST enter the path to gswin64.exe
echo Example: E:\archives\27\Maths\Academia\Proceeding\Test\Files\pdf2png\gswin64.exe
echo.
set /p GS_EXE="Enter Ghostscript path (gswin64.exe): "

:: Check if user entered a path
if "!GS_EXE!"=="" (
    echo.
    echo ERROR: You must enter a Ghostscript path!
    echo.
    echo Please enter a valid path.
    echo.
    goto :ask_gs_path
)

:: Remove quotes if present
set GS_EXE=!GS_EXE:"=!

:: Check if file exists
if exist "!GS_EXE!" (
    set GS_FOUND=1
    echo.
    echo FOUND: !GS_EXE!
    echo.
    goto :ask_pdf_viewer
) else (
    echo.
    echo ERROR: File not found: !GS_EXE!
    echo.
    echo Please check the path and try again.
    echo.
    goto :ask_gs_path
)

:: ============================================
:: PART 4: ASK FOR PDF VIEWER PATH
:: ============================================
:ask_pdf_viewer
echo.
echo ============================================================
echo   ENTER PDF VIEWER PATH
echo ============================================================
echo.
echo Example: C:\Program Files\SumatraPDF\SumatraPDF.exe
echo Or press ENTER to use Windows default PDF viewer
echo.
set /p PDF_VIEWER="Enter PDF Viewer path: "

set PDF_FOUND=0

:: If user pressed ENTER, use Windows default
if "!PDF_VIEWER!"=="" (
    echo.
    echo No PDF viewer path entered. Will use Windows default.
    echo.
    goto :save_config
)

:: Remove quotes if present
set PDF_VIEWER=!PDF_VIEWER:"=!

:: Check if file exists
if exist "!PDF_VIEWER!" (
    set PDF_FOUND=1
    echo FOUND: !PDF_VIEWER!
    echo.
) else (
    echo NOT FOUND: !PDF_VIEWER!
    echo.
    echo Will use Windows default.
    echo.
    set PDF_VIEWER=
    set PDF_FOUND=0
)

:: ============================================
:: SAVE CONFIGURATION TO compile_config.txt
:: ============================================
:save_config
echo.
echo ============================================================
echo   SAVING CONFIGURATION TO %CONFIG_FILE%
echo ============================================================
echo.
(
    echo TEXLIVE_PATH=!TEXLIVE_PATH!
    echo GS_EXE=!GS_EXE!
    echo PDF_VIEWER=!PDF_VIEWER!
    echo USE_GHOSTSCRIPT=!USE_GHOSTSCRIPT!
) > "%CONFIG_FILE%"
echo Configuration saved successfully to: %CD%\%CONFIG_FILE%
echo.
echo Content of %CONFIG_FILE%:
echo ----------------------------------------
type "%CONFIG_FILE%"
echo ----------------------------------------
echo.
timeout /t 2 /nobreak >nul

:: ============================================
:: PART 5: COMPILE
:: ============================================
:compile
echo.
echo ========================================
echo   Compiling LaTeX Document
echo ========================================
echo.

set FILENAME=
for %%f in (*.tex) do (
    set FILENAME=%%~nf
    set FULLTEX=%%f
    echo Found: !FILENAME!.tex
    goto :found_tex
)

if not defined FILENAME (
    echo.
    echo ============================================================
    echo   ERROR: No .tex file found!
    echo ============================================================
    echo.
    echo Current directory: %CD%
    echo Please place your .tex file in this folder.
    echo.
    goto :end_program
)

:found_tex
echo.

:: Kill PDF viewers
echo Closing PDF viewers...
taskkill /f /im Acrobat.exe 2>nul
taskkill /f /im AcroRd32.exe 2>nul
taskkill /f /im AcrobatReader.exe 2>nul
taskkill /f /im AcroCEF.exe 2>nul
taskkill /f /im FoxitReader.exe 2>nul
taskkill /f /im FoxitPDFReader.exe 2>nul
taskkill /f /im SumatraPDF.exe 2>nul
timeout /t 1 /nobreak >nul
echo Done.
echo.

:: Clean old files
echo Cleaning old files...
if exist "!FILENAME!.pdf" (
    attrib -r "!FILENAME!.pdf" 2>nul
    del /f /q "!FILENAME!.pdf" 2>nul
)
del /f /q "!FILENAME!.aux" "!FILENAME!.bbl" "!FILENAME!.bcf" "!FILENAME!.blg" 2>nul
del /f /q "!FILENAME!.idx" "!FILENAME!.ilg" "!FILENAME!.ind" 2>nul
del /f /q "!FILENAME!.log" "!FILENAME!.out" "!FILENAME!.toc" 2>nul
del /f /q "!FILENAME!.synctex.gz" "!FILENAME!.run.xml" 2>nul
del /f /q "indexstyle.ist" "references.bib" 2>nul
echo Done.
echo.

:: pdflatex pass 1
echo [1/5] First pdflatex pass...
"!TEXLIVE_PATH!pdflatex.exe" -interaction=nonstopmode "!FULLTEX!"
if errorlevel 1 (
    echo.
    echo ============================================================
    echo   ERROR: First pdflatex pass failed!
    echo ============================================================
    echo.
    echo Check !FILENAME!.log for errors
    echo.
    goto :end_program
)
echo OK.
echo.

:: bibtex
echo [2/5] Running bibtex...
if exist "!FILENAME!.aux" (
    "!TEXLIVE_PATH!bibtex.exe" "!FILENAME!"
    if errorlevel 1 (
        echo WARNING: BibTeX had issues
    ) else (
        echo OK.
    )
) else (
    echo Skipped (no .aux file)
)
echo.

:: makeindex
echo [3/5] Running makeindex...
if exist "!FILENAME!.idx" (
    if exist "indexstyle.ist" (
        "!TEXLIVE_PATH!makeindex.exe" -s indexstyle.ist "!FILENAME!.idx"
    ) else (
        "!TEXLIVE_PATH!makeindex.exe" "!FILENAME!.idx"
    )
    echo OK.
) else (
    echo Skipped (no index file)
)
echo.

:: pdflatex pass 2
echo [4/5] Second pdflatex pass...
"!TEXLIVE_PATH!pdflatex.exe" -interaction=nonstopmode "!FULLTEX!"
if errorlevel 1 (
    echo.
    echo ============================================================
    echo   ERROR: Second pdflatex pass failed!
    echo ============================================================
    echo.
    echo Check !FILENAME!.log for errors
    echo.
    goto :end_program
)
echo OK.
echo.

:: pdflatex pass 3
echo [5/5] Final pdflatex pass...
"!TEXLIVE_PATH!pdflatex.exe" -interaction=nonstopmode "!FULLTEX!"
if errorlevel 1 (
    echo.
    echo ============================================================
    echo   ERROR: Final pdflatex pass failed!
    echo ============================================================
    echo.
    echo Check !FILENAME!.log for errors
    echo.
    goto :end_program
)
echo OK.
echo.

if not exist "!FILENAME!.pdf" (
    echo.
    echo ============================================================
    echo   ERROR: PDF not created!
    echo ============================================================
    echo.
    echo Check !FILENAME!.log for errors
    echo.
    goto :end_program
)

echo.
echo ========================================
echo   COMPILATION SUCCESSFUL!
echo ========================================
echo PDF created: !FILENAME!.pdf
for %%i in ("!FILENAME!.pdf") do echo Size: %%~zi bytes
echo.

:: ============================================
:: PART 6: CONVERT PDF TO PNG (IF SELECTED)
:: ============================================
if !USE_GHOSTSCRIPT!==1 (
    :: Check if GS_EXE is set and exists
    if defined GS_EXE (
        if exist "!GS_EXE!" (
            goto :convert_to_png
        ) else (
            echo.
            echo ============================================================
            echo   ERROR: Ghostscript path is invalid!
            echo ============================================================
            echo.
            echo GS_EXE=!GS_EXE! does not exist.
            echo Please re-run the script and enter a valid Ghostscript path.
            echo.
            goto :open_results
        )
    ) else (
        echo.
        echo ============================================================
        echo   ERROR: Ghostscript path not defined!
        echo ============================================================
        echo.
        echo GS_EXE is not set. Please re-run the script.
        echo.
        goto :open_results
    )
) else (
    echo.
    echo ========================================
    echo   SKIPPING PNG CONVERSION
    echo ========================================
    echo.
    echo Ghostscript conversion was skipped as per your selection.
    echo.
    goto :open_results
)

:convert_to_png
echo.
echo ========================================
echo   Creating Output Directory
echo ========================================
echo.

if not exist "%OUTPUT_DIR%" (
    mkdir "%OUTPUT_DIR%"
    echo Created output directory: %OUTPUT_DIR%
    echo.
) else (
    echo Output directory already exists: %OUTPUT_DIR%
    echo.
)

echo.
echo ========================================
echo   Converting PDF to PNG
echo ========================================
echo.

set GS_OPTS=-dNOPAUSE -dBATCH -dSAFER -sDEVICE=png16m
set OUTFILE=%OUTPUT_DIR%\!FILENAME!_page%%d.png

echo Ghostscript path: !GS_EXE!
echo PDF file: !FILENAME!.pdf
echo Output folder: %OUTPUT_DIR%
echo Resolution: %RESOLUTION% DPI
echo.
echo Command: "!GS_EXE!" %GS_OPTS% -r%RESOLUTION% -sOutputFile="%OUTFILE%" "!FILENAME!.pdf"
echo.
echo Running Ghostscript...
echo.

"!GS_EXE!" %GS_OPTS% -r%RESOLUTION% -sOutputFile="%OUTFILE%" "!FILENAME!.pdf"

set GS_RESULT=%errorlevel%
echo Ghostscript exit code: %GS_RESULT%

if %GS_RESULT%==0 (
    echo.
    echo ========================================
    echo   Ghostscript completed successfully!
    echo ========================================
    echo.
    
    :: Count PNG files created
    set PNG_COUNT=0
    for %%p in ("%OUTPUT_DIR%\!FILENAME!_page*.png") do set /a PNG_COUNT+=1
    
    echo PNG files found: !PNG_COUNT!
    
    if !PNG_COUNT!==0 (
        echo.
        echo ============================================================
        echo   WARNING: No PNG files created!
        echo ============================================================
        echo.
        echo Ghostscript ran but no PNG files were generated.
        echo.
        echo Possible issues:
        echo   1. PDF has no pages
        echo   2. Ghostscript version is incompatible
        echo   3. Output path is not writable
        echo.
    ) else (
        echo.
        echo ========================================
        echo   CONVERSION SUCCESSFUL!
        echo ========================================
        echo Created !PNG_COUNT! PNG file(s)
        echo.
        echo PNG files in: %CD%\%OUTPUT_DIR%
        echo.
        dir "%OUTPUT_DIR%\!FILENAME!_page*.png"
    )
) else (
    echo.
    echo ============================================================
    echo   ERROR: Ghostscript conversion failed!
    echo ============================================================
    echo.
    echo Exit code: %GS_RESULT%
    echo.
)

:: ============================================
:: PART 7: OPEN RESULTS
:: ============================================
:open_results
echo.
echo ========================================
echo   Opening Results
echo ========================================
echo.

:: Check if PDF viewer exists and use it
if defined PDF_VIEWER (
    if exist "!PDF_VIEWER!" (
        echo Opening PDF with: !PDF_VIEWER!
        start "" "!PDF_VIEWER!" "!FILENAME!.pdf"
    ) else (
        echo PDF viewer not found. Trying Windows default...
        start "" "!FILENAME!.pdf"
    )
) else (
    echo No PDF viewer specified. Trying Windows default...
    start "" "!FILENAME!.pdf"
)

if !USE_GHOSTSCRIPT!==1 (
    if exist "%OUTPUT_DIR%\!FILENAME!_page*.png" (
        echo.
        echo Opening PNG folder...
        start explorer "%OUTPUT_DIR%"
    )
)

echo.
echo ============================================================
echo   PROCESS COMPLETED!
echo ============================================================
echo.
echo Summary:
echo   - Configuration file: %CD%\%CONFIG_FILE%
echo   - TeX Live: !TEXLIVE_PATH!
echo   - PDF: %CD%\!FILENAME!.pdf
if defined PDF_VIEWER (
    if exist "!PDF_VIEWER!" echo   - PDF Viewer: !PDF_VIEWER!
)
if !USE_GHOSTSCRIPT!==1 (
    echo   - Ghostscript: !GS_EXE!
    if exist "%OUTPUT_DIR%\!FILENAME!_page*.png" echo   - PNGs: %CD%\%OUTPUT_DIR%\
) else (
    echo   - PNG Conversion: SKIPPED
)
echo.
echo Completed at: %date% %time%
echo.

:: ============================================
:: END - ALWAYS PAUSES
:: ============================================
:end_program
echo.
echo ============================================================
echo   PRESS ANY KEY TO CLOSE THIS WINDOW
echo ============================================================
pause >nul
exit /b 0