@echo off
setlocal

REM ---- Set default filename ----
if "%1"=="" (set TEXFILE=13.tex) else (set TEXFILE=%1)

REM ---- Paths ----
set TEXLIVE=E:\Processings\Doctorate\texlive\2024\bin\windows
set NODEJS=E:\Processings\Online_Softwares\tools\node-v13.14.0-win-x64
set NPM_GLOBAL=%APPDATA%\npm

set PUPPETEER_SKIP_CHROMIUM_DOWNLOAD=true
set PUPPETEER_EXECUTABLE_PATH=D:\apps\chrome+idm\Google\Chrome\Application\chrome.exe
set PUPPETEER_LAUNCH_ARGS=--no-sandbox --disable-setuid-sandbox --disable-gpu

set PATH=%TEXLIVE%;%NODEJS%;%NPM_GLOBAL%;%PATH%

REM ---- Clean auxiliary files ----
echo Cleaning auxiliary files...
del /q *.aux *.toc *.out *.log *.lof *.lot 2>nul

echo Compiling %TEXFILE% ...
lualatex -shell-escape %TEXFILE%
if errorlevel 1 (
    echo First pass failed. Check %TEXFILE:.tex=.log%
    pause
    exit /b 1
)

lualatex -shell-escape %TEXFILE%
if errorlevel 1 (
    echo Second pass failed. Check %TEXFILE:.tex=.log%
    pause
    exit /b 1
)

echo Compilation successful.
pause