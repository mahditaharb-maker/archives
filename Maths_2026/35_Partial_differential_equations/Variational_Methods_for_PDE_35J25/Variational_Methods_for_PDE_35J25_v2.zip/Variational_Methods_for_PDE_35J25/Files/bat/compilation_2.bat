@echo off
setlocal enabledelayedexpansion

echo ========================================
echo   Quick PDF Update with SumatraPDF
echo ========================================
echo.

set TEXLIVE_PATH=E:/archives/25/Doctorate/texlive/2024/bin/windows/
set SUMATRA_EXE=SumatraPDF.exe

echo Searching for .tex file...
for %%f in (*.tex) do (
    set FILENAME=%%~nf
    set FULLTEX=%%f
    goto :found
)
echo ERROR: No .tex file found!
pause
goto :end

:found
echo Compiling: !FILENAME!.tex
echo.

echo Killing PDF viewers only (keeping browsers and SumatraPDF)...
taskkill /f /im Acrobat.exe 2>nul
taskkill /f /im AcroRd32.exe 2>nul
taskkill /f /im AcrobatReader.exe 2>nul
taskkill /f /im AcroCEF.exe 2>nul
taskkill /f /im FoxitReader.exe 2>nul
taskkill /f /im FoxitPDFReader.exe 2>nul
:: SumatraPDF is NOT killed - removed from the list
timeout /t 1 /nobreak >nul
echo Done.
echo.

"%TEXLIVE_PATH%pdflatex.exe" -interaction=nonstopmode "!FULLTEX!"

if errorlevel 1 (
    echo.
    echo ERROR: Compilation failed!
    echo Check !FILENAME!.log for details
    pause
    goto :end
)

echo.
echo SUCCESS: !FILENAME!.pdf updated
echo.

echo Opening with SumatraPDF...
set "PDFFILE=!CD!\!FILENAME!.pdf"

if exist "!CD!\!SUMATRA_EXE!" (
    start "" "!CD!\!SUMATRA_EXE!" -reuse-instance "!PDFFILE!"
) else (
    where !SUMATRA_EXE! >nul 2>nul
    if errorlevel 1 (
        echo WARNING: SumatraPDF not found!
        echo PDF created at: !PDFFILE!
    ) else (
        start "" !SUMATRA_EXE! -reuse-instance "!PDFFILE!"
    )
)

:end
echo.
pause