@echo off
setlocal enabledelayedexpansion
title PNG Generator
color 0A

echo ============================================================
echo   GENERATE PNG FROM TIKZ TREE
echo ============================================================
echo.

if not exist "test.tex" (
    echo ERROR: test.tex not found!
    pause
    exit /b 1
)

echo Found: test.tex
echo.

:: Find TeX Live
set TEXLIVE_PATH=
if exist "E:\archives\25\Doctorate\texlive\2024\bin\windows\pdflatex.exe" (
    set TEXLIVE_PATH=E:\archives\25\Doctorate\texlive\2024\bin\windows\
    echo FOUND: E:\archives\25\Doctorate\texlive\2024\bin\windows\pdflatex.exe
    goto :tex_found
)

where pdflatex.exe >nul 2>nul
if not errorlevel 1 (
    for /f "delims=" %%i in ('where pdflatex.exe') do (
        set TEXLIVE_PATH=%%~dpi
        echo FOUND in PATH: %%i
        goto :tex_found
    )
)

echo ERROR: TeX Live not found!
pause
exit /b 1

:tex_found
echo.
echo ============================================================
echo   COMPILING...
echo ============================================================
echo.

:: Clean
if exist "test.pdf" del /f /q "test.pdf" 2>nul
del /f /q "test.aux" "test.log" "test.out" "test.toc" 2>nul

:: Compile (2 passes enough for standalone)
"!TEXLIVE_PATH!pdflatex.exe" -interaction=nonstopmode test.tex > compile_log.txt 2>&1
"!TEXLIVE_PATH!pdflatex.exe" -interaction=nonstopmode test.tex >> compile_log.txt 2>&1

if not exist "test.pdf" (
    echo ERROR: PDF not created!
    pause
    exit /b 1
)

echo PDF created: test.pdf
echo.

:: Find Ghostscript
set GS_EXE=
if exist "E:\archives\27\Maths\Academia\Proceeding\Test\Files\pdf2png\gswin64.exe" (
    set GS_EXE=E:\archives\27\Maths\Academia\Proceeding\Test\Files\pdf2png\gswin64.exe
    echo FOUND: !GS_EXE!
    goto :gs_found
)

where gswin64.exe >nul 2>nul
if not errorlevel 1 (
    for /f "delims=" %%i in ('where gswin64.exe') do (
        set GS_EXE=%%i
        echo FOUND in PATH: !GS_EXE!
        goto :gs_found
    )
)

echo WARNING: Ghostscript not found!
echo Please download from: https://ghostscript.com/
pause
exit /b 1

:gs_found
echo.
echo ============================================================
echo   CONVERTING PDF TO PNG...
echo ============================================================
echo.

set OUTPUT_DIR=PNG_Output
if not exist "%OUTPUT_DIR%" mkdir "%OUTPUT_DIR%"

"!GS_EXE!" -dNOPAUSE -dBATCH -dSAFER -sDEVICE=png16m -r300 -sOutputFile="%OUTPUT_DIR%\test_page%%d.png" test.pdf

if errorlevel 1 (
    echo ERROR: Conversion failed!
    pause
    exit /b 1
)

echo.
echo ============================================================
echo   SUCCESS!
echo ============================================================
echo.
echo PNG created: %OUTPUT_DIR%\test_page1.png
echo.
start explorer "%OUTPUT_DIR%"
pause