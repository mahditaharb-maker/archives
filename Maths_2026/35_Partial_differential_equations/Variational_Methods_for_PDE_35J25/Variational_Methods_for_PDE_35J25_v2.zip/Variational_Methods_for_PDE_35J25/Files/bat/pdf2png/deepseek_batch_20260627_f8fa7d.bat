@echo off
setlocal enabledelayedexpansion
title PDF Compiler & Converter
color 0A

:: ============================================
:: CONFIGURATION
:: ============================================
set RESOLUTION=150
set OUTPUT_DIR=PNG_Output

echo ============================================================
echo   PDF Compiler & Converter - Full Automatic Workflow
echo ============================================================
echo.
echo Starting at: %date% %time%
echo.

:: ============================================
:: PART 1: FIND TEXLIVE
:: ============================================
echo ========================================
echo   PART 1: Finding TeX Live
echo ========================================
echo.

set TEXLIVE_PATH=
set TEX_FOUND=0

echo Searching for TeX Live (pdflatex.exe)...
echo.

:: Check specific path first (from your original script)
echo [1] Checking specific path...
if exist "E:\archives\25\Doctorate\texlive\2024\bin\windows\pdflatex.exe" (
    set TEXLIVE_PATH=E:\archives\25\Doctorate\texlive\2024\bin\windows\
    set TEX_FOUND=1
    echo     FOUND: E:\archives\25\Doctorate\texlive\2024\bin\windows\pdflatex.exe
    goto :tex_found
) else (
    echo     Not found at specific path.
)
echo.

:: Check PATH
echo [2] Checking system PATH...
where pdflatex.exe >nul 2>nul
if not errorlevel 1 (
    for /f "delims=" %%i in ('where pdflatex.exe') do (
        set TEXLIVE_PATH=%%~dpi
        set TEX_FOUND=1
        echo     FOUND in PATH: %%i
        goto :tex_found
    )
) else (
    echo     Not found in PATH.
)
echo.

:: Search C: drive
echo [3] Searching C: drive for pdflatex.exe...
echo     This may take a moment...
for /r C:\ %%i in (pdflatex.exe) do (
    if exist "%%i" (
        set TEXLIVE_PATH=%%~dpi
        set TEX_FOUND=1
        echo     FOUND: %%i
        goto :tex_found
    )
)
echo     Not found on C: drive.
echo.

:: Search D: drive
if exist D:\ (
    echo [4] Searching D: drive for pdflatex.exe...
    echo     This may take a moment...
    for /r D:\ %%i in (pdflatex.exe) do (
        if exist "%%i" (
            set TEXLIVE_PATH=%%~dpi
            set TEX_FOUND=1
            echo     FOUND: %%i
            goto :tex_found
        )
    )
    echo     Not found on D: drive.
) else (
    echo [4] D: drive does not exist. Skipping.
)
echo.

:: Search E: drive
if exist E:\ (
    echo [5] Searching E: drive for pdflatex.exe...
    echo     This may take a moment...
    for /r E:\ %%i in (pdflatex.exe) do (
        if exist "%%i" (
            set TEXLIVE_PATH=%%~dpi
            set TEX_FOUND=1
            echo     FOUND: %%i
            goto :tex_found
        )
    )
    echo     Not found on E: drive.
) else (
    echo [5] E: drive does not exist. Skipping.
)
echo.

:: Search F: drive
if exist F:\ (
    echo [6] Searching F: drive for pdflatex.exe...
    echo     This may take a moment...
    for /r F:\ %%i in (pdflatex.exe) do (
        if exist "%%i" (
            set TEXLIVE_PATH=%%~dpi
            set TEX_FOUND=1
            echo     FOUND: %%i
            goto :tex_found
        )
    )
    echo     Not found on F: drive.
) else (
    echo [6] F: drive does not exist. Skipping.
)
echo.

:: Search G: drive
if exist G:\ (
    echo [7] Searching G: drive for pdflatex.exe...
    echo     This may take a moment...
    for /r G:\ %%i in (pdflatex.exe) do (
        if exist "%%i" (
            set TEXLIVE_PATH=%%~dpi
            set TEX_FOUND=1
            echo     FOUND: %%i
            goto :tex_found
        )
    )
    echo     Not found on G: drive.
) else (
    echo [7] G: drive does not exist. Skipping.
)
echo.

:: Search H: drive
if exist H:\ (
    echo [8] Searching H: drive for pdflatex.exe...
    echo     This may take a moment...
    for /r H:\ %%i in (pdflatex.exe) do (
        if exist "%%i" (
            set TEXLIVE_PATH=%%~dpi
            set TEX_FOUND=1
            echo     FOUND: %%i
            goto :tex_found
        )
    )
    echo     Not found on H: drive.
) else (
    echo [8] H: drive does not exist. Skipping.
)
echo.

:tex_found
if %TEX_FOUND%==0 (
    echo.
    echo ========================================
    echo   ERROR: TeX Live NOT found!
    echo ========================================
    echo.
    echo Searched:
    echo   - Specific: E:\archives\25\Doctorate\texlive\2024\bin\windows\
    echo   - System PATH
    echo   - C: drive
    echo   - D: drive
    echo   - E: drive
    echo   - F: drive
    echo   - G: drive
    echo   - H: drive
    echo.
    echo Please install TeX Live or MiKTeX
    echo Download: https://tug.org/texlive/
    echo.
    echo Press any key to exit...
    pause >nul
    exit /b 1
)

echo.
echo ========================================
echo   TeX Live FOUND!
echo ========================================
echo Path: !TEXLIVE_PATH!
echo.

:: ============================================
:: PART 2: FIND LATEX FILE AND COMPILE
:: ============================================
echo ========================================
echo   PART 2: Compiling LaTeX Document
echo ========================================
echo.

set FILENAME=
for %%f in (*.tex) do (
    set FILENAME=%%~nf
    set FULLTEX=%%f
    echo Found: !FILENAME!.tex
    goto :found_tex
)

if not defined FILENAME (
    echo.
    echo ========================================
    echo   ERROR: No .tex file found!
    echo ========================================
    echo.
    echo Current directory: %CD%
    echo Please place your .tex file in this folder.
    echo.
    echo Press any key to exit...
    pause >nul
    exit /b 1
)

:found_tex
echo.

:: Kill PDF viewers
echo Closing PDF viewers...
taskkill /f /im Acrobat.exe 2>nul
taskkill /f /im AcroRd32.exe 2>nul
taskkill /f /im AcrobatReader.exe 2>nul
taskkill /f /im AcroCEF.exe 2>nul
taskkill /f /im FoxitReader.exe 2>nul
taskkill /f /im FoxitPDFReader.exe 2>nul
taskkill /f /im SumatraPDF.exe 2>nul
timeout /t 1 /nobreak >nul
echo.

:: Clean old files
echo Cleaning old files...
if exist "!FILENAME!.pdf" (
    attrib -r "!FILENAME!.pdf" 2>nul
    del /f /q "!FILENAME!.pdf" 2>nul
)
del /f /q "!FILENAME!.aux" "!FILENAME!.bbl" "!FILENAME!.bcf" "!FILENAME!.blg" 2>nul
del /f /q "!FILENAME!.idx" "!FILENAME!.ilg" "!FILENAME!.ind" 2>nul
del /f /q "!FILENAME!.log" "!FILENAME!.out" "!FILENAME!.toc" 2>nul
del /f /q "!FILENAME!.synctex.gz" "!FILENAME!.run.xml" 2>nul
del /f /q "indexstyle.ist" "references.bib" 2>nul
echo Done.
echo.

:: pdflatex pass 1
echo [1/5] First pdflatex pass...
"!TEXLIVE_PATH!pdflatex.exe" -interaction=nonstopmode "!FULLTEX!" 
if errorlevel 1 (
    echo.
    echo ========================================
    echo   ERROR: First pdflatex pass failed!
    echo ========================================
    echo.
    echo Check !FILENAME!.log for errors
    echo.
    echo Press any key to exit...
    pause >nul
    exit /b 1
)
echo OK.
echo.

:: bibtex
echo [2/5] Running bibtex...
if exist "!FILENAME!.aux" (
    "!TEXLIVE_PATH!bibtex.exe" "!FILENAME!"
    if errorlevel 1 (
        echo WARNING: BibTeX had issues
    ) else (
        echo OK.
    )
) else (
    echo Skipped (no .aux file)
)
echo.

:: makeindex
echo [3/5] Running makeindex...
if exist "!FILENAME!.idx" (
    if exist "indexstyle.ist" (
        "!TEXLIVE_PATH!makeindex.exe" -s indexstyle.ist "!FILENAME!.idx"
    ) else (
        "!TEXLIVE_PATH!makeindex.exe" "!FILENAME!.idx"
    )
    echo OK.
) else (
    echo Skipped (no index file)
)
echo.

:: pdflatex pass 2
echo [4/5] Second pdflatex pass...
"!TEXLIVE_PATH!pdflatex.exe" -interaction=nonstopmode "!FULLTEX!"
if errorlevel 1 (
    echo.
    echo ========================================
    echo   ERROR: Second pdflatex pass failed!
    echo ========================================
    echo.
    echo Check !FILENAME!.log for errors
    echo.
    echo Press any key to exit...
    pause >nul
    exit /b 1
)
echo OK.
echo.

:: pdflatex pass 3
echo [5/5] Final pdflatex pass...
"!TEXLIVE_PATH!pdflatex.exe" -interaction=nonstopmode "!FULLTEX!"
if errorlevel 1 (
    echo.
    echo ========================================
    echo   ERROR: Final pdflatex pass failed!
    echo ========================================
    echo.
    echo Check !FILENAME!.log for errors
    echo.
    echo Press any key to exit...
    pause >nul
    exit /b 1
)
echo OK.
echo.

if not exist "!FILENAME!.pdf" (
    echo.
    echo ========================================
    echo   ERROR: PDF not created!
    echo ========================================
    echo.
    echo Check !FILENAME!.log for errors
    echo.
    echo Press any key to exit...
    pause >nul
    exit /b 1
)

echo ========================================
echo   COMPILATION SUCCESSFUL!
echo ========================================
echo PDF created: !FILENAME!.pdf
for %%i in ("!FILENAME!.pdf") do echo Size: %%~zi bytes
echo.

:: ============================================
:: PART 3: FIND GHOSTSCRIPT
:: ============================================
echo ========================================
echo   PART 3: Finding Ghostscript
echo ========================================
echo.

set GS_EXE=
set GS_FOUND=0

echo Searching for Ghostscript (gswin64.exe / gswin64c.exe)...
echo.

:: Check specific path first
echo [1] Checking specific path...
if exist "E:\archives\27\Maths\Academia\Proceeding\Test\Files\pdf2png\gswin64.exe" (
    set GS_EXE=E:\archives\27\Maths\Academia\Proceeding\Test\Files\pdf2png\gswin64.exe
    set GS_FOUND=1
    echo     FOUND: !GS_EXE!
    goto :gs_found
) else (
    echo     Not found at specific path.
)
echo.

:: Check PATH
echo [2] Checking system PATH...
where gswin64.exe >nul 2>nul
if not errorlevel 1 (
    for /f "delims=" %%i in ('where gswin64.exe') do (
        set GS_EXE=%%i
        set GS_FOUND=1
        echo     FOUND in PATH: %%i
        goto :gs_found
    )
)
where gswin64c.exe >nul 2>nul
if not errorlevel 1 (
    for /f "delims=" %%i in ('where gswin64c.exe') do (
        set GS_EXE=%%i
        set GS_FOUND=1
        echo     FOUND in PATH: %%i
        goto :gs_found
    )
)
echo     Not found in PATH.
echo.

:: Search current directory
echo [3] Searching current directory...
if exist "gswin64.exe" (
    set GS_EXE=%CD%\gswin64.exe
    set GS_FOUND=1
    echo     FOUND: !GS_EXE!
    goto :gs_found
)
if exist "gswin64c.exe" (
    set GS_EXE=%CD%\gswin64c.exe
    set GS_FOUND=1
    echo     FOUND: !GS_EXE!
    goto :gs_found
)
echo     Not found in current directory.
echo.

:: Search subdirectories
echo [4] Searching subdirectories...
for /r %%i in (gswin64.exe) do (
    if exist "%%i" (
        set GS_EXE=%%i
        set GS_FOUND=1
        echo     FOUND: %%i
        goto :gs_found
    )
)
for /r %%i in (gswin64c.exe) do (
    if exist "%%i" (
        set GS_EXE=%%i
        set GS_FOUND=1
        echo     FOUND: %%i
        goto :gs_found
    )
)
echo     Not found in subdirectories.
echo.

:: Search C: drive
echo [5] Searching C: drive for gswin64.exe...
echo     This may take a moment...
for /r C:\ %%i in (gswin64.exe) do (
    if exist "%%i" (
        set GS_EXE=%%i
        set GS_FOUND=1
        echo     FOUND: %%i
        goto :gs_found
    )
)
echo     Not found on C: drive.
echo.

:: Search D: drive
if exist D:\ (
    echo [6] Searching D: drive for gswin64.exe...
    echo     This may take a moment...
    for /r D:\ %%i in (gswin64.exe) do (
        if exist "%%i" (
            set GS_EXE=%%i
            set GS_FOUND=1
            echo     FOUND: %%i
            goto :gs_found
        )
    )
    echo     Not found on D: drive.
) else (
    echo [6] D: drive does not exist. Skipping.
)
echo.

:: Search E: drive
if exist E:\ (
    echo [7] Searching E: drive for gswin64.exe...
    echo     This may take a moment...
    for /r E:\ %%i in (gswin64.exe) do (
        if exist "%%i" (
            set GS_EXE=%%i
            set GS_FOUND=1
            echo     FOUND: %%i
            goto :gs_found
        )
    )
    echo     Not found on E: drive.
) else (
    echo [7] E: drive does not exist. Skipping.
)
echo.

:gs_found
if %GS_FOUND%==0 (
    echo.
    echo WARNING: Ghostscript not found!
    echo Skipping PNG conversion.
    echo.
) else (
    echo.
    echo ========================================
    echo   Ghostscript FOUND!
    echo ========================================
    echo Path: !GS_EXE!
    echo.
)

:: ============================================
:: PART 4: FIND SUMATRAPDF
:: ============================================
echo ========================================
echo   PART 4: Finding SumatraPDF
echo ========================================
echo.

set SUMATRA_EXE=
set SUMATRA_FOUND=0

echo Searching for SumatraPDF.exe...
echo.

:: Check PATH
echo [1] Checking system PATH...
where SumatraPDF.exe >nul 2>nul
if not errorlevel 1 (
    for /f "delims=" %%i in ('where SumatraPDF.exe') do (
        set SUMATRA_EXE=%%i
        set SUMATRA_FOUND=1
        echo     FOUND in PATH: %%i
        goto :sumatra_found
    )
)
echo     Not found in PATH.
echo.

:: Search current directory
echo [2] Searching current directory...
if exist "SumatraPDF.exe" (
    set SUMATRA_EXE=%CD%\SumatraPDF.exe
    set SUMATRA_FOUND=1
    echo     FOUND: !SUMATRA_EXE!
    goto :sumatra_found
)
echo     Not found in current directory.
echo.

:: Search subdirectories
echo [3] Searching subdirectories...
for /r %%i in (SumatraPDF.exe) do (
    if exist "%%i" (
        set SUMATRA_EXE=%%i
        set SUMATRA_FOUND=1
        echo     FOUND: %%i
        goto :sumatra_found
    )
)
echo     Not found in subdirectories.
echo.

:: Search C: drive Program Files
echo [4] Searching C: drive Program Files...
if exist "C:\Program Files\SumatraPDF\SumatraPDF.exe" (
    set SUMATRA_EXE=C:\Program Files\SumatraPDF\SumatraPDF.exe
    set SUMATRA_FOUND=1
    echo     FOUND: !SUMATRA_EXE!
    goto :sumatra_found
)
if exist "C:\Program Files (x86)\SumatraPDF\SumatraPDF.exe" (
    set SUMATRA_EXE=C:\Program Files (x86)\SumatraPDF\SumatraPDF.exe
    set SUMATRA_FOUND=1
    echo     FOUND: !SUMATRA_EXE!
    goto :sumatra_found
)
echo     Not found in C: Program Files.
echo.

:: Search D: drive Program Files
if exist D:\ (
    echo [5] Searching D: drive Program Files...
    if exist "D:\Program Files\SumatraPDF\SumatraPDF.exe" (
        set SUMATRA_EXE=D:\Program Files\SumatraPDF\SumatraPDF.exe
        set SUMATRA_FOUND=1
        echo     FOUND: !SUMATRA_EXE!
        goto :sumatra_found
    )
    if exist "D:\Program Files (x86)\SumatraPDF\SumatraPDF.exe" (
        set SUMATRA_EXE=D:\Program Files (x86)\SumatraPDF\SumatraPDF.exe
        set SUMATRA_FOUND=1
        echo     FOUND: !SUMATRA_EXE!
        goto :sumatra_found
    )
    echo     Not found in D: Program Files.
) else (
    echo [5] D: drive does not exist. Skipping.
)
echo.

:: Search E: drive Program Files
if exist E:\ (
    echo [6] Searching E: drive Program Files...
    if exist "E:\Program Files\SumatraPDF\SumatraPDF.exe" (
        set SUMATRA_EXE=E:\Program Files\SumatraPDF\SumatraPDF.exe
        set SUMATRA_FOUND=1
        echo     FOUND: !SUMATRA_EXE!
        goto :sumatra_found
    )
    if exist "E:\Program Files (x86)\SumatraPDF\SumatraPDF.exe" (
        set SUMATRA_EXE=E:\Program Files (x86)\SumatraPDF\SumatraPDF.exe
        set SUMATRA_FOUND=1
        echo     FOUND: !SUMATRA_EXE!
        goto :sumatra_found
    )
    echo     Not found in E: Program Files.
) else (
    echo [6] E: drive does not exist. Skipping.
)
echo.

:sumatra_found
if %SUMATRA_FOUND%==0 (
    echo.
    echo WARNING: SumatraPDF not found!
    echo.
) else (
    echo.
    echo ========================================
    echo   SumatraPDF FOUND!
    echo ========================================
    echo Path: !SUMATRA_EXE!
    echo.
)

:: ============================================
:: PART 5: CONVERT TO PNG (if Ghostscript found)
:: ============================================
if %GS_FOUND%==1 (
    echo ========================================
    echo   PART 5: Converting PDF to PNG
    echo ========================================
    echo.

    if not exist "%OUTPUT_DIR%" (
        mkdir "%OUTPUT_DIR%"
        echo Created output directory: %OUTPUT_DIR%
        echo.
    )

    set GS_OPTS=-dNOPAUSE -dBATCH -dSAFER -sDEVICE=png16m
    set OUTFILE=%OUTPUT_DIR%\!FILENAME!_page%%d.png

    echo Converting: !FILENAME!.pdf
    echo Resolution: %RESOLUTION% DPI
    echo.

    "!GS_EXE!" %GS_OPTS% -r%RESOLUTION% -sOutputFile="%OUTFILE%" "!FILENAME!.pdf"

    if errorlevel 1 (
        echo ERROR: Conversion failed!
    ) else (
        set PNG_COUNT=0
        for %%p in ("%OUTPUT_DIR%\!FILENAME!_page*.png") do set /a PNG_COUNT+=1
        echo ========================================
        echo   CONVERSION SUCCESSFUL!
        echo ========================================
        echo Created !PNG_COUNT! PNG file(s)
        echo.
        echo PNG files in: %CD%\%OUTPUT_DIR%
    )
    echo.
) else (
    echo ========================================
    echo   SKIPPING PNG CONVERSION
    echo ========================================
    echo Ghostscript not found.
    echo.
)

:: ============================================
:: PART 6: OPEN RESULTS
:: ============================================
echo ========================================
echo   PART 6: Opening Results
echo ========================================
echo.

if %SUMATRA_FOUND%==1 (
    echo Opening PDF with SumatraPDF...
    start "" "!SUMATRA_EXE!" -reuse-instance "!FILENAME!.pdf"
) else (
    echo PDF saved at: %CD%\!FILENAME!.pdf
)

if exist "%OUTPUT_DIR%\!FILENAME!_page*.png" (
    echo Opening PNG folder...
    start explorer "%OUTPUT_DIR%"
)

echo.
echo ============================================================
echo   PROCESS COMPLETED!
echo ============================================================
echo.
echo Summary:
echo   - TeX Live: !TEXLIVE_PATH!
echo   - PDF: %CD%\!FILENAME!.pdf
if %SUMATRA_FOUND%==1 echo   - SumatraPDF: !SUMATRA_EXE!
if %GS_FOUND%==1 echo   - Ghostscript: !GS_EXE!
if exist "%OUTPUT_DIR%\!FILENAME!_page*.png" echo   - PNGs: %CD%\%OUTPUT_DIR%\
echo.
echo Completed at: %date% %time%
echo.
echo Press any key to exit...
pause >nul
exit /b 0