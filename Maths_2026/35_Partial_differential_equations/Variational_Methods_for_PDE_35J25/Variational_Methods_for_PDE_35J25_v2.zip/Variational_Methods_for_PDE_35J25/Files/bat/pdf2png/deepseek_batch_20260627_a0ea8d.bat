@echo off
setlocal enabledelayedexpansion
title PDF Compiler & Converter
color 0A

:: ============================================
:: CONFIGURATION
:: ============================================
set TEXLIVE_PATH=E:/archives/25/Doctorate/texlive/2024/bin/windows/
set RESOLUTION=150
set OUTPUT_DIR=PNG_Output

echo ============================================================
echo   PDF Compiler & Converter - Full Automatic Workflow
echo ============================================================
echo.
echo Starting at: %date% %time%
echo.

:: ============================================
:: PART 1: COMPILE LATEX
:: ============================================
echo ========================================
echo   PART 1: Compiling LaTeX Document
echo ========================================
echo.

:: Find .tex file
for %%f in (*.tex) do (
    set FILENAME=%%~nf
    set FULLTEX=%%f
    echo Found: !FILENAME!.tex
    goto :found_tex
)
echo ERROR: No .tex file found in current directory!
echo.
pause
exit /b 1

:found_tex
echo.

:: Kill PDF viewers
echo Killing PDF viewers...
taskkill /f /im Acrobat.exe 2>nul
taskkill /f /im AcroRd32.exe 2>nul
taskkill /f /im AcrobatReader.exe 2>nul
taskkill /f /im AcroCEF.exe 2>nul
taskkill /f /im FoxitReader.exe 2>nul
taskkill /f /im FoxitPDFReader.exe 2>nul
taskkill /f /im SumatraPDF.exe 2>nul
timeout /t 1 /nobreak >nul
echo.

:: Clean old files
echo Cleaning old files...
if exist "!FILENAME!.pdf" (
    attrib -r "!FILENAME!.pdf" 2>nul
    del /f /q "!FILENAME!.pdf" 2>nul
)
del /f /q "!FILENAME!.aux" "!FILENAME!.bbl" "!FILENAME!.bcf" "!FILENAME!.blg" 2>nul
del /f /q "!FILENAME!.idx" "!FILENAME!.ilg" "!FILENAME!.ind" 2>nul
del /f /q "!FILENAME!.log" "!FILENAME!.out" "!FILENAME!.toc" 2>nul
del /f /q "!FILENAME!.synctex.gz" "!FILENAME!.run.xml" 2>nul
del /f /q "indexstyle.ist" "references.bib" 2>nul
echo Done.
echo.

:: pdflatex pass 1
echo [1/5] First pdflatex pass...
"%TEXLIVE_PATH%pdflatex.exe" -interaction=nonstopmode "!FULLTEX!" >nul 2>&1
if errorlevel 1 (
    echo ERROR: First pdflatex pass failed!
    goto error
)
echo OK.
echo.

:: bibtex
echo [2/5] Running bibtex...
if exist "!FILENAME!.aux" (
    "%TEXLIVE_PATH%bibtex.exe" "!FILENAME!" >nul 2>&1
    if errorlevel 1 (
        echo WARNING: BibTeX had issues - check references.bib
    ) else (
        echo OK.
    )
) else (
    echo WARNING: !FILENAME!.aux not found - BibTeX skipped
)
echo.

:: makeindex
echo [3/5] Running makeindex...
if exist "!FILENAME!.idx" (
    if exist "indexstyle.ist" (
        "%TEXLIVE_PATH%makeindex.exe" -s indexstyle.ist "!FILENAME!.idx" >nul 2>&1
    ) else (
        "%TEXLIVE_PATH%makeindex.exe" "!FILENAME!.idx" >nul 2>&1
    )
    if errorlevel 1 (
        echo WARNING: makeindex had issues
    ) else (
        echo OK.
    )
) else (
    echo Skipped (no index file)
)
echo.

:: pdflatex pass 2
echo [4/5] Second pdflatex pass...
"%TEXLIVE_PATH%pdflatex.exe" -interaction=nonstopmode "!FULLTEX!" >nul 2>&1
if errorlevel 1 (
    echo ERROR: Second pdflatex pass failed!
    goto error
)
echo OK.
echo.

:: pdflatex pass 3
echo [5/5] Final pdflatex pass...
"%TEXLIVE_PATH%pdflatex.exe" -interaction=nonstopmode "!FULLTEX!" >nul 2>&1
if errorlevel 1 (
    echo ERROR: Final pdflatex pass failed!
    goto error
)
echo OK.
echo.

:: Check if PDF created
if not exist "!FILENAME!.pdf" (
    echo ERROR: PDF not created!
    echo.
    echo Check !FILENAME!.log for errors
    pause
    exit /b 1
)

echo ========================================
echo   COMPILATION SUCCESSFUL!
echo ========================================
echo PDF created: !FILENAME!.pdf
for %%i in ("!FILENAME!.pdf") do echo Size: %%~zi bytes
echo.

:: ============================================
:: PART 2: FIND GHOSTSCRIPT
:: ============================================
echo ========================================
echo   PART 2: Finding Ghostscript
echo ========================================
echo.

:: Auto-search for gswin64.exe in current directory and subdirectories
set GS_EXE=
echo Searching for Ghostscript (gswin64.exe / gswin64c.exe)...

:: Search in current directory first
if exist "gswin64.exe" (
    set GS_EXE=gswin64.exe
    echo Found: %CD%\gswin64.exe
    goto :gs_found
)

:: Search in all subdirectories for gswin64.exe
for /r %%i in (gswin64.exe) do (
    if exist "%%i" (
        set GS_EXE=%%i
        echo Found: %%i
        goto :gs_found
    )
)

:: If not found, try gswin64c.exe in current directory
if exist "gswin64c.exe" (
    set GS_EXE=gswin64c.exe
    echo Found: %CD%\gswin64c.exe
    goto :gs_found
)

:: Search for gswin64c.exe in subdirectories
for /r %%i in (gswin64c.exe) do (
    if exist "%%i" (
        set GS_EXE=%%i
        echo Found: %%i
        goto :gs_found
    )
)

:: If still not found
echo.
echo WARNING: Ghostscript (gswin64.exe or gswin64c.exe) not found!
echo.
echo Searched in:
echo   - %CD%
echo   - All subdirectories
echo.
echo PDF created at: %CD%\!FILENAME!.pdf
echo.
goto find_sumatra

:gs_found
echo.

:: ============================================
:: PART 3: FIND SUMATRAPDF
:: ============================================
:find_sumatra
echo ========================================
echo   PART 3: Finding SumatraPDF
echo ========================================
echo.

:: Auto-search for SumatraPDF.exe in current directory and subdirectories
set SUMATRA_EXE=
echo Searching for SumatraPDF.exe...

:: Search in current directory first
if exist "SumatraPDF.exe" (
    set SUMATRA_EXE=SumatraPDF.exe
    echo Found: %CD%\SumatraPDF.exe
    goto :sumatra_found
)

:: Search in all subdirectories
for /r %%i in (SumatraPDF.exe) do (
    if exist "%%i" (
        set SUMATRA_EXE=%%i
        echo Found: %%i
        goto :sumatra_found
    )
)

:: If not found
echo.
echo WARNING: SumatraPDF.exe not found!
echo.
echo Searched in:
echo   - %CD%
echo   - All subdirectories
echo.
echo PDF created at: %CD%\!FILENAME!.pdf
echo.
goto :check_gs_for_conversion

:sumatra_found
echo.

:: ============================================
:: PART 4: CONVERT PDF TO PNG (if Ghostscript found)
:: ============================================
:check_gs_for_conversion
if defined GS_EXE (
    echo ========================================
    echo   PART 4: Converting PDF to PNG
    echo ========================================
    echo.

    :: Create output directory
    if not exist "%OUTPUT_DIR%" (
        mkdir "%OUTPUT_DIR%"
        echo Created output directory: %OUTPUT_DIR%
        echo.
    )

    :: Set Ghostscript options
    set GS_OPTS=-dNOPAUSE -dBATCH -dSAFER -sDEVICE=png16m
    set OUTFILE=%OUTPUT_DIR%\!FILENAME!_page%%d.png

    echo Converting: !FILENAME!.pdf
    echo Resolution: %RESOLUTION% DPI
    echo Output folder: %OUTPUT_DIR%
    echo.
    echo Using Ghostscript: !GS_EXE!
    echo.

    "!GS_EXE!" %GS_OPTS% -r%RESOLUTION% -sOutputFile="%OUTFILE%" "!FILENAME!.pdf" 2>nul

    if errorlevel 1 (
        echo ERROR: PDF to PNG conversion failed!
        echo.
    ) else (
        :: Count PNG files created
        set PNG_COUNT=0
        for %%p in ("%OUTPUT_DIR%\!FILENAME!_page*.png") do set /a PNG_COUNT+=1
        echo ========================================
        echo   CONVERSION SUCCESSFUL!
        echo ========================================
        echo Created !PNG_COUNT! PNG file(s)
        echo.
        echo PNG files saved in: %CD%\%OUTPUT_DIR%
        echo.
    )
) else (
    echo ========================================
    echo   SKIPPING CONVERSION
    echo ========================================
    echo.
    echo Ghostscript not found - skipping PNG conversion.
    echo.
)

:: ============================================
:: PART 5: OPEN RESULTS
:: ============================================
echo ========================================
echo   PART 5: Opening Results
echo ========================================
echo.

:: Open PDF with SumatraPDF if found
if defined SUMATRA_EXE (
    echo Opening PDF with SumatraPDF...
    start "" "!SUMATRA_EXE!" -reuse-instance "!FILENAME!.pdf"
    echo.
) else (
    echo SumatraPDF not found - PDF saved at: %CD%\!FILENAME!.pdf
    echo.
)

:: Open PNG folder if conversion succeeded
if exist "%OUTPUT_DIR%" (
    if exist "%OUTPUT_DIR%\!FILENAME!_page*.png" (
        echo Opening PNG output folder...
        start explorer "%OUTPUT_DIR%"
        echo.
    )
)

echo ============================================================
echo   PROCESS COMPLETED SUCCESSFULLY!
echo ============================================================
echo.
echo Summary:
echo   - PDF: %CD%\!FILENAME!.pdf
if defined SUMATRA_EXE (
    echo   - SumatraPDF: !SUMATRA_EXE!
)
if defined GS_EXE (
    echo   - Ghostscript: !GS_EXE!
)
if exist "%OUTPUT_DIR%\!FILENAME!_page*.png" (
    echo   - PNGs: %CD%\%OUTPUT_DIR%\
)
echo.
echo Completed at: %date% %time%
echo.
pause
exit /b 0

:error
echo.
echo ========================================
echo   ERROR: Compilation failed
echo ========================================
echo.
echo Check !FILENAME!.log for errors
echo.
pause
exit /b 1