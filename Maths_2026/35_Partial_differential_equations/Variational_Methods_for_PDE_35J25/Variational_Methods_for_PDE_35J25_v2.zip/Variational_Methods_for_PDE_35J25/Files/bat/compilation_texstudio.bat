@echo off
set "TEXSTUDIO_PATH=E:\Processings\Maths\Tools\texstudio-2.12.6"

if not exist "%TEXSTUDIO_PATH%\texstudio.exe" (
    echo Error: texstudio.exe not found at %TEXSTUDIO_PATH%
    pause
    exit /b
)

set PATH=%PATH%;%TEXSTUDIO_PATH%

REM Find the first .tex file in current directory
for %%f in (*.tex) do (
    start "" "%TEXSTUDIO_PATH%\texstudio.exe" "%%f"
    exit /b
)

echo No .tex file found in current directory
pause