@echo off
setlocal enabledelayedexpansion

:: ============================================================
::  Logging setup
:: ============================================================
set LOGDIR=logs
if not exist "%LOGDIR%" mkdir "%LOGDIR%"

for /f "tokens=1-6 delims=/: " %%a in ("%date% %time%") do (
    set YYYY=%%a
    set MM=%%b
    set DD=%%c
    set HH=%%d
    set MI=%%e
    set SS=%%f
)
set HH=%HH: =0%
set MI=%MI: =0%
set SS=%SS: =0%
set TIMESTAMP=%YYYY%%MM%%DD%_%HH%%MI%%SS%
set LOGFILE=%LOGDIR%\compile_%TIMESTAMP%.log

powershell -Command "Start-Transcript -Path '%LOGFILE%' -Append -NoClobber" >nul 2>&1

echo ========================================
echo   Compiling with LuaLaTeX
echo ========================================
echo Log file: %LOGFILE%
echo.

:: ============================================================
::  Detect TeX Live bin path
:: ============================================================
for /f "delims=" %%i in ('kpsewhich -var-value SELFAUTOPARENT 2^>nul') do set TEXLIVE_ROOT=%%i
if defined TEXLIVE_ROOT (
    set TEXLIVE_PATH=%TEXLIVE_ROOT%\bin\windows\
    echo TeX Live found at %TEXLIVE_PATH%
) else (
    echo WARNING: kpsewhich not found. Using fallback path.
    set TEXLIVE_PATH=E:\Processings\Doctorate\texlive\2024\bin\windows\
)

:: ============================================================
::  Check JuliaMono fonts (download if missing)
:: ============================================================
set FONT_DIR=JuliaMono
set FONT_FILE=JuliaMono-Regular.ttf
set JULIA_VERSION=0.058
set ZIP_NAME=JuliaMono-%JULIA_VERSION%.zip
set DOWNLOAD_URL=https://github.com/cormullion/juliamono/releases/download/v%JULIA_VERSION%/%ZIP_NAME%

if exist "%FONT_DIR%" (
    echo [OK] Font folder found.
) else (
    echo [INFO] Downloading JuliaMono fonts...
    powershell -Command "Invoke-WebRequest -Uri '%DOWNLOAD_URL%' -OutFile '%ZIP_NAME%'"
    if errorlevel 1 (
        echo [ERROR] Download failed.
        pause
        goto cleanup
    )
    powershell -Command "Expand-Archive -Force '%ZIP_NAME%' -DestinationPath '.'"
    if errorlevel 1 (
        echo [ERROR] Extraction failed.
        pause
        goto cleanup
    )
    if not exist "%FONT_DIR%" mkdir "%FONT_DIR%"
    for %%f in ("JuliaMono-%JULIA_VERSION%\*.ttf") do move "%%f" "%FONT_DIR%\" >nul
    rmdir /s /q "JuliaMono-%JULIA_VERSION%" 2>nul
    del "%ZIP_NAME%"
    echo [OK] Fonts downloaded.
)

:: ============================================================
::  Find .tex file
:: ============================================================
for %%f in (*.tex) do (
    set FILENAME=%%~nf
    set FULLTEX=%%f
    goto :found
)
echo ERROR: No .tex file found!
pause
goto cleanup

:found
echo Compiling %FILENAME%.tex ...

:: ============================================================
::  Kill PDF viewers
:: ============================================================
taskkill /f /im Acrobat.exe 2>nul
taskkill /f /im AcroRd32.exe 2>nul
taskkill /f /im AcrobatReader.exe 2>nul
taskkill /f /im AcroCEF.exe 2>nul
taskkill /f /im FoxitReader.exe 2>nul
taskkill /f /im FoxitPDFReader.exe 2>nul
taskkill /f /im SumatraPDF.exe 2>nul
timeout /t 1 /nobreak >nul

:: ============================================================
::  Clean auxiliary files
:: ============================================================
del /f /q "%FILENAME%.aux" "%FILENAME%.bbl" "%FILENAME%.bcf" "%FILENAME%.blg" 2>nul
del /f /q "%FILENAME%.idx" "%FILENAME%.ilg" "%FILENAME%.ind" 2>nul
del /f /q "%FILENAME%.log" "%FILENAME%.out" "%FILENAME%.toc" 2>nul
del /f /q "%FILENAME%.synctex.gz" 2>nul
del /f /q "indexstyle.ist" "references.bib" 2>nul

:: ============================================================
::  Compile with latexmk if available (recommended)
:: ============================================================
where latexmk >nul 2>&1
if %errorlevel%==0 (
    echo Using latexmk for automated build...
    latexmk -lualatex -interaction=nonstopmode -synctex=1 "%FULLTEX%"
    if errorlevel 1 (
        echo ERROR: latexmk failed.
        goto error
    )
) else (
    echo latexmk not found – falling back to manual steps.
    echo STEP 1: lualatex
    "%TEXLIVE_PATH%lualatex.exe" -interaction=nonstopmode "%FULLTEX%"
    if errorlevel 1 goto error
    echo STEP 2: bibtex
    if exist "%FILENAME%.aux" "%TEXLIVE_PATH%bibtex.exe" "%FILENAME%"
    echo STEP 3: makeindex
    if exist "%FILENAME%.idx" (
        if exist indexstyle.ist (
            "%TEXLIVE_PATH%makeindex.exe" -s indexstyle.ist "%FILENAME%.idx"
        ) else (
            "%TEXLIVE_PATH%makeindex.exe" "%FILENAME%.idx"
        )
    )
    echo STEP 4: lualatex (second pass)
    "%TEXLIVE_PATH%lualatex.exe" -interaction=nonstopmode "%FULLTEX%"
    if errorlevel 1 goto error
    echo STEP 5: lualatex (final pass)
    "%TEXLIVE_PATH%lualatex.exe" -interaction=nonstopmode "%FULLTEX%"
    if errorlevel 1 goto error
)

:: ============================================================
::  Check output and open PDF
:: ============================================================
if exist "%FILENAME%.pdf" (
    echo ========================================
    echo   SUCCESS! PDF created.
    echo ========================================
    echo Opening with SumatraPDF...
    where SumatraPDF >nul 2>&1
    if %errorlevel%==0 (
        start SumatraPDF -reuse-instance "%FILENAME%.pdf"
    ) else if exist "%CD%\SumatraPDF.exe" (
        start "" "%CD%\SumatraPDF.exe" -reuse-instance "%FILENAME%.pdf"
    ) else (
        echo SumatraPDF not found – PDF is at %CD%\%FILENAME%.pdf
    )
    goto cleanup
) else (
    echo ERROR: PDF not produced.
    goto error
)

:error
echo.
echo Compilation failed. Check %FILENAME%.log for details.
pause
goto cleanup

:cleanup
powershell -Command "Stop-Transcript" >nul 2>&1
echo Log saved to %LOGFILE%
pause