@echo off
setlocal enabledelayedexpansion

:: ============================================================
::  Logging setup – create logs folder and timestamped log file
:: ============================================================
set LOGDIR=logs
if not exist "%LOGDIR%" mkdir "%LOGDIR%"

:: Create timestamp: YYYYMMDD_HHMMSS (no spaces)
for /f "tokens=1-6 delims=/: " %%a in ("%date% %time%") do (
set YYYY=%%a
set MM=%%b
set DD=%%c
set HH=%%d
set MI=%%e
set SS=%%f
)
:: Remove leading zeros (to avoid octal issues)
set HH=%HH: =0%
set MI=%MI: =0%
set SS=%SS: =0%
set TIMESTAMP=%YYYY%%MM%%DD%_%HH%%MI%%SS%
set LOGFILE=%LOGDIR%\compile_%TIMESTAMP%.log

:: Start PowerShell transcript to capture everything
powershell -Command "Start-Transcript -Path '%LOGFILE%' -Append -NoClobber" >nul 2>&1

echo ========================================
echo   Compiling Main Document with LuaLaTeX
echo ========================================
echo.
echo Log file: %LOGFILE%
echo.

:: ============================================================
::  Font checking and automatic download (JuliaMono)
:: ============================================================
set FONT_DIR=JuliaMono
set FONT_FILE=JuliaMono-Regular.ttf
set JULIA_VERSION=0.058
set ZIP_NAME=JuliaMono-%JULIA_VERSION%.zip
set DOWNLOAD_URL=https://github.com/cormullion/juliamono/releases/download/v%JULIA_VERSION%/%ZIP_NAME%

echo ========================================
echo   CHECKING FONTS (JuliaMono)
echo ========================================
echo.

if exist "%FONT_DIR%" (
echo [OK] Font folder found: %FONT_DIR%
) else (
echo [INFO] Font folder "%FONT_DIR%" not found.
echo Downloading JuliaMono fonts from GitHub...
powershell -Command "Invoke-WebRequest -Uri '%DOWNLOAD_URL%' -OutFile '%ZIP_NAME%'"
if errorlevel 1 (
echo [ERROR] Failed to download the font archive.
echo Please check your internet connection and try again.
echo.
pause
goto :cleanup
)
echo Extracting %ZIP_NAME% ...
:: Extract to a temporary folder
powershell -Command "Expand-Archive -Force '%ZIP_NAME%' -DestinationPath '.'"
if errorlevel 1 (
echo [ERROR] Failed to extract the archive.
echo Please ensure you have PowerShell 5+.
pause
goto :cleanup
)
:: Create the target folder and move only .ttf files
if not exist "%FONT_DIR%" mkdir "%FONT_DIR%"
echo Moving .ttf files to %FONT_DIR% ...
for %%f in ("JuliaMono-%JULIA_VERSION%\*.ttf") do (
move "%%f" "%FONT_DIR%\" >nul
)
:: Clean up the extracted folder and the zip
rmdir /s /q "JuliaMono-%JULIA_VERSION%" 2>nul
del "%ZIP_NAME%"
echo [OK] Fonts extracted to "%FONT_DIR%".
)

:: Now check if the specific font file exists
if not exist "%FONT_DIR%\%FONT_FILE%" (
echo [ERROR] Font file "%FONT_FILE%" not found in "%FONT_DIR%".
echo Please check the extracted folder.
pause
goto :cleanup
)

echo [OK] Font file found: %FONT_FILE%
echo Font path: %CD%\%FONT_DIR%\%FONT_FILE%
echo.

:: Ask user whether to install fonts system-wide (optional)
set /p install_fonts="Do you want to install the fonts system-wide (requires admin)? (y/n) "
if /i "!install_fonts!"=="y" (
net session >nul 2>&1
if errorlevel 1 (
echo This script must be run as Administrator to install fonts.
echo Please right-click the batch file and select "Run as administrator".
) else (
echo Installing fonts to Windows Fonts folder...
for %%f in ("%FONT_DIR%\*.ttf") do (
echo Installing %%f ...
copy "%%f" "%WINDIR%\Fonts" >nul
)
echo Fonts installed successfully.
)
echo.
)

:: ============================================================
::  LaTeX compilation pipeline
:: ============================================================
set TEXLIVE_PATH=E:\Processings\Doctorate\texlive\2024\bin\windows\
set SUMATRA_EXE=SumatraPDF.exe

echo Searching for .tex file in current directory...
for %%f in (*.tex) do (
set FILENAME=%%~nf
set FULLTEX=%%f
echo Found: !FILENAME!.tex
goto :found
)
echo ERROR: No .tex file found in current directory!
pause
goto :cleanup

:found
echo.

echo ========================================
echo   STEP 0: Killing PDF viewers only
echo ========================================
echo Closing PDF viewers before compilation...
taskkill /f /im Acrobat.exe 2>nul
taskkill /f /im AcroRd32.exe 2>nul
taskkill /f /im AcrobatReader.exe 2>nul
taskkill /f /im AcroCEF.exe 2>nul
taskkill /f /im FoxitReader.exe 2>nul
taskkill /f /im FoxitPDFReader.exe 2>nul
taskkill /f /im SumatraPDF.exe 2>nul
timeout /t 1 /nobreak >nul
echo Done.
echo.

echo ========================================
echo   Cleaning old files...
echo ========================================
if exist "!FILENAME!.pdf" (
echo Deleting !FILENAME!.pdf...
attrib -r "!FILENAME!.pdf" 2>nul
del /f /q "!FILENAME!.pdf" 2>nul
)
del /f /q "!FILENAME!.aux" "!FILENAME!.bbl" "!FILENAME!.bcf" "!FILENAME!.blg" 2>nul
del /f /q "!FILENAME!.idx" "!FILENAME!.ilg" "!FILENAME!.ind" 2>nul
del /f /q "!FILENAME!.log" "!FILENAME!.out" "!FILENAME!.toc" 2>nul
del /f /q "!FILENAME!.bbl" 2>nul
del /f /q "!FILENAME!.synctex.gz" 2>nul
del /f /q "!FILENAME!.run.xml" 2>nul
del /f /q "indexstyle.ist" 2>nul
del /f /q "references.bib" 2>nul
echo Done.
echo.

echo ========================================
echo   STEP 1: lualatex (first pass)
echo ========================================
"%TEXLIVE_PATH%lualatex.exe" -interaction=nonstopmode "!FULLTEX!"
if errorlevel 1 (
echo ERROR: First lualatex pass failed!
goto error
)
echo.

echo ========================================
echo   STEP 2: bibtex
echo ========================================
if exist "!FILENAME!.aux" (
"%TEXLIVE_PATH%bibtex.exe" "!FILENAME!"
if errorlevel 1 (
echo WARNING: BibTeX had issues - check references.bib
)
) else (
echo WARNING: !FILENAME!.aux not found - BibTeX skipped
)
echo.

echo ========================================
echo   STEP 3: makeindex
echo ========================================
if exist "!FILENAME!.idx" (
if exist "indexstyle.ist" (
"%TEXLIVE_PATH%makeindex.exe" -s indexstyle.ist "!FILENAME!.idx"
if errorlevel 1 (
echo WARNING: makeindex had issues
)
) else (
echo WARNING: indexstyle.ist not found - running makeindex without style
"%TEXLIVE_PATH%makeindex.exe" "!FILENAME!.idx"
)
) else (
echo No index file found - skipping makeindex
)
echo.

echo ========================================
echo   STEP 4: lualatex (second pass)
echo ========================================
"%TEXLIVE_PATH%lualatex.exe" -interaction=nonstopmode "!FULLTEX!"
if errorlevel 1 (
echo ERROR: Second lualatex pass failed!
goto error
)
echo.

echo ========================================
echo   STEP 5: lualatex (final pass)
echo ========================================
"%TEXLIVE_PATH%lualatex.exe" -interaction=nonstopmode "!FULLTEX!"
if errorlevel 1 (
echo ERROR: Final lualatex pass failed!
goto error
)
echo.

if exist "!FILENAME!.pdf" (
echo ========================================
echo   SUCCESS! PDF created
echo ========================================
echo.
echo Output: !FILENAME!.pdf
echo.

echo ========================================
echo   Opening with SumatraPDF only
echo ========================================

echo Closing any remaining PDF viewers...
taskkill /f /im Acrobat.exe 2>nul
taskkill /f /im AcroRd32.exe 2>nul
taskkill /f /im AcrobatReader.exe 2>nul
taskkill /f /im FoxitReader.exe 2>nul
taskkill /f /im SumatraPDF.exe 2>nul
timeout /t 1 /nobreak >nul

if exist "%CD%\%SUMATRA_EXE%" (
echo Found SumatraPDF in current directory.
echo.
echo Opening PDF with SumatraPDF...
start "" "%CD%\%SUMATRA_EXE%" -reuse-instance "!FILENAME!.pdf"
echo.
echo ========================================
echo   SumatraPDF opened successfully!
echo   PDF: %CD%\!FILENAME!.pdf
echo ========================================
) else (
echo ========================================
echo   ERROR: SumatraPDF not found!
echo ========================================
echo.
echo Expected location: %CD%\%SUMATRA_EXE%
echo.
echo Please ensure SumatraPDF.exe is in the same directory
echo as this batch file.
echo.
echo Download from: https://www.sumatrapdfreader.org/download.html
echo.
echo PDF created at: %CD%\!FILENAME!.pdf
echo.
)
) else (
echo ========================================
echo   ERROR: PDF not created
echo ========================================
echo.
echo Check !FILENAME!.log for errors
pause
goto cleanup
)

goto cleanup

:error
echo.
echo ========================================
echo   ERROR: Compilation failed
echo ========================================
echo.
echo Check the following files for errors:
echo   - !FILENAME!.log
echo   - !FILENAME!.aux
echo   - references.bib
echo.
pause

:cleanup
:: Stop the PowerShell transcript
powershell -Command "Stop-Transcript" >nul 2>&1
echo.
echo Log saved to: %LOGFILE%
echo.
pause