@echo off
setlocal enabledelayedexpansion

:: ------------------------------------------------------------------
:: Check for DejaVu fonts and download/install if missing
:: ------------------------------------------------------------------

set FONT_DIR=dejavu-fonts-ttf-2.37\ttf
set ZIP_NAME=dejavu-fonts-ttf-2.37.zip
set DOWNLOAD_URL=https://github.com/dejavu-fonts/dejavu-fonts/releases/download/version_2_37/%ZIP_NAME%

:: ------------------------------------------------------------------
:: 1. Check if the font folder exists
:: ------------------------------------------------------------------
if exist "%FONT_DIR%" (
    echo Font directory "%FONT_DIR%" already exists.
    goto :ask_install
)

echo Font directory "%FONT_DIR%" not found.
echo Downloading DejaVu fonts from GitHub...

:: ------------------------------------------------------------------
:: 2. Download the ZIP file using PowerShell (built-in)
:: ------------------------------------------------------------------
powershell -Command "Invoke-WebRequest -Uri '%DOWNLOAD_URL%' -OutFile '%ZIP_NAME%'" || (
    echo Failed to download the font archive. Please check your internet connection.
    pause
    exit /b 1
)

:: ------------------------------------------------------------------
:: 3. Extract the ZIP file using PowerShell
:: ------------------------------------------------------------------
echo Extracting %ZIP_NAME% ...
powershell -Command "Expand-Archive -Force '%ZIP_NAME%' -DestinationPath '.'" || (
    echo Failed to extract the archive. Please ensure you have PowerShell 5+.
    pause
    exit /b 1
)

:: ------------------------------------------------------------------
:: 4. Clean up: remove the ZIP file after extraction
:: ------------------------------------------------------------------
if exist "%ZIP_NAME%" del "%ZIP_NAME%"

echo Fonts have been extracted to "%FONT_DIR%".

:: ------------------------------------------------------------------
:: 5. Optional system-wide installation (needs admin rights)
:: ------------------------------------------------------------------
:ask_install
echo.
set /p install_fonts="Do you want to install the fonts system-wide (requires admin)? (y/n) "
if /i not "!install_fonts!"=="y" goto :end

:: Check if running as administrator
net session >nul 2>&1
if errorlevel 1 (
    echo This script must be run as Administrator to install fonts.
    echo Please right-click the batch file and select "Run as administrator".
    goto :end
)

echo Installing fonts to Windows Fonts folder...
for %%f in ("%FONT_DIR%\*.ttf") do (
    echo Installing %%f ...
    copy "%%f" "%WINDIR%\Fonts" >nul
)

echo Fonts installed successfully.

:end
echo Done.
pause