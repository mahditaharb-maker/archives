@echo off
setlocal enabledelayedexpansion

:: ============================================================
::  Logging setup – create logs folder and timestamped log file
:: ============================================================
set LOGDIR=logs
if not exist "%LOGDIR%" mkdir "%LOGDIR%"

:: Create timestamp: YYYYMMDD_HHMMSS (no spaces)
for /f "tokens=1-6 delims=/: " %%a in ("%date% %time%") do (
    set YYYY=%%a
    set MM=%%b
    set DD=%%c
    set HH=%%d
    set MI=%%e
    set SS=%%f
)
set HH=%HH: =0%
set MI=%MI: =0%
set SS=%SS: =0%
set TIMESTAMP=%YYYY%%MM%%DD%_%HH%%MI%%SS%
set LOGFILE=%LOGDIR%\compile_%TIMESTAMP%.log

:: Start PowerShell transcript to capture everything
powershell -Command "Start-Transcript -Path '%LOGFILE%' -Append -NoClobber" >nul 2>&1

echo ========================================
echo   Compiling Main Document with LuaLaTeX
echo ========================================
echo.
echo Log file: %LOGFILE%
echo.

:: ============================================================
::  Font checking (JuliaMono)
:: ============================================================
set JULIA_DIR=JuliaMono
set JULIA_FILE=JuliaMono-Regular.ttf
set ZIP_NAME=JuliaMono-0.057.zip
set DOWNLOAD_URL=https://github.com/cormullion/juliamono/releases/download/v0.057/%ZIP_NAME%

echo ========================================
echo   CHECKING FONTS
echo ========================================
echo.

if exist "%JULIA_DIR%\%JULIA_FILE%" (
    echo [OK] JuliaMono font found: %JULIA_DIR%\%JULIA_FILE%
) else (
    echo [WARNING] JuliaMono font not found.
    echo Downloading from GitHub...
    powershell -Command "Invoke-WebRequest -Uri '%DOWNLOAD_URL%' -OutFile '%ZIP_NAME%'"
    if errorlevel 1 (
        echo [ERROR] Failed to download JuliaMono.
        echo Please download manually from https://github.com/cormullion/juliamono/releases
    ) else (
        echo Extracting ...
        powershell -Command "Expand-Archive -Force '%ZIP_NAME%' -DestinationPath '.'"
        if errorlevel 1 (
            echo [ERROR] Failed to extract.
        ) else (
            del "%ZIP_NAME%"
            echo [OK] JuliaMono extracted.
        )
    )
)
echo.

:: ============================================================
::  LaTeX compilation pipeline
:: ============================================================
set TEXLIVE_PATH=E:\Processings\Doctorate\texlive\2024\bin\windows\
set SUMATRA_EXE=SumatraPDF.exe

:: Find the .tex file
echo Searching for .tex file in current directory...
set TEX_FILE=
for %%f in (*.tex) do (
    set TEX_FILE=%%f
    set FILENAME=%%~nf
    echo Found: %%f
    goto :found
)
echo ERROR: No .tex file found!
pause
goto :cleanup

:found
set FULLTEX=!TEX_FILE!
echo Using: !FULLTEX!
echo.

:: Kill PDF viewers
echo ========================================
echo   STEP 0: Killing PDF viewers
echo ========================================
taskkill /f /im Acrobat.exe 2>nul
taskkill /f /im AcroRd32.exe 2>nul
taskkill /f /im AcrobatReader.exe 2>nul
taskkill /f /im FoxitReader.exe 2>nul
taskkill /f /im SumatraPDF.exe 2>nul
timeout /t 1 /nobreak >nul
echo Done.
echo.

:: Clean auxiliary files
echo ========================================
echo   Cleaning old files...
echo ========================================
if exist "!FILENAME!.pdf" (
    echo Deleting !FILENAME!.pdf...
    attrib -r "!FILENAME!.pdf" 2>nul
    del /f /q "!FILENAME!.pdf" 2>nul
)
del /f /q "!FILENAME!.aux" "!FILENAME!.bbl" "!FILENAME!.bcf" "!FILENAME!.blg" 2>nul
del /f /q "!FILENAME!.idx" "!FILENAME!.ilg" "!FILENAME!.ind" 2>nul
del /f /q "!FILENAME!.log" "!FILENAME!.out" "!FILENAME!.toc" 2>nul
del /f /q "!FILENAME!.synctex.gz" 2>nul
del /f /q "!FILENAME!.run.xml" 2>nul
del /f /q "indexstyle.ist" 2>nul
del /f /q "references.bib" 2>nul
echo Done.
echo.

:: ============================================================
::  Compilation steps
:: ============================================================
set LUALATEX="%TEXLIVE_PATH%lualatex.exe"
set BIBTEX="%TEXLIVE_PATH%bibtex.exe"
set MAKEINDEX="%TEXLIVE_PATH%makeindex.exe"

if not exist %LUALATEX% (
    echo ERROR: lualatex not found at %LUALATEX%
    echo Attempting to locate lualatex in PATH...
    where lualatex >nul 2>&1
    if errorlevel 1 (
        echo ERROR: lualatex not found. Please check your TeX Live installation.
        pause
        goto :cleanup
    ) else (
        for /f "delims=" %%i in ('where lualatex') do set LUALATEX="%%i"
        echo Found lualatex at %LUALATEX%
    )
)

:: Step 1
echo ========================================
echo   STEP 1: lualatex (first pass)
echo ========================================
%LUALATEX% -interaction=nonstopmode -shell-escape "!FULLTEX!"
if errorlevel 1 (
    echo ERROR: First lualatex pass failed!
    goto :error
)
if exist "!FILENAME!.log" (
    findstr /C:"! LaTeX Error:" "!FILENAME!.log" >nul
    if not errorlevel 1 (
        echo ERROR: LaTeX error detected in first pass.
        goto :error
    )
)
echo.

:: Step 2
echo ========================================
echo   STEP 2: bibtex
echo ========================================
if exist "!FILENAME!.aux" (
    %BIBTEX% "!FILENAME!"
    if errorlevel 1 (
        echo WARNING: BibTeX had issues.
    )
) else (
    echo WARNING: !FILENAME!.aux not found - BibTeX skipped.
)
echo.

:: Step 3
echo ========================================
echo   STEP 3: makeindex
echo ========================================
if exist "!FILENAME!.idx" (
    if exist "indexstyle.ist" (
        %MAKEINDEX% -s indexstyle.ist "!FILENAME!.idx"
        if errorlevel 1 (
            echo WARNING: makeindex had issues.
        )
    ) else (
        echo WARNING: indexstyle.ist not found - running without style.
        %MAKEINDEX% "!FILENAME!.idx"
    )
) else (
    echo No index file found - skipping makeindex.
)
echo.

:: Step 4
echo ========================================
echo   STEP 4: lualatex (second pass)
echo ========================================
%LUALATEX% -interaction=nonstopmode -shell-escape "!FULLTEX!"
if errorlevel 1 (
    echo ERROR: Second lualatex pass failed!
    goto :error
)
if exist "!FILENAME!.log" (
    findstr /C:"! LaTeX Error:" "!FILENAME!.log" >nul
    if not errorlevel 1 (
        echo ERROR: LaTeX error detected in second pass.
        goto :error
    )
)
echo.

:: Step 5
echo ========================================
echo   STEP 5: lualatex (final pass)
echo ========================================
%LUALATEX% -interaction=nonstopmode -shell-escape "!FULLTEX!"
if errorlevel 1 (
    echo ERROR: Final lualatex pass failed!
    goto :error
)
if exist "!FILENAME!.log" (
    findstr /C:"! LaTeX Error:" "!FILENAME!.log" >nul
    if not errorlevel 1 (
        echo ERROR: LaTeX error detected in final pass.
        goto :error
    )
)
echo.

:: Success
if exist "!FILENAME!.pdf" (
    echo ========================================
    echo   SUCCESS! PDF created
    echo ========================================
    echo.
    echo Output: !FILENAME!.pdf
    echo Full path: %CD%\!FILENAME!.pdf
    echo.

    :: Open PDF – try SumatraPDF first, fallback to default viewer
    echo ========================================
    echo   Opening PDF
    echo ========================================
    taskkill /f /im SumatraPDF.exe 2>nul
    timeout /t 1 /nobreak >nul
    where SumatraPDF.exe >nul 2>&1
    if not errorlevel 1 (
        start "" SumatraPDF.exe -reuse-instance "!FILENAME!.pdf"
        echo SumatraPDF opened.
    ) else if exist "%CD%\%SUMATRA_EXE%" (
        start "" "%CD%\%SUMATRA_EXE%" -reuse-instance "!FILENAME!.pdf"
        echo SumatraPDF opened from current directory.
    ) else (
        echo SumatraPDF not found. Opening with default PDF viewer.
        start "" "!FILENAME!.pdf"
    )
) else (
    echo ========================================
    echo   ERROR: PDF not created
    echo ========================================
    goto :error
)

goto :cleanup

:error
echo.
echo ========================================
echo   ERROR: Compilation failed
echo ========================================
echo Check the log file: !FILENAME!.log
echo.
pause

:cleanup
powershell -Command "Stop-Transcript" >nul 2>&1
echo.
echo Log saved to: %LOGFILE%
echo.
pause