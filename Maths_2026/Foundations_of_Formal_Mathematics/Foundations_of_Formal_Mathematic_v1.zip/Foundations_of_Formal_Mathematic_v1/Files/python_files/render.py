import mermaid as md

# Read your diagram code from the file
with open('a.mmd', 'r') as f:
    diagram_code = f.read()

# Render the diagram using the Mermaid class
# You can set the output file name here
render = md.Mermaid(diagram_code, output_file='sortie.png')

# This renders and saves the diagram
render