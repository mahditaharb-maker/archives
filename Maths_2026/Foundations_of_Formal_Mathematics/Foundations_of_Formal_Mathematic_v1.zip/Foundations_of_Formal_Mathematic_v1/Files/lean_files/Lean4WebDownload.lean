theorem forall_and_distrib {α : Type} (p q : α → Prop) :
  (∀ x, p x ∧ q x) ↔ (∀ x, p x) ∧ (∀ x, q x) :=
  Iff.intro
    (fun h : ∀ x, p x ∧ q x =>
      And.intro
        (fun x : α => (h x).left)
        (fun x : α => (h x).right))
    (fun h : (∀ x, p x) ∧ (∀ x, q x) =>
      fun x : α =>
        And.intro
          ((h.left) x)
          ((h.right) x))
          #check forall_and_distrib (fun n : Nat => n > 0) (fun n => n < 5)