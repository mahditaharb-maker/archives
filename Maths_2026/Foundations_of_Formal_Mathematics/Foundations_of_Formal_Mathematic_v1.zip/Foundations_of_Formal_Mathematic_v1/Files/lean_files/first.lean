-- Example from Section 2.1: Declaring constants and checking types
constant m : nat
constant n : nat
constants b1 b2 : bool

#check m
#check n
#check n + 0
#check m * (n + 0)
#check b1
#check b1 && b2
#check b1 || b2
#check tt