@echo off
setlocal enabledelayedexpansion

set TEXLIVE=E:\Processings\Doctorate\texlive\2024\bin\windows
set NODEJS=E:\Processings\Online_Softwares\tools\node-v13.14.0-win-x64
set NPM_GLOBAL=%APPDATA%\npm
set PATH=%TEXLIVE%;%NODEJS%;%NPM_GLOBAL%;%PATH%

set PUPPETEER_SKIP_CHROMIUM_DOWNLOAD=true
set PUPPETEER_EXECUTABLE_PATH=D:\apps\chrome+idm\Google\Chrome\Application\chrome.exe
set PUPPETEER_LAUNCH_ARGS=--no-sandbox --disable-setuid-sandbox --disable-gpu

set TEXFILE=test_with_index

if not exist "%TEXFILE%.tex" (
    echo ERROR: File "%TEXFILE%.tex" not found!
    pause
    exit /b 1
)

where lualatex >nul 2>nul
if errorlevel 1 (
    echo ERROR: lualatex not found in PATH!
    pause
    exit /b 1
)

del /q "%TEXFILE%.aux" "%TEXFILE%.toc" "%TEXFILE%.out" "%TEXFILE%.log" "%TEXFILE%.lof" "%TEXFILE%.lot" "%TEXFILE%.idx" "%TEXFILE%.ind" "%TEXFILE%.ilg" 2>nul

echo COMPILING %TEXFILE%.tex ...
lualatex -shell-escape -interaction=nonstopmode "%TEXFILE%.tex" || goto error
makeindex -s indexstyle.ist "%TEXFILE%.idx" 2>nul
lualatex -shell-escape -interaction=nonstopmode "%TEXFILE%.tex" || goto error
lualatex -shell-escape -interaction=nonstopmode "%TEXFILE%.tex" || goto error

echo.
echo ============================================
echo  BUILD SUCCESSFUL!  Output: %TEXFILE%.pdf
echo ============================================
echo.

REM ---- Open the PDF with SumatraPDF (if present in the same directory) ----
if exist "SumatraPDF.exe" (
    echo Opening %TEXFILE%.pdf with SumatraPDF...
    start "" "SumatraPDF.exe" "%TEXFILE%.pdf"
) else (
    echo SumatraPDF.exe not found in current directory.
    echo Please open %TEXFILE%.pdf manually.
)

pause
exit /b

:error
echo.
echo ERROR! Check %TEXFILE%.log
pause
exit /b 1