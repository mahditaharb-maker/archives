@echo off
setlocal enabledelayedexpansion

echo ========================================
echo   Compiling Main Document with LuaLaTeX
echo ========================================
echo.

set TEXLIVE_PATH=E:\Processings\Doctorate\texlive\2024\bin\windows\
set SUMATRA_EXE=SumatraPDF.exe

echo Searching for .tex file in current directory...
for %%f in (*.tex) do (
    set FILENAME=%%~nf
    set FULLTEX=%%f
    echo Found: !FILENAME!.tex
    goto :found
)
echo ERROR: No .tex file found in current directory!
pause
goto :end

:found
echo.

echo ========================================
echo   STEP 0: Killing PDF viewers only
echo ========================================
echo Closing PDF viewers before compilation...
taskkill /f /im Acrobat.exe 2>nul
taskkill /f /im AcroRd32.exe 2>nul
taskkill /f /im AcrobatReader.exe 2>nul
taskkill /f /im AcroCEF.exe 2>nul
taskkill /f /im FoxitReader.exe 2>nul
taskkill /f /im FoxitPDFReader.exe 2>nul
timeout /t 1 /nobreak >nul
echo Done.
echo.

echo ========================================
echo   STEP 1: lualatex (first pass)
echo ========================================
"%TEXLIVE_PATH%lualatex.exe" -interaction=nonstopmode "!FULLTEX!"
if errorlevel 1 (
    echo ERROR: First lualatex pass failed!
    goto error
)
echo.

echo ========================================
echo   STEP 2: bibtex
echo ========================================
if exist "!FILENAME!.aux" (
    "%TEXLIVE_PATH%bibtex.exe" "!FILENAME!"
    if errorlevel 1 (
        echo WARNING: BibTeX had issues – check references.bib
    )
) else (
    echo WARNING: !FILENAME!.aux not found – BibTeX skipped
)
echo.

echo ========================================
echo   STEP 3: makeindex (optional – only if .idx exists)
echo ========================================
if exist "!FILENAME!.idx" (
    echo Found !FILENAME!.idx – running makeindex...
    if exist "indexstyle.ist" (
        echo Using style file: indexstyle.ist
        "%TEXLIVE_PATH%makeindex.exe" -s indexstyle.ist "!FILENAME!.idx"
    ) else (
        echo WARNING: indexstyle.ist not found – running without style
        "%TEXLIVE_PATH%makeindex.exe" "!FILENAME!.idx"
    )
    if errorlevel 1 (
        echo WARNING: makeindex had issues – check !FILENAME!.ilg
    ) else (
        if exist "!FILENAME!.ind" (
            echo ✅ Index generated: !FILENAME!.ind
        ) else (
            echo ℹ️ No index entries found – .ind not created
        )
    )
) else (
    echo No index file !FILENAME!.idx – skipping makeindex
)
echo.

echo ========================================
echo   STEP 4: lualatex (second pass)
echo ========================================
"%TEXLIVE_PATH%lualatex.exe" -interaction=nonstopmode "!FULLTEX!"
if errorlevel 1 (
    echo ERROR: Second lualatex pass failed!
    goto error
)
echo.

echo ========================================
echo   STEP 5: lualatex (final pass)
echo ========================================
"%TEXLIVE_PATH%lualatex.exe" -interaction=nonstopmode "!FULLTEX!"
if errorlevel 1 (
    echo ERROR: Final lualatex pass failed!
    goto error
)
echo.

:: ==========================================
:: FINAL CHECK – one single pass
:: ==========================================
if exist "!FILENAME!.pdf" (
    echo ========================================
    echo   SUCCESS! PDF created
    echo ========================================
    echo.
    echo Output: !FILENAME!.pdf
    echo.
    if exist "!FILENAME!.ind" (
        echo ✅ Index included in PDF
    ) else (
        echo ℹ️ No index generated (no \idx entries)
    )
    echo.
    echo ========================================
    echo   Opening with SumatraPDF
    echo ========================================
    taskkill /f /im SumatraPDF.exe 2>nul
    timeout /t 1 /nobreak >nul
    if exist "%CD%\%SUMATRA_EXE%" (
        echo Found SumatraPDF – opening...
        start "" "%CD%\%SUMATRA_EXE%" -reuse-instance "!FILENAME!.pdf"
        echo.
        echo ========================================
        echo   SumatraPDF opened successfully
        echo   PDF: %CD%\!FILENAME!.pdf
        echo ========================================
    ) else (
        echo ERROR: SumatraPDF.exe not found in current directory.
        echo PDF created but viewer not opened.
    )
    goto end
) else (
    echo ========================================
    echo   ERROR: PDF not created
    echo ========================================
    echo Check !FILENAME!.log for errors
    pause
    goto end
)

:error
echo.
echo ========================================
echo   ERROR: Compilation failed
echo ========================================
echo Check !FILENAME!.log for errors.
pause

:end
pause