@echo off
set PATH=E:\Processings\Online_Softwares\Python\Python38_updated;%PATH%
set PATH=E:\Processings\Online_Softwares\CODE\VSCode-Latex_win32-x64-1.70.2;%PATH%
set PATH=E:\Processings\Online_Softwares\LEAN\lean-3.23.0-windows\bin;%PATH%
set PATH=E:\Processings\Doctorate\texlive\2024\bin\windows;%PATH%
set PATH=E:\Processings\Online_Softwares\tools\curl-8.21.0_2-win64-mingw\bin;%PATH%
set PATH=E:\Processings\Online_Softwares\tools\node-v13.14.0-win-x64;%PATH%
set PATH=E:\Processings\Online_Softwares\tools\ghostscript\gs10.07.0\bin;%PATH%
lean --version
python --version
pdflatex --version
curl --version
node --version



cd \
cmd