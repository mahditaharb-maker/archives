@echo off
title SYSTEM INFORMATION
color 0A

:: Get the directory where the batch file is located
set SCRIPT_DIR=%~dp0
set OUTPUT_FILE=%SCRIPT_DIR%informations.txt

echo.
echo ============================================================================
echo    SYSTEM INFORMATION - Saving to: %OUTPUT_FILE%
echo ============================================================================
echo.
echo Collecting system information... Please wait.

:: Create the output file
echo ============================================================================ > "%OUTPUT_FILE%"
echo                    SYSTEM INFORMATION REPORT >> "%OUTPUT_FILE%"
echo ============================================================================ >> "%OUTPUT_FILE%"
echo. >> "%OUTPUT_FILE%"
echo Report Generated: %date% %time% >> "%OUTPUT_FILE%"
echo Computer Name: %COMPUTERNAME% >> "%OUTPUT_FILE%"
echo User Name: %USERNAME% >> "%OUTPUT_FILE%"
echo. >> "%OUTPUT_FILE%"

:: SECTION 1 - OS VERSION
echo ============================================================================ >> "%OUTPUT_FILE%"
echo 1. OPERATING SYSTEM VERSION >> "%OUTPUT_FILE%"
echo ============================================================================ >> "%OUTPUT_FILE%"
echo. >> "%OUTPUT_FILE%"
ver >> "%OUTPUT_FILE%" 2>&1
echo. >> "%OUTPUT_FILE%"

:: OS Details
echo [Full OS Details] >> "%OUTPUT_FILE%"
echo ----------------- >> "%OUTPUT_FILE%"
systeminfo >> "%OUTPUT_FILE%" 2>&1
echo. >> "%OUTPUT_FILE%"

:: SECTION 2 - CPU
echo ============================================================================ >> "%OUTPUT_FILE%"
echo 2. CPU INFORMATION >> "%OUTPUT_FILE%"
echo ============================================================================ >> "%OUTPUT_FILE%"
echo. >> "%OUTPUT_FILE%"
wmic cpu get Name,NumberOfCores,NumberOfLogicalProcessors,MaxClockSpeed /format:list >> "%OUTPUT_FILE%" 2>&1
echo. >> "%OUTPUT_FILE%"

:: SECTION 3 - RAM
echo ============================================================================ >> "%OUTPUT_FILE%"
echo 3. MEMORY (RAM) >> "%OUTPUT_FILE%"
echo ============================================================================ >> "%OUTPUT_FILE%"
echo. >> "%OUTPUT_FILE%"
wmic memorychip get Capacity,Speed /format:list >> "%OUTPUT_FILE%" 2>&1
echo. >> "%OUTPUT_FILE%"
echo [Total Physical Memory] >> "%OUTPUT_FILE%"
wmic ComputerSystem get TotalPhysicalMemory /format:list >> "%OUTPUT_FILE%" 2>&1
echo. >> "%OUTPUT_FILE%"
echo [Free Physical Memory] >> "%OUTPUT_FILE%"
wmic os get FreePhysicalMemory,FreeVirtualMemory /format:list >> "%OUTPUT_FILE%" 2>&1
echo. >> "%OUTPUT_FILE%"

:: SECTION 4 - DISK SPACE
echo ============================================================================ >> "%OUTPUT_FILE%"
echo 4. DISK SPACE >> "%OUTPUT_FILE%"
echo ============================================================================ >> "%OUTPUT_FILE%"
echo. >> "%OUTPUT_FILE%"
wmic logicaldisk where drivetype=3 get DeviceID,Size,FreeSpace /format:table >> "%OUTPUT_FILE%" 2>&1
echo. >> "%OUTPUT_FILE%"

:: SECTION 5 - NETWORK
echo ============================================================================ >> "%OUTPUT_FILE%"
echo 5. NETWORK CONFIGURATION >> "%OUTPUT_FILE%"
echo ============================================================================ >> "%OUTPUT_FILE%"
echo. >> "%OUTPUT_FILE%"
ipconfig >> "%OUTPUT_FILE%" 2>&1
echo. >> "%OUTPUT_FILE%"

:: SECTION 6 - RUNNING PROCESSES (Top 20 by Memory)
echo ============================================================================ >> "%OUTPUT_FILE%"
echo 6. TOP 20 PROCESSES BY MEMORY >> "%OUTPUT_FILE%"
echo ============================================================================ >> "%OUTPUT_FILE%"
echo. >> "%OUTPUT_FILE%"
wmic process get Name,WorkingSetSize /format:table >> "%OUTPUT_FILE%" 2>&1
echo. >> "%OUTPUT_FILE%"

:: SECTION 7 - SYSTEM UPTIME
echo ============================================================================ >> "%OUTPUT_FILE%"
echo 7. SYSTEM UPTIME >> "%OUTPUT_FILE%"
echo ============================================================================ >> "%OUTPUT_FILE%"
echo. >> "%OUTPUT_FILE%"
net statistics workstation >> "%OUTPUT_FILE%" 2>&1
echo. >> "%OUTPUT_FILE%"

:: SECTION 8 - INSTALLED HOTFIXES
echo ============================================================================ >> "%OUTPUT_FILE%"
echo 8. INSTALLED HOTFIXES / UPDATES >> "%OUTPUT_FILE%"
echo ============================================================================ >> "%OUTPUT_FILE%"
echo. >> "%OUTPUT_FILE%"
wmic qfe list brief >> "%OUTPUT_FILE%" 2>&1
echo. >> "%OUTPUT_FILE%"

:: SECTION 9 - ENVIRONMENT VARIABLES
echo ============================================================================ >> "%OUTPUT_FILE%"
echo 9. ENVIRONMENT VARIABLES >> "%OUTPUT_FILE%"
echo ============================================================================ >> "%OUTPUT_FILE%"
echo. >> "%OUTPUT_FILE%"
set >> "%OUTPUT_FILE%" 2>&1
echo. >> "%OUTPUT_FILE%"

:: End of report
echo ============================================================================ >> "%OUTPUT_FILE%"
echo                    END OF SYSTEM INFORMATION REPORT >> "%OUTPUT_FILE%"
echo ============================================================================ >> "%OUTPUT_FILE%"

:: Create timestamped backup
set TIMESTAMP=%date:~-4,4%%date:~-7,2%%date:~-10,2%_%time:~0,2%%time:~3,2%%time:~6,2%
set TIMESTAMP=%TIMESTAMP: =0%
set BACKUP_FILE=%SCRIPT_DIR%backup_%TIMESTAMP%.log
copy "%OUTPUT_FILE%" "%BACKUP_FILE%" > nul 2>&1

echo.
echo ============================================================================
echo  SYSTEM INFORMATION COMPLETE!
echo ============================================================================
echo.
echo Report saved to: %OUTPUT_FILE%
echo Backup saved to: %BACKUP_FILE%
echo.
echo Press any key to open the report...
pause > nul
start notepad "%OUTPUT_FILE%"
exit