@echo off
setlocal enabledelayedexpansion

REM =========================================================
REM  COMPILE ANY .TEX FILE IN THE CURRENT DIRECTORY
REM  Usage: compile_tex.bat [filename_without_extension]
REM  If no filename given, the first .tex file is used.
REM =========================================================

REM ---- Set paths (same as original) ----
set TEXLIVE=E:\Processings\Doctorate\texlive\2024\bin\windows
set NODEJS=E:\Processings\Online_Softwares\tools\node-v13.14.0-win-x64
set NPM_GLOBAL=%APPDATA%\npm
set PATH=%TEXLIVE%;%NODEJS%;%NPM_GLOBAL%;%PATH%

REM ---- Puppeteer/Chrome settings for mermaid ----
set PUPPETEER_SKIP_CHROMIUM_DOWNLOAD=true
set PUPPETEER_EXECUTABLE_PATH=D:\apps\chrome+idm\Google\Chrome\Application\chrome.exe
set PUPPETEER_LAUNCH_ARGS=--no-sandbox --disable-setuid-sandbox --disable-gpu

REM ---- Determine which .tex file to compile ----
if "%1" neq "" (
    set TEXFILE=%~n1
) else (
    set TEXFILE=
    for %%f in (*.tex) do (
        if not defined TEXFILE set TEXFILE=%%~nf
    )
)

if not defined TEXFILE (
    echo ERROR: No .tex file found in current directory!
    pause
    exit /b 1
)

if not exist "%TEXFILE%.tex" (
    echo ERROR: File "%TEXFILE%.tex" not found!
    pause
    exit /b 1
)

REM ---- Check if lualatex is available ----
where lualatex >nul 2>nul
if errorlevel 1 (
    echo ERROR: lualatex not found in PATH!
    pause
    exit /b 1
)

REM ---- Clean auxiliary files ----
echo Cleaning auxiliary files...
del /q "%TEXFILE%.aux" "%TEXFILE%.toc" "%TEXFILE%.out" "%TEXFILE%.log" "%TEXFILE%.lof" "%TEXFILE%.lot" "%TEXFILE%.idx" "%TEXFILE%.ind" "%TEXFILE%.ilg" 2>nul

echo.
echo ============================================
echo  COMPILING: %TEXFILE%.tex
echo ============================================
echo.

REM ---- First pass ----
echo [1/4] First LaTeX pass...
lualatex -shell-escape -interaction=nonstopmode "%TEXFILE%.tex" || goto error

REM ---- Index generation ----
echo [2/4] Generating index...
if exist "%TEXFILE%.idx" (
    makeindex -s indexstyle.ist "%TEXFILE%.idx" 2>nul
)

REM ---- Second pass ----
echo [3/4] Second LaTeX pass...
lualatex -shell-escape -interaction=nonstopmode "%TEXFILE%.tex" || goto error

REM ---- Third pass ----
echo [4/4] Third LaTeX pass...
lualatex -shell-escape -interaction=nonstopmode "%TEXFILE%.tex" || goto error

echo.
echo ============================================
echo  BUILD SUCCESSFUL!  Output: %TEXFILE%.pdf
echo ============================================
echo.

REM ---- Open the PDF with SumatraPDF (if present) ----
if exist "SumatraPDF.exe" (
    echo Opening %TEXFILE%.pdf with SumatraPDF...
    start "" "SumatraPDF.exe" "%TEXFILE%.pdf"
) else (
    echo SumatraPDF.exe not found in current directory.
    echo Please open %TEXFILE%.pdf manually.
)

pause
exit /b

:error
echo.
echo ERROR! Check %TEXFILE%.log
pause
exit /b 1