@echo off
setlocal enabledelayedexpansion

:: ============================================================
::  Configuration (EDIT THIS IF YOUR TEXLIVE PATH IS DIFFERENT)
:: ============================================================
set TEXLIVE_PATH=E:\archives\Processings\Doctorate\texlive\2024\bin\windows\
:: If the above does not work, set to empty to rely on PATH:
:: set TEXLIVE_PATH=

:: ============================================================
::  Logging setup
:: ============================================================
set LOGDIR=logs
if not exist "%LOGDIR%" mkdir "%LOGDIR%"
for /f %%i in ('powershell -Command "Get-Date -Format 'yyyyMMdd_HHmmss'"') do set TIMESTAMP=%%i
set LOGFILE=%LOGDIR%\compile_%TIMESTAMP%.log

:: Start transcript
powershell -Command "Start-Transcript -Path '%LOGFILE%' -Append" >nul 2>&1

echo ========================================
echo   Compiling with LuaLaTeX
echo ========================================
echo Log file: %LOGFILE%
echo.

:: ============================================================
::  Verify TeX Live path
:: ============================================================
if not defined TEXLIVE_PATH (
    echo [INFO] TEXLIVE_PATH not set. Will rely on system PATH.
) else (
    echo [INFO] Using TeX Live path: %TEXLIVE_PATH%
    if not exist "%TEXLIVE_PATH%lualatex.exe" (
        echo [ERROR] lualatex.exe not found at %TEXLIVE_PATH%
        echo [ERROR] Please check the path or set TEXLIVE_PATH correctly.
        pause
        goto cleanup
    )
)

:: ============================================================
::  Check JuliaMono fonts (download if missing)
:: ============================================================
set FONT_DIR=JuliaMono
set JULIA_VERSION=0.058
set ZIP_NAME=JuliaMono-%JULIA_VERSION%.zip
set DOWNLOAD_URL=https://github.com/cormullion/juliamono/releases/download/v%JULIA_VERSION%/%ZIP_NAME%

if exist "%FONT_DIR%" (
    echo [OK] Font folder found.
) else (
    echo [INFO] Downloading JuliaMono fonts...
    powershell -Command "Invoke-WebRequest -Uri '%DOWNLOAD_URL%' -OutFile '%ZIP_NAME%'"
    if errorlevel 1 (
        echo [ERROR] Download failed.
        pause
        goto cleanup
    )
    powershell -Command "Expand-Archive -Force '%ZIP_NAME%' -DestinationPath '.'"
    if errorlevel 1 (
        echo [ERROR] Extraction failed.
        pause
        goto cleanup
    )
    if not exist "%FONT_DIR%" mkdir "%FONT_DIR%"
    for %%f in ("JuliaMono-%JULIA_VERSION%\*.ttf") do move "%%f" "%FONT_DIR%\" >nul
    rmdir /s /q "JuliaMono-%JULIA_VERSION%" 2>nul
    del "%ZIP_NAME%"
    echo [OK] Fonts downloaded.
)

:: ============================================================
::  Find .tex file
:: ============================================================
set FILENAME=
for %%f in (*.tex) do (
    set FILENAME=%%~nf
    set FULLTEX=%%f
    goto :found
)
echo [ERROR] No .tex file found in current directory!
pause
goto cleanup

:found
echo [INFO] Found TeX file: %FULLTEX%
echo.

:: ============================================================
::  Ask user whether to clean old files
:: ============================================================
set /p CLEAN="Do you want to delete old auxiliary files (clean build)? (y/n): "
if /i "%CLEAN%"=="y" (
    echo [INFO] Performing clean build – deleting old files.
    if exist "%FILENAME%.pdf" (
        echo Deleting %FILENAME%.pdf...
        attrib -r "%FILENAME%.pdf" 2>nul
        del /f /q "%FILENAME%.pdf" 2>nul
    )
    del /f /q "%FILENAME%.aux" "%FILENAME%.bbl" "%FILENAME%.bcf" "%FILENAME%.blg" 2>nul
    del /f /q "%FILENAME%.idx" "%FILENAME%.ilg" "%FILENAME%.listing" "%FILENAME%.ind" 2>nul
    del /f /q "%FILENAME%.log" "%FILENAME%.out" "%FILENAME%.toc" 2>nul
    del /f /q "%FILENAME%.synctex.gz" 2>nul
    del /f /q "%FILENAME%.nav" "%FILENAME%.snm" "%FILENAME%.vrb" 2>nul
    del /f /q "%FILENAME%.run.xml" 2>nul
    del /f /q "indexstyle.ist" 2>nul
    del /f /q "references.bib" 2>nul
    echo Done.
) else (
    echo [INFO] Keeping old auxiliary files – incremental build.
)

:: ============================================================
::  Set lualatex command
:: ============================================================
if defined TEXLIVE_PATH (
    set LUALATEX_CMD=%TEXLIVE_PATH%lualatex.exe
) else (
    set LUALATEX_CMD=lualatex
)
echo [INFO] Lualatex command: %LUALATEX_CMD%

:: Verify lualatex exists
%LUALATEX_CMD% --version >nul 2>&1
if errorlevel 1 (
    echo [ERROR] lualatex is not available. Check your TeX Live installation.
    pause
    goto cleanup
)
echo [OK] lualatex is working.

:: ============================================================
::  Kill PDF viewers
:: ============================================================
echo [INFO] Closing PDF viewers...
taskkill /f /im Acrobat.exe 2>nul
taskkill /f /im AcroRd32.exe 2>nul
taskkill /f /im AcrobatReader.exe 2>nul
taskkill /f /im AcroCEF.exe 2>nul
taskkill /f /im FoxitReader.exe 2>nul
taskkill /f /im FoxitPDFReader.exe 2>nul
taskkill /f /im SumatraPDF.exe 2>nul
timeout /t 1 /nobreak >nul

:: ============================================================
::  Compile with latexmk if available (recommended)
:: ============================================================
where latexmk >nul 2>&1
if %errorlevel%==0 (
    echo [INFO] Using latexmk for automated build...
    latexmk -lualatex -interaction=nonstopmode -synctex=1 "%FULLTEX%"
    if errorlevel 1 (
        echo [ERROR] latexmk failed.
        goto error
    )
) else (
    echo [INFO] latexmk not found – falling back to manual steps.
    echo.

    echo [STEP 1/7] lualatex (first pass)
    "%LUALATEX_CMD%" -interaction=nonstopmode "%FULLTEX%"
    if errorlevel 1 goto error

    echo [STEP 2/7] bibtex (if .aux exists)
    if exist "%FILENAME%.aux" (
        if defined TEXLIVE_PATH (
            if exist "%TEXLIVE_PATH%bibtex.exe" (
                "%TEXLIVE_PATH%bibtex.exe" "%FILENAME%"
            ) else (
                echo [WARNING] bibtex not found, skipping.
            )
        ) else (
            where bibtex >nul 2>&1 && bibtex "%FILENAME%"
        )
    )

    echo [STEP 3/7] makeindex (if .idx exists)
    if exist "%FILENAME%.idx" (
        if defined TEXLIVE_PATH (
            if exist "%TEXLIVE_PATH%makeindex.exe" (
                if exist indexstyle.ist (
                    "%TEXLIVE_PATH%makeindex.exe" -s indexstyle.ist "%FILENAME%.idx"
                ) else (
                    "%TEXLIVE_PATH%makeindex.exe" "%FILENAME%.idx"
                )
            ) else (
                echo [WARNING] makeindex not found, skipping.
            )
        ) else (
            where makeindex >nul 2>&1 && makeindex "%FILENAME%.idx"
        )
    )

    echo [STEP 4/7] lualatex (second pass)
    "%LUALATEX_CMD%" -interaction=nonstopmode "%FULLTEX%"
    if errorlevel 1 goto error

    echo [STEP 5/7] lualatex (third pass)
    "%LUALATEX_CMD%" -interaction=nonstopmode "%FULLTEX%"
    if errorlevel 1 goto error

    echo [STEP 6/7] makeindex (final pass)
    if exist "%FILENAME%.idx" (
        if defined TEXLIVE_PATH (
            if exist "%TEXLIVE_PATH%makeindex.exe" (
                if exist indexstyle.ist (
                    "%TEXLIVE_PATH%makeindex.exe" -s indexstyle.ist "%FILENAME%.idx"
                ) else (
                    "%TEXLIVE_PATH%makeindex.exe" "%FILENAME%.idx"
                )
            )
        ) else (
            where makeindex >nul 2>&1 && makeindex "%FILENAME%.idx"
        )
    )

    echo [STEP 7/7] lualatex (final pass to resolve all references)
    "%LUALATEX_CMD%" -interaction=nonstopmode "%FULLTEX%"
    if errorlevel 1 goto error
)

:: ============================================================
::  ANALYZE LOG FOR UNDEFINED REFERENCES
:: ============================================================
echo.
echo ========================================
echo   ANALYZING REFERENCES
echo ========================================

:: Check if log file exists
if not exist "%FILENAME%.log" (
    echo [WARNING] No log file found to analyze.
    goto skip_analysis
)

:: Count undefined references
set UNDEF_COUNT=0
set CITATION_COUNT=0
set LABEL_COUNT=0
set UNKNOWN_COUNT=0

echo.
echo [INFO] Scanning for undefined references...
echo.

:: Extract all undefined reference warnings
for /f "delims=" %%a in ('findstr /C:"undefined" /C:"not defined" "%FILENAME%.log" 2^>nul') do (
    set /a UNDEF_COUNT+=1
    echo   %%a
)

:: Count citations separately
for /f "delims=" %%a in ('findstr /C:"Citation" /C:"undefined" "%FILENAME%.log" 2^>nul') do (
    set /a CITATION_COUNT+=1
)

:: Count label references separately
for /f "delims=" %%a in ('findstr /C:"Reference" /C:"undefined" "%FILENAME%.log" 2^>nul') do (
    set /a LABEL_COUNT+=1
)

echo.
echo ========================================
echo   REFERENCE SUMMARY
echo ========================================
echo.
echo   Total undefined references: %UNDEF_COUNT%
echo   Undefined citations:        %CITATION_COUNT%
echo   Undefined labels:           %LABEL_COUNT%
echo.

if %UNDEF_COUNT%==0 (
    echo [OK] No undefined references found!
    echo.
) else (
    echo [WARNING] Some references are undefined.
    echo.
    echo To fix:
    echo   1. Check that all \label{} names match exactly with \ref{} or \cite{}
    echo   2. Run the batch file again – references sometimes resolve on second pass
    echo   3. For citations, ensure the entry exists in References.bib
    echo   4. For labels, check for typos or missing \label commands
    echo.

    :: Extract specific undefined references for easier debugging
    echo [DETAILS] Undefined references found:
    echo.
    findstr /C:"undefined" "%FILENAME%.log" 2>nul | findstr /C:"Citation" >nul
    if not errorlevel 1 (
        echo   --- Undefined citations ---
        findstr /C:"Citation" "%FILENAME%.log" 2>nul | findstr /C:"undefined"
        echo.
    )
    findstr /C:"undefined" "%FILENAME%.log" 2>nul | findstr /C:"Reference" >nul
    if not errorlevel 1 (
        echo   --- Undefined labels ---
        findstr /C:"Reference" "%FILENAME%.log" 2>nul | findstr /C:"undefined"
        echo.
    )

    :: Check if references were resolved in the final run
    echo.
    echo [INFO] Checking if references were resolved...
    findstr /C:"Label(s) may have changed" "%FILENAME%.log" >nul
    if not errorlevel 1 (
        echo   ⚠️  References may still be unresolved. Try running the script again.
        echo.
    ) else (
        echo   ✅ All references appear to be resolved.
        echo.
    )
)

:skip_analysis

:: ============================================================
::  Check output and open PDF
:: ============================================================
if exist "%FILENAME%.pdf" (
    echo ========================================
    echo   SUCCESS! PDF created.
    echo ========================================
    echo Opening with SumatraPDF...
    where SumatraPDF >nul 2>&1
    if %errorlevel%==0 (
        start SumatraPDF -reuse-instance "%FILENAME%.pdf"
    ) else if exist "%CD%\SumatraPDF.exe" (
        start "" "%CD%\SumatraPDF.exe" -reuse-instance "%FILENAME%.pdf"
    ) else (
        echo SumatraPDF not found – PDF is at %CD%\%FILENAME%.pdf
    )
    goto cleanup
) else (
    echo [ERROR] PDF not produced.
    goto error
)

:error
echo.
echo [ERROR] Compilation failed. Check %FILENAME%.log for details.
pause
goto cleanup

:cleanup
powershell -Command "Stop-Transcript" >nul 2>&1
echo [INFO] Log saved to %LOGFILE%
pause