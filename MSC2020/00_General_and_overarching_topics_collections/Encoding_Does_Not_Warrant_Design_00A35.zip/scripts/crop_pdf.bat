@echo off
setlocal enabledelayedexpansion

REM ============================================================
REM  CROP A MERMAID PDF TO REMOVE WHITE MARGINS
REM  Usage: crop_pdf.bat [input.pdf]
REM  If no input given, defaults to the first PDF in /mermaid
REM ============================================================

REM ---- Add TeX Live and Strawberry Perl Portable to PATH ----
set TEXLIVE=E:\archives\Processings\Doctorate\texlive\2024\bin\windows
set PERL_PATH=E:\archives\Processings\Online_Softwares\tools\strawberry-perl-5.42.2.1-64bit-portable\perl\bin
set PATH=%TEXLIVE%;%PERL_PATH%;%PATH%

REM ---- Check if Perl is available ----
where perl >nul 2>nul
if errorlevel 1 (
    echo ERROR: Perl not found in %PERL_PATH%
    echo Please check the path to your portable Strawberry Perl.
    pause
    exit /b 1
)

REM ---- Determine input file ----
if "%1" neq "" (
    set INPDF=%~1
) else (
    REM Look for the first .pdf in the mermaid folder
    for %%f in (*.pdf) do (
        if not defined INPDF set INPDF=%%f
    )
)

if not defined INPDF (
    echo ERROR: No PDF found. Please specify a file or place the PDF in the mermaid folder.
    pause
    exit /b 1
)

if not exist "%INPDF%" (
    echo ERROR: File "%INPDF%" not found!
    pause
    exit /b 1
)

REM ---- Set output name: prepend "cropped_" to the base name ----
for %%F in ("%INPDF%") do set OUTFILE=cropped_%%~nxF

REM ---- Run pdfcrop with zero margins ----
echo Cropping "%INPDF%" -> "%OUTFILE%" ...
pdfcrop --margins 0 "%INPDF%" "%OUTFILE%"

if errorlevel 1 (
    echo.
    echo ERROR: pdfcrop failed. Check that the TeX Live path is correct and pdfcrop exists.
    pause
    exit /b 1
)

echo.
echo SUCCESS! Cropped PDF saved as "%OUTFILE%"
pause