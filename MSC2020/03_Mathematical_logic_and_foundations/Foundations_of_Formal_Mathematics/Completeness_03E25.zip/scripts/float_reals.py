#!/usr/bin/env python3
"""
Modern machine implementation of referential functions and constants
using IEEE 754 double-precision floating-point arithmetic.
All computations are finite-precision approximations.
"""

import math

def demo_float_arithmetic():
    """Demonstrate the finite-precision real arithmetic on a modern machine."""
    print("Using IEEE 754 double precision:")
    
    # ---- Universal constants ----
    e = math.e                 # base of natural log
    pi = math.pi               # circle constant
    i = 1j                    # imaginary unit (as complex)
    
    print(f"e  = {e:.15f}")
    print(f"pi = {pi:.15f}")
    print(f"i  = {i}")
    print()
    
    # ---- Elementary functions at x = 1 ----
    x = 1.0
    sin_x = math.sin(x)
    cos_x = math.cos(x)
    tan_x = math.tan(x)
    exp_x = math.exp(x)
    ln_e = math.log(e)        # should be 1
    sinh_x = math.sinh(x)
    cosh_x = math.cosh(x)
    
    print(f"sin(1)   = {sin_x:.15f}")
    print(f"cos(1)   = {cos_x:.15f}")
    print(f"tan(1)   = {tan_x:.15f}")
    print(f"exp(1)   = {exp_x:.15f}")
    print(f"ln(e)    = {ln_e:.15f}")
    print(f"sinh(1)  = {sinh_x:.15f}")
    print(f"cosh(1)  = {cosh_x:.15f}")
    print()
    
    # ---- Pythagorean identity verification ----
    pythagorean = sin_x*sin_x + cos_x*cos_x
    error = abs(pythagorean - 1.0)
    print(f"sin^2(1) + cos^2(1) = {pythagorean:.15f}  (error = {error:.2e})")
    
    # ---- Check identity exp(x)*exp(-x) = 1 ----
    exp_neg = math.exp(-x)
    product = exp_x * exp_neg
    print(f"exp(1) * exp(-1) = {product:.15f}")
    
    # ---- Periodicity at pi ----
    sin_pi = math.sin(pi)
    cos_pi = math.cos(pi)
    print(f"sin(pi)  = {sin_pi:.15f}  (should be 0)")
    print(f"cos(pi)  = {cos_pi:.15f}  (should be -1)")
    
    # ---- Demonstrate that floating-point is finite ----
    # The set of representable floats is finite (about 2^64 values).
    # We can see the machine epsilon (smallest increment that changes 1.0)
    eps = math.eps
    print(f"Machine epsilon = {eps:.2e}")
    print("The Pythagorean identity error is on the order of machine epsilon.")
    print("This is the best possible accuracy with finite-precision hardware.")

if __name__ == "__main__":
    demo_float_arithmetic()