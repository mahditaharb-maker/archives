import math

class FiniteField:
    """Represents an element of F_p."""
    def __init__(self, value, p):
        self.p = p
        self.value = value % p

    def __add__(self, other):
        return FiniteField((self.value + other.value) % self.p, self.p)

    def __sub__(self, other):
        return FiniteField((self.value - other.value) % self.p, self.p)

    def __mul__(self, other):
        return FiniteField((self.value * other.value) % self.p, self.p)

    def __truediv__(self, other):
        # modular inverse
        inv = pow(other.value, -1, self.p)
        return FiniteField((self.value * inv) % self.p, self.p)

    def __pow__(self, exp):
        return FiniteField(pow(self.value, exp, self.p), self.p)

    def __neg__(self):
        return FiniteField((-self.value) % self.p, self.p)

    def __eq__(self, other):
        return self.value == other.value and self.p == other.p

    def __repr__(self):
        return f"{self.value}"

    def inv(self):
        return FiniteField(pow(self.value, -1, self.p), self.p)

    def sqrt(self):
        # Tonelli-Shanks for p ≡ 1 mod 4; works for any p where sqrt exists
        if self.value == 0:
            return FiniteField(0, self.p)
        if pow(self.value, (self.p - 1)//2, self.p) != 1:
            raise ValueError("No square root")
        # simple for p ≡ 3 mod 4
        if self.p % 4 == 3:
            return FiniteField(pow(self.value, (self.p + 1)//4, self.p), self.p)
        # Tonelli-Shanks general (for p ≡ 1 mod 4)
        # For simplicity, we brute-force (only for small p)
        for r in range(1, self.p):
            if (r * r) % self.p == self.value:
                return FiniteField(r, self.p)
        raise ValueError("No square root")

def primitive_root(p):
    """Find the smallest primitive root modulo p."""
    if p == 2:
        return 1
    # factorisation of p-1
    phi = p - 1
    factors = []
    n = phi
    d = 2
    while d * d <= n:
        if n % d == 0:
            factors.append(d)
            while n % d == 0:
                n //= d
        d += 1
    if n > 1:
        factors.append(n)
    for g in range(2, p):
        ok = True
        for q in factors:
            if pow(g, phi // q, p) == 1:
                ok = False
                break
        if ok:
            return g
    return None

def factorial_mod(n, p):
    """Compute n! mod p."""
    res = 1
    for i in range(2, n+1):
        res = (res * i) % p
    return res

def taylor_series(func, p, order=None):
    """
    Generic Taylor series evaluator for functions with known coefficients.
    func(k) returns the coefficient of x^k / k! for k=0..order.
    Returns a function that evaluates the series at a field element x.
    """
    if order is None:
        order = p - 1  # we can go up to p-1 because k! is invertible modulo p for k < p
    def eval_series(x):
        if not isinstance(x, FiniteField):
            x = FiniteField(x, p)
        result = FiniteField(0, p)
        fact = 1
        for k in range(order + 1):
            coeff = func(k) % p  # coefficient a_k in sum a_k x^k / k!
            # Actually we want sum (coeff/k!) x^k, but if we have coeff as the numerator
            # we need to divide by k! ; we'll accumulate term = coeff * x^k / k!
            # Instead, we precompute factorial inverse.
            term = FiniteField(coeff * pow(factorial_mod(k, p), -1, p) % p, p)
            term = term * (x ** k)
            result = result + term
        return result
    return eval_series

def create_functions(p):
    """Create and return all function objects and constants for F_p."""
    # Constants
    i_val = None
    try:
        i_val = FiniteField(-1, p).sqrt()
    except ValueError:
        pass
    e_val = primitive_root(p)  # base of natural exp as a primitive root
    pi_val = (p - 1) // 2      # half-turn constant

    # Taylor series coefficients: sin, cos, exp, sinh, cosh
    # sin: a_k = 0 for even, (-1)^((k-1)/2) for odd
    def sin_coeff(k):
        if k % 2 == 0:
            return 0
        sign = -1 if ((k-1)//2) % 2 else 1
        return sign
    sin_func = taylor_series(sin_coeff, p)

    def cos_coeff(k):
        if k % 2 == 1:
            return 0
        sign = -1 if (k//2) % 2 else 1
        return sign
    cos_func = taylor_series(cos_coeff, p)

    def exp_coeff(k):
        return 1  # coefficient for x^k/k! is 1
    exp_func = taylor_series(exp_coeff, p)

    # sinh = (exp(x) - exp(-x))/2, cosh = (exp(x)+exp(-x))/2
    # We can implement directly via exp
    def sinh_func(x):
        if not isinstance(x, FiniteField):
            x = FiniteField(x, p)
        ex = exp_func(x)
        ex_neg = exp_func(-x)
        return (ex - ex_neg) / FiniteField(2, p)

    def cosh_func(x):
        if not isinstance(x, FiniteField):
            x = FiniteField(x, p)
        ex = exp_func(x)
        ex_neg = exp_func(-x)
        return (ex + ex_neg) / FiniteField(2, p)

    # tan = sin/cos (if cos != 0)
    def tan_func(x):
        if not isinstance(x, FiniteField):
            x = FiniteField(x, p)
        s = sin_func(x)
        c = cos_func(x)
        if c.value == 0:
            raise ZeroDivisionError("cos(x) = 0, tan undefined")
        return s / c

    # ln(x) = discrete logarithm with base e (primitive root)
    def ln_func(x):
        if not isinstance(x, FiniteField):
            x = FiniteField(x, p)
        if x.value == 0:
            raise ValueError("ln(0) undefined")
        # discrete log of x base e_val
        # simple baby-step giant-step for small p; for large p use built-in? We'll brute.
        # For demonstration, brute force:
        for k in range(1, p):
            if pow(e_val, k, p) == x.value:
                return FiniteField(k, p)
        raise ValueError("x not in cyclic group (should not happen for nonzero)")

    return {
        'p': p,
        'i': i_val,
        'e': e_val,
        'pi': pi_val,
        'sin': sin_func,
        'cos': cos_func,
        'tan': tan_func,
        'exp': exp_func,
        'ln': ln_func,
        'sinh': sinh_func,
        'cosh': cosh_func,
    }

# ------------------- Demonstration -------------------
if __name__ == "__main__":
    p = 97  # a prime where -1 has a sqrt (p ≡ 1 mod 4)
    F = create_functions(p)

    print(f"Prime p = {p}")
    print(f"i = sqrt(-1) = {F['i']}" if F['i'] else "No sqrt(-1) in F_p")
    print(f"e (primitive root) = {F['e']}")
    print(f"pi (half-turn) = {F['pi']}")
    print()

    # Test at x = 1 (as field element)
    x = FiniteField(1, p)
    print(f"sin(1) = {F['sin'](x)}")
    print(f"cos(1) = {F['cos'](x)}")
    print(f"tan(1) = {F['tan'](x)}")
    print(f"exp(1) = {F['exp'](x)}")
    print(f"ln(e) = {F['ln'](FiniteField(F['e'], p))}   (should be 1)")
    print(f"sinh(1) = {F['sinh'](x)}")
    print(f"cosh(1) = {F['cosh'](x)}")
    print()

    # Verify identities
    s = F['sin'](x)
    c = F['cos'](x)
    print(f"sin^2 + cos^2 = {s*s + c*c}   (should be 1)")
    print(f"exp(1) * exp(-1) = {F['exp'](x) * F['exp'](-x)}   (should be 1)")

    # Compute at x = pi/2 (if we have a notion: pi/2 = (p-1)//4 if defined)
    # In this framework, pi is integer (p-1)/2, so pi/2 might not be integer.
    # We can approximate by using an integer representative.
    # For demonstration, we'll compute sin(pi) using the series (should be 0 if series works)
    x_pi = FiniteField(F['pi'], p)
    print(f"sin(pi) = {F['sin'](x_pi)}   (should be 0)")
    print(f"cos(pi) = {F['cos'](x_pi)}   (should be -1)")