#!/usr/bin/env python3
"""
finite_completeness.py

Halting test for finite completeness on a grid G_{p,n}.
This script:
1. Builds a finite grid of fractions x / g^n modulo p (or simply a set of floats).
2. Enumerates all non-empty subsets of the grid and verifies that each has a maximum.
   This check always returns True because finite sets always have a maximum.
3. Provides a utility to search for counterexamples to a universal predicate
   by sampling the grid.

The purpose is to illustrate that the finite completeness axiom is trivial
and to show how finite grids can be used for refutation (finding counterexamples).
"""

import math

# ----------------------------------------------------------------------
# Grid construction
# ----------------------------------------------------------------------

def primitive_root(p):
    """Find a primitive root modulo p (smallest one)."""
    if p == 2:
        return 1
    phi = p - 1
    factors = []
    n = phi
    d = 2
    while d * d <= n:
        if n % d == 0:
            factors.append(d)
            while n % d == 0:
                n //= d
        d += 1
    if n > 1:
        factors.append(n)
    for g in range(2, p):
        ok = True
        for q in factors:
            if pow(g, phi // q, p) == 1:
                ok = False
                break
        if ok:
            return g
    return None

def build_grid(p, n):
    """
    Build the finite grid G_{p,n} = { x / g^n mod p | x in F_p }.
    We represent each element as a rational number in [0,1) for ordering.
    Returns a list of (value, rational_approx) where rational_approx is a float.
    """
    g = primitive_root(p)
    if g is None:
        raise ValueError(f"No primitive root for p={p}")
    scale = pow(g, n) % p
    inv_scale = pow(scale, -1, p)
    grid = []
    for x in range(p):
        # The modular value (in F_p) is x * inv_scale mod p.
        val_mod = (x * inv_scale) % p
        # Rational representative: val_mod / p (or better: as a float)
        # We need a total order; we use the rational number val_mod / p in [0,1).
        rational = val_mod / p
        grid.append((val_mod, rational))
    # Sort by rational value to have a natural order
    grid.sort(key=lambda t: t[1])
    return grid

# ----------------------------------------------------------------------
# Finite completeness check (trivial)
# ----------------------------------------------------------------------

def check_finite_completeness(grid):
    """
    Check that every non-empty subset of the grid has a maximum.
    This always returns True for any finite totally ordered set.
    """
    grid_values = [x for (x, _) in grid]
    # Enumerate all non-empty subsets (only for small grids!)
    # For demonstration, we limit to grids of size <= 8 to keep execution fast.
    if len(grid_values) > 8:
        print("Grid too large for exhaustive subset enumeration; skipping.")
        return True
    # Generate all non-empty subsets using bitmask
    n = len(grid_values)
    for mask in range(1, 1 << n):
        subset = [grid_values[i] for i in range(n) if (mask >> i) & 1]
        # The maximum is simply max(subset) because the order is total
        # In our grid, the order is by rational value; we can just use Python's max
        max_elem = max(subset)
        # Check that max_elem is indeed an upper bound and the least.
        # For finite sets, this is automatically true, but we verify:
        is_ub = all(e <= max_elem for e in subset)
        is_lub = all(u >= max_elem for u in subset)  # trivial because max is in subset
        if not is_ub or not is_lub:
            return False
    return True

# ----------------------------------------------------------------------
# Counterexample search
# ----------------------------------------------------------------------

def search_counterexample(predicate, grid, threshold=0):
    """
    Search the grid for an element x such that predicate(x) is False.
    predicate: a function that takes a grid element (value) and returns bool.
    threshold: if predicate returns a numeric value, we treat it as True if > threshold.
    Returns the first counterexample found, or None if none found.
    """
    for val, rat in grid:
        # Evaluate predicate; if predicate returns a number, compare to threshold
        res = predicate(val)
        if isinstance(res, (int, float)):
            if res <= threshold:
                return val, rat
        else:
            if not res:
                return val, rat
    return None

# ----------------------------------------------------------------------
# Demo functions
# ----------------------------------------------------------------------

def demo_completeness():
    print("=== Finite completeness check ===")
    p = 5
    n = 2
    print(f"Grid for p={p}, n={n}:")
    grid = build_grid(p, n)
    for val, rat in grid:
        print(f"  {val} (rational approx {rat:.3f})")
    result = check_finite_completeness(grid)
    print(f"Finite completeness axiom holds: {result}")
    print()

def demo_counterexample():
    print("=== Counterexample search ===")
    p = 7
    n = 1
    grid = build_grid(p, n)
    print(f"Grid for p={p}, n={n} size {len(grid)}")

    # Define a predicate: f(x) = x^2 - 0.5 > 0  (should be false for some)
    def predicate(val):
        # val is a modular integer, we use its rational representative
        # We'll use the rational approximation for the function.
        # For demo, we'll just use the rational value.
        # We need to map val to its rational representative.
        # We have the grid as list of (val, rational). We'll find the rational for this val.
        # Simpler: use the rational directly from the grid.
        # Better: we'll pass rational as argument.
        pass

    # Instead, we define a predicate that uses the rational value directly.
    # Let's search for x such that x^2 - 0.5 <= 0.
    # Using the rational values.
    def pred(x_rat):
        return x_rat**2 - 0.5 > 0.0

    # We'll evaluate at each grid point.
    # The grid stores (val_mod, rational).
    for val, rat in grid:
        if rat**2 - 0.5 <= 0.0:
            print(f"Counterexample found: val={val}, rational={rat:.3f}, f(x)={rat**2 - 0.5:.3f}")
            return
    print("No counterexample found on this grid (predicate true for all).")

def main():
    demo_completeness()
    demo_counterexample()

if __name__ == "__main__":
    main()