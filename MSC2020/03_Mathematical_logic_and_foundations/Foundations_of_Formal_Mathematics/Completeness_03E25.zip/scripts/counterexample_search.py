#!/usr/bin/env python3
"""
counterexample_search.py

Search for counterexamples to a universal predicate on a finite grid.
This script builds a grid G_{p,n} (as fractions modulo p) and evaluates a
given predicate on each grid point. If the predicate fails at any point,
it reports a counterexample.

This is useful for refuting statements of the form:
    "forall x in [a,b], P(x)"
by sampling a finite set of points. If the failure is not isolated, a fine
enough grid will find it.

The grid is constructed as in the pseudo-real field framework:
    G_{p,n} = { x / g^n mod p | x in F_p }
with a natural ordering by the rational representative in [0,1).
"""

import math

# ----------------------------------------------------------------------
# Grid construction
# ----------------------------------------------------------------------

def primitive_root(p):
    """Find a primitive root modulo p (smallest one)."""
    if p == 2:
        return 1
    phi = p - 1
    factors = []
    n = phi
    d = 2
    while d * d <= n:
        if n % d == 0:
            factors.append(d)
            while n % d == 0:
                n //= d
        d += 1
    if n > 1:
        factors.append(n)
    for g in range(2, p):
        ok = True
        for q in factors:
            if pow(g, phi // q, p) == 1:
                ok = False
                break
        if ok:
            return g
    return None

def build_grid(p, n):
    """
    Build the finite grid G_{p,n} = { x / g^n mod p | x in F_p }.
    Returns a list of (value_mod, rational_approx) where rational_approx is a float.
    """
    g = primitive_root(p)
    if g is None:
        raise ValueError(f"No primitive root for p={p}")
    scale = pow(g, n) % p
    inv_scale = pow(scale, -1, p)
    grid = []
    for x in range(p):
        val_mod = (x * inv_scale) % p
        rational = val_mod / p
        grid.append((val_mod, rational))
    # Sort by rational value to have a natural order
    grid.sort(key=lambda t: t[1])
    return grid

# ----------------------------------------------------------------------
# Counterexample search
# ----------------------------------------------------------------------

def search_counterexample(grid, predicate, threshold=0):
    """
    Search the grid for an element x such that predicate(x) is False.
    predicate: a function that takes a rational value (float) and returns bool or a number.
               If it returns a number, we treat it as False if number <= threshold.
    Returns the first counterexample found as (mod_value, rational), or (None, None).
    """
    for val_mod, rat in grid:
        res = predicate(rat)
        if isinstance(res, (int, float)):
            if res <= threshold:
                return val_mod, rat
        else:
            if not res:
                return val_mod, rat
    return None, None

# ----------------------------------------------------------------------
# Example predicates
# ----------------------------------------------------------------------

def predicate_exp_positive(x):
    """Check if exp(x) > 0. This should always be true."""
    return math.exp(x) > 0.0

def predicate_sin_positive(x):
    """Check if sin(x) > 0. This fails for negative sin values."""
    return math.sin(x) > 0.0

def predicate_quadratic(x):
    """Check if x^2 - 0.5 > 0. Fails for x in [-sqrt(0.5), sqrt(0.5)]."""
    return x**2 - 0.5 > 0.0

# ----------------------------------------------------------------------
# Main demo
# ----------------------------------------------------------------------

def main():
    print("=== Counterexample Search on a Finite Grid ===\n")
    
    # Parameters
    p = 13
    n = 2
    print(f"Using grid: p={p}, n={n} (grid size {p})")
    grid = build_grid(p, n)
    print(f"Grid points (mod value -> rational approx):")
    for val, rat in grid:
        print(f"  {val} -> {rat:.4f}")
    print()

    # Search for counterexample to "exp(x) > 0"
    print("Predicate: exp(x) > 0  (should be true for all x)")
    val, rat = search_counterexample(grid, predicate_exp_positive)
    if val is not None:
        print(f"Counterexample found: val={val}, rational={rat:.4f}, exp({rat:.4f}) = {math.exp(rat):.4f}")
    else:
        print("No counterexample found (predicate holds on all grid points).")
    print()

    # Search for counterexample to "sin(x) > 0"
    print("Predicate: sin(x) > 0")
    val, rat = search_counterexample(grid, predicate_sin_positive)
    if val is not None:
        print(f"Counterexample found: val={val}, rational={rat:.4f}, sin({rat:.4f}) = {math.sin(rat):.4f}")
    else:
        print("No counterexample found on this grid.")
    print()

    # Search for counterexample to "x^2 - 0.5 > 0"
    print("Predicate: x^2 - 0.5 > 0")
    val, rat = search_counterexample(grid, predicate_quadratic)
    if val is not None:
        print(f"Counterexample found: val={val}, rational={rat:.4f}, f(x) = {rat**2 - 0.5:.4f}")
    else:
        print("No counterexample found on this grid.")
    print()

    # Refine grid to find the expected counterexample for quadratic
    print("Refining grid to find counterexample for quadratic...")
    p2 = 31
    n2 = 3
    print(f"Using refined grid: p={p2}, n={n2}")
    grid2 = build_grid(p2, n2)
    val, rat = search_counterexample(grid2, predicate_quadratic)
    if val is not None:
        print(f"Counterexample found: val={val}, rational={rat:.4f}, f(x) = {rat**2 - 0.5:.4f}")
    else:
        print("No counterexample found even on refined grid (grid may still be too coarse).")
    print()

if __name__ == "__main__":
    main()