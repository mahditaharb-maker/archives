from math import isqrt
import sys

def count_pythagorean_tuples(n: int, k: int) -> int:
    """
    Counts non-degenerate integer solutions to:
        x1^2 + x2^2 + ... + xk^2 = d^2
    with 1 <= d < n, and all xi >= 1.
    The count treats permutations of the xi as the same solution.
    """
    if k <= 0 or n <= 1:
        return 0

    total = 0

    for d in range(1, n):
        target = d * d

        # Minimum possible sum of k positive squares is k * 1^2 = k.
        # If even that exceeds target, no solution exists for this d.
        if k > target:
            continue

        def dfs(start: int, remaining: int, current_sum: int) -> int:
            """
            Recursively fills 'remaining' variables.
            Variables are chosen non-decreasing, starting from 'start'.
            'current_sum' is the sum of squares of already chosen variables.
            """
            if remaining == 0:
                return 1 if current_sum == target else 0

            # --- Optimization for the very last variable ---
            if remaining == 1:
                rem = target - current_sum
                if rem <= 0:
                    return 0
                root = isqrt(rem)
                if root * root == rem and root >= start:
                    return 1
                return 0

            # Maximum possible value for the current variable:
            # we must leave at least 1^2 for each of the (remaining-1) later variables.
            max_val = isqrt(target - current_sum - (remaining - 1) * 1)
            if max_val < start:
                return 0

            count = 0
            for x in range(start, max_val + 1):
                new_sum = current_sum + x * x

                # Pruning: if we set this and all later variables to at least x,
                # the sum becomes new_sum + (remaining-1)*x^2.
                # If that minimum exceeds target, larger x will only make it worse.
                if new_sum + (remaining - 1) * x * x > target:
                    break

                count += dfs(x, remaining - 1, new_sum)

            return count

        total += dfs(1, k, 0)

    return total


if __name__ == "__main__":
    if len(sys.argv) == 3:
        n = int(sys.argv[1])
        k = int(sys.argv[2])
    else:
        n = int(input("Enter n (hypotenuse bound, d < n): "))
        k = int(input("Enter k (number of positive legs): "))

    result = count_pythagorean_tuples(n, k)
    print(f"Number of non-degenerate Pythagorean {k}-tuples with hypotenuse < {n}: {result}")